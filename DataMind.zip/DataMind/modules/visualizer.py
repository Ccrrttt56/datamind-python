"""Visualization helpers.

Source: Student + AI
"""

import plotly.express as px


def bar_chart(df, x, y, title=None):
    """Create a bar chart for category-value results."""
    fig = px.bar(df, x=x, y=y, title=title or f"{y} by {x}")
    fig.update_layout(xaxis_title=x, yaxis_title=y)
    return fig


def pie_chart(df, names, values, title=None, hole=0):
    """Create a pie or donut chart for category shares."""
    fig = px.pie(df, names=names, values=values, title=title or f"{values} share by {names}", hole=hole)
    return fig


def line_chart(df, x, y, title=None):
    """Create a line chart for trend results."""
    fig = px.line(df, x=x, y=y, markers=True, title=title or f"{y} over {x}")
    fig.update_layout(xaxis_title=x, yaxis_title=y)
    return fig


def heatmap(corr_df, title="Correlation Heatmap"):
    """Create a heatmap for a correlation matrix."""
    fig = px.imshow(
        corr_df,
        text_auto=True,
        aspect="auto",
        color_continuous_scale="RdBu_r",
        zmin=-1,
        zmax=1,
        title=title,
    )
    return fig


def histogram(df, column, title=None):
    """Create a histogram for one numeric column."""
    fig = px.histogram(df, x=column, title=title or f"Distribution of {column}")
    fig.update_layout(xaxis_title=column, yaxis_title="count")
    return fig


def box_chart(df, column, title=None):
    """Create a box chart for one numeric column."""
    fig = px.box(df, y=column, title=title or f"Box chart of {column}")
    fig.update_layout(yaxis_title=column)
    return fig


def scatter_chart(df, x, y, title=None):
    """Create a scatter chart for two numeric columns."""
    fig = px.scatter(df, x=x, y=y, title=title or f"{x} and {y}")
    fig.update_layout(xaxis_title=x, yaxis_title=y)
    return fig


def recommend_chart(profile, analysis_type=None):
    """Recommend a chart type from dataset profile and analysis type."""
    if analysis_type in {"top_n", "groupby_sum", "groupby_agg"}:
        return {"chart_type": "bar", "reason": "类别和数值结果适合使用柱状图。"}
    if analysis_type == "trend_analysis":
        return {"chart_type": "line", "reason": "时间序列结果适合使用折线图。"}
    if analysis_type == "correlation":
        return {"chart_type": "heatmap", "reason": "相关性矩阵适合使用热力图。"}
    if profile.get("numeric_columns"):
        return {"chart_type": "histogram", "reason": "数值字段适合先查看分布。"}
    return {"chart_type": "table", "reason": "当前结果更适合用表格展示。"}
