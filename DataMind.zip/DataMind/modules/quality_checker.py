"""Data quality checking and quick diagnosis utilities.

Source: Student + AI
"""

import pandas as pd

from modules.capability_detector import detect_capabilities


def quality_report(df):
    """Build a compact quality report for a DataFrame."""
    missing_rate = float(df.isna().mean().mean() * 100) if not df.empty else 0.0
    duplicate_rate = float(df.duplicated().mean() * 100) if len(df) else 0.0
    high_missing_columns = _high_missing_columns(df)
    outlier_summary = _outlier_summary(df)
    capability_table = detect_capabilities(df)
    supported_count = int((capability_table["supported"] == "支持").sum())
    capability_rate = supported_count / max(len(capability_table), 1) * 100

    score = _quality_score(
        missing_rate=missing_rate,
        duplicate_rate=duplicate_rate,
        high_missing_count=len(high_missing_columns),
        outlier_risk_count=len(outlier_summary),
        capability_rate=capability_rate,
    )

    return {
        "score": score,
        "summary": pd.DataFrame(
            [
                {"metric": "综合质量评分", "value": f"{score}/100"},
                {"metric": "整体缺失率", "value": f"{missing_rate:.2f}%"},
                {"metric": "重复行比例", "value": f"{duplicate_rate:.2f}%"},
                {"metric": "高缺失字段数", "value": len(high_missing_columns)},
                {"metric": "异常风险字段数", "value": len(outlier_summary)},
                {"metric": "可支持分析能力数", "value": f"{supported_count}/{len(capability_table)}"},
            ]
        ),
        "issues": pd.DataFrame(_quality_issues(df, high_missing_columns, outlier_summary)),
        "recommendations": pd.DataFrame(_recommendations(high_missing_columns, outlier_summary, missing_rate)),
        "outlier_summary": pd.DataFrame(outlier_summary),
    }


def quick_diagnosis(df):
    """Generate a quick dataset diagnosis summary."""
    report = quality_report(df)
    capabilities = detect_capabilities(df)
    supported = capabilities.loc[capabilities["supported"] == "支持", "capability"].tolist()
    unsupported = capabilities.loc[capabilities["supported"] != "支持", "capability"].tolist()

    return {
        "quality_score": report["score"],
        "dataset_shape": f"{len(df)} 行 x {len(df.columns)} 列",
        "priority_analysis": supported[:4],
        "not_suitable": unsupported[:4],
        "main_issues": report["issues"]["issue"].head(5).tolist()
        if not report["issues"].empty
        else ["未发现明显数据质量问题。"],
    }


def _quality_score(missing_rate, duplicate_rate, high_missing_count, outlier_risk_count, capability_rate):
    score = 100.0
    score -= min(missing_rate * 0.8, 35)
    score -= min(duplicate_rate * 1.2, 20)
    score -= min(high_missing_count * 3, 20)
    score -= min(outlier_risk_count * 2, 15)
    score += min(capability_rate * 0.1, 10)
    return max(0, min(100, round(score)))


def _high_missing_columns(df, threshold=0.4):
    missing_rates = df.isna().mean()
    return missing_rates[missing_rates >= threshold].sort_values(ascending=False).to_dict()


def _outlier_summary(df):
    rows = []
    numeric_df = df.select_dtypes(include="number")
    for column in numeric_df.columns:
        series = numeric_df[column].dropna()
        if len(series) < 8:
            continue
        q1 = series.quantile(0.25)
        q3 = series.quantile(0.75)
        iqr = q3 - q1
        if iqr == 0:
            continue
        lower = q1 - 1.5 * iqr
        upper = q3 + 1.5 * iqr
        mask = (series < lower) | (series > upper)
        outlier_count = int(mask.sum())
        outlier_rate = outlier_count / len(series) * 100
        if outlier_rate >= 1:
            rows.append(
                {
                    "column": column,
                    "outlier_count": outlier_count,
                    "outlier_rate_%": round(outlier_rate, 2),
                    "method": "IQR",
                }
            )
    return rows


def _quality_issues(df, high_missing_columns, outlier_summary):
    rows = []
    duplicate_count = int(df.duplicated().sum())
    if duplicate_count:
        rows.append(
            {
                "issue": f"存在 {duplicate_count} 行重复记录。",
                "severity": "中",
                "suggestion": "可在清洗模块中删除重复行。",
            }
        )

    for column, rate in list(high_missing_columns.items())[:10]:
        rows.append(
            {
                "issue": f"字段 {column} 缺失率较高（{rate * 100:.2f}%）。",
                "severity": "高",
                "suggestion": "分析前应考虑删除、填充或解释该字段缺失原因。",
            }
        )

    for item in outlier_summary[:10]:
        rows.append(
            {
                "issue": f"字段 {item['column']} 存在异常值风险（{item['outlier_rate_%']}%）。",
                "severity": "中",
                "suggestion": "可结合箱线图或业务含义判断是否处理。",
            }
        )

    if not rows:
        rows.append(
            {
                "issue": "未发现明显重复、高缺失或异常值风险。",
                "severity": "低",
                "suggestion": "可以继续进行探索性分析。",
            }
        )
    return rows


def _recommendations(high_missing_columns, outlier_summary, missing_rate):
    rows = []
    if missing_rate > 10:
        rows.append({"recommendation": "优先处理缺失值，避免影响后续统计结论。"})
    if high_missing_columns:
        rows.append({"recommendation": "对高缺失字段单独说明，必要时从分析字段中排除。"})
    if outlier_summary:
        rows.append({"recommendation": "对异常值风险字段使用箱线图或 IQR 方法进一步检查。"})
    rows.append({"recommendation": "报告结论中应说明数据来源、样本范围和主要局限。"})
    rows.append({"recommendation": "相关性结果只能说明关系强弱，不能直接写成因果结论。"})
    return rows
