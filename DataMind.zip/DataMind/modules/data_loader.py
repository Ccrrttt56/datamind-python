"""Data loading utilities.

Source: Student + AI
"""

from pathlib import Path

import pandas as pd


class DataLoadError(ValueError):
    """Raised when an uploaded table cannot be read safely."""


def read_table(uploaded_file):
    """Read a CSV or Excel file into a pandas DataFrame."""
    if uploaded_file is None:
        raise DataLoadError("No file was uploaded.")

    if isinstance(uploaded_file, (str, Path)):
        file_name = str(uploaded_file)
        source = uploaded_file
    else:
        file_name = getattr(uploaded_file, "name", "")
        source = uploaded_file

    suffix = Path(file_name).suffix.lower()
    lower_name = file_name.lower()

    try:
        if suffix == ".csv" or suffix == ".gz" or lower_name.endswith(".csv.gz"):
            return _read_csv_with_encoding_fallback(source)
        if suffix in {".xlsx", ".xls"}:
            return pd.read_excel(source)
    except pd.errors.EmptyDataError as exc:
        raise DataLoadError("The uploaded file is empty.") from exc
    except Exception as exc:
        raise DataLoadError(f"Failed to read table: {exc}") from exc

    raise DataLoadError(
        f"Unsupported file type for {file_name}. Please upload a CSV or Excel file."
    )


def _read_csv_with_encoding_fallback(source):
    """Try common encodings for CSV files."""
    encodings = ["utf-8", "utf-8-sig", "gbk", "gb18030", "latin1"]
    last_error = None

    for encoding in encodings:
        try:
            if hasattr(source, "seek"):
                source.seek(0)
            return pd.read_csv(source, encoding=encoding)
        except UnicodeDecodeError as exc:
            last_error = exc

    raise DataLoadError("Failed to decode CSV file with common encodings.") from last_error
