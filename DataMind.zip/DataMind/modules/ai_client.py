"""Minimal DeepSeek-compatible client for optional AI enhancement.

Source: Student + AI
"""

from __future__ import annotations

import copy
import hashlib
import json
import socket
import urllib.error
import urllib.request

from modules.ai_config import ai_api_key, ai_base_url, ai_model, ai_status, ai_use_system_proxy


CHAT_COMPLETIONS_PATH = "/chat/completions"
AI_RESPONSE_CACHE_VERSION = "ai-response-cache-v1"
AI_RESPONSE_CACHE = {}


def clear_ai_response_cache():
    """Clear cached successful AI responses in the current Python process."""
    AI_RESPONSE_CACHE.clear()


def request_structured_json(prompt, schema, timeout=30):
    """Request structured JSON from a DeepSeek-compatible chat API.

    Returns (data, error). If AI is disabled, missing a key, the network fails,
    or the model returns invalid JSON, data is None and error explains why.
    Successful responses are cached by model, base URL, prompt and schema so
    repeated Streamlit reruns do not ask the model to regenerate the same result.
    """
    status = ai_status()
    if not status["can_call"]:
        return None, status["message"]

    model = ai_model()
    base_url = ai_base_url().rstrip("/")
    body = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": (
                    "You are a strict JSON generator. Return only valid JSON. "
                    "Do not include markdown fences or extra explanations."
                ),
            },
            {"role": "user", "content": prompt},
        ],
        "response_format": {"type": "json_object"},
        "temperature": 0.2,
    }
    cache_key = ai_response_cache_key(prompt, schema, model, base_url, body["temperature"])
    if cache_key in AI_RESPONSE_CACHE:
        return copy.deepcopy(AI_RESPONSE_CACHE[cache_key]), None

    url = base_url + CHAT_COMPLETIONS_PATH
    request = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {ai_api_key()}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    try:
        opener = urllib.request.build_opener() if ai_use_system_proxy() else urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(request, timeout=timeout) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="ignore")
        return None, f"AI 调用失败：HTTP {exc.code} {detail[:300]}"
    except (TimeoutError, socket.timeout):
        return None, "AI 调用失败：请求超时，已使用本地规则兜底。"
    except urllib.error.URLError as exc:
        return None, f"AI 调用失败：{exc}"
    except OSError as exc:
        return None, f"AI 调用失败：{exc}"
    except json.JSONDecodeError:
        return None, "AI 返回内容不是有效 JSON。"

    text = extract_output_text(payload)
    if not text:
        return None, "AI 返回内容为空。"

    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return None, "AI 输出没有匹配预期 JSON 格式。"
    AI_RESPONSE_CACHE[cache_key] = copy.deepcopy(data)
    return data, None


def ai_response_cache_key(prompt, schema, model, base_url, temperature):
    """Build a stable key for a structured AI request."""
    payload = {
        "version": AI_RESPONSE_CACHE_VERSION,
        "model": model,
        "base_url": base_url,
        "temperature": temperature,
        "prompt": str(prompt),
        "schema": schema,
    }
    text = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def extract_output_text(payload):
    """Extract output text from OpenAI-compatible or Responses-style payloads."""
    choices = payload.get("choices", [])
    if choices:
        message = choices[0].get("message", {})
        if message.get("content"):
            return message["content"]

    if "output_text" in payload:
        return payload["output_text"]

    parts = []
    for item in payload.get("output", []):
        for content in item.get("content", []):
            if content.get("type") in {"output_text", "text"} and content.get("text"):
                parts.append(content["text"])
    return "".join(parts)
