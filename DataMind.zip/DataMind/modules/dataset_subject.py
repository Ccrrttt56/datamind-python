"""Dataset subject inference with local fallback and AI extension point.

Source: Student + AI
"""

from __future__ import annotations

import pandas as pd

from modules.ai_client import request_structured_json


def infer_dataset_subject(df):
    """Infer what real-world object the uploaded table may describe."""
    payload = build_ai_subject_payload(df)
    ai_result = infer_subject_with_ai(payload)
    if ai_result:
        ai_result["source"] = "AI 增强识别"
        ai_result["fallback_available"] = True
        return ai_result

    local_result = infer_subject_with_local_rules(df)
    local_result["source"] = "本地规则兜底"
    local_result["fallback_available"] = True
    local_result["ai_status"] = "AI 增强识别当前未启用，系统使用本地规则生成保守判断。"
    local_result["overview_paragraphs"] = local_subject_overview(local_result)
    return local_result


def build_ai_subject_payload(df, sample_rows=3, max_columns=40):
    """Build a compact, non-executable payload for AI subject inference."""
    sampled = df.head(sample_rows).copy()
    if len(sampled.columns) > max_columns:
        sampled = sampled.iloc[:, :max_columns]
    shown_columns = list(sampled.columns)

    return {
        "row_count": int(len(df)),
        "column_count": int(len(df.columns)),
        "columns": [str(column) for column in shown_columns],
        "dtypes": {str(column): str(df[column].dtype) for column in shown_columns},
        "missing_rates": {
            str(column): round(float(df[column].isna().mean() * 100), 2)
            for column in shown_columns
        },
        "top_values": {
            str(column): top_preview_values(df[column])
            for column in shown_columns
            if is_previewable_category(df[column])
        },
        "sample_values": {
            str(column): [safe_preview_value(value) for value in sampled[column].dropna().head(2).tolist()]
            for column in sampled.columns
        },
    }


def infer_subject_with_ai(payload):
    """Infer dataset overview with AI using raw dataset summary only."""
    prompt = build_ai_subject_prompt(payload)
    data, error = request_structured_json(prompt, schema={"overview": "object"}, timeout=25)
    if error or not isinstance(data, dict):
        return None
    overview = data.get("overview", data)
    if not isinstance(overview, dict):
        return None

    paragraphs = [
        clean_overview_sentence(overview.get("data_object", "")),
        clean_overview_sentence(overview.get("information_structure", "")),
        clean_overview_sentence(overview.get("supported_analysis", "")),
    ]
    if any(not paragraph for paragraph in paragraphs):
        return None

    subject = clean_subject_name(overview.get("subject", "AI 识别的数据集"))
    return {
        "subject": subject,
        "confidence": clean_confidence(overview.get("confidence", "中等")),
        "description": paragraphs[0],
        "evidence": "AI 根据字段名、字段类型、缺失比例、少量样例值和高频取值生成概览。",
        "matched_keywords": [],
        "overview_paragraphs": paragraphs,
        "ai_status": "AI 只生成数据内容概览文本，不执行代码，也不参与数据计算。",
    }


def build_ai_subject_prompt(payload):
    """Build a strict prompt for user-facing dataset overview."""
    return f"""
请根据下面的数据表原始摘要，生成面向普通用户的“数据内容概览”。

重要规则：
1. 只返回 JSON，不要 Markdown，不要解释过程。
2. JSON 格式必须为：
{{
  "overview": {{
    "subject": "数据对象的简短名称",
    "confidence": "较高/中等/较低",
    "data_object": "一句话说明这份数据主要记录什么",
    "information_structure": "一句话说明表中包含哪些信息维度",
    "supported_analysis": "一句话说明这些信息可以支持哪些分析"
  }}
}}
3. 只能依据给出的字段名、字段类型、缺失比例、少量样例值和高频取值判断。
4. 不要使用或假设任何本地规则结论；输入中也没有本地规则主题。
5. 不要编造字段中不存在的信息，不要写因果结论。
6. 每个中文句子控制在 90 字以内，语言要面向用户，不能出现“字段名、关键词、可信度、本地规则、AI”等内部说明。
7. data_object 必须直接、具体、明显地说明这份数据介绍或记录了什么，不要写成泛泛的“包含多种信息”。
8. 如果不确定，请使用“可能”“适合初步分析”等保守表达。

数据表原始摘要：
{payload}
""".strip()


def infer_subject_with_local_rules(df):
    """Infer dataset subject using transparent keyword rules."""
    columns = [str(column).lower() for column in df.columns]
    joined = " ".join(columns)

    rules = [
        {
            "subject": "短租房源或住宿平台数据",
            "keywords": [
                "host",
                "room_type",
                "property_type",
                "neighbourhood",
                "neighborhood",
                "availability",
                "minimum_nights",
                "reviews_per_month",
                "listing_url",
            ],
            "evidence": "字段中出现房东、房型、街区、可订天数、最少入住晚数或评论相关信息。",
        },
        {
            "subject": "房地产、房屋或租赁信息数据",
            "keywords": ["price", "rent", "bedroom", "bathroom", "property", "house", "apartment", "address"],
            "evidence": "字段中出现价格、卧室、浴室、房屋类型或地址等信息。",
        },
        {
            "subject": "问卷调查或心理测量数据",
            "keywords": ["age", "gender", "score", "scale", "question", "answer", "survey", "response"],
            "evidence": "字段中出现年龄、性别、得分、量表、问题或回答等信息。",
        },
        {
            "subject": "销售订单或客户交易数据",
            "keywords": ["order", "customer", "product", "sales", "revenue", "quantity", "invoice"],
            "evidence": "字段中出现订单、客户、商品、销售额、收入或数量等信息。",
        },
        {
            "subject": "学生成绩或课程学习数据",
            "keywords": ["student", "course", "grade", "score", "class", "exam", "homework"],
            "evidence": "字段中出现学生、课程、成绩、班级、考试或作业等信息。",
        },
        {
            "subject": "时间序列或监测记录数据",
            "keywords": ["date", "time", "timestamp", "temperature", "sensor", "measurement", "value"],
            "evidence": "字段中出现时间、传感器、测量值或连续记录等信息。",
        },
    ]

    scored = []
    for rule in rules:
        matched = [keyword for keyword in rule["keywords"] if keyword in joined]
        if matched:
            scored.append((len(matched), matched, rule))

    if scored:
        _, matched, rule = sorted(scored, key=lambda item: item[0], reverse=True)[0]
        confidence = "较高" if len(matched) >= 4 else "中等"
        return {
            "subject": rule["subject"],
            "confidence": confidence,
            "description": f"这份数据可能描述的是{rule['subject']}。",
            "evidence": rule["evidence"],
            "matched_keywords": matched[:8],
        }

    return {
        "subject": "通用表格数据",
        "confidence": "较低",
        "description": "这份数据的具体对象暂时无法仅靠本地规则准确判断。",
        "evidence": "当前字段名没有明显命中已内置的数据类型规则。",
        "matched_keywords": [],
    }


def safe_preview_value(value, max_length=80):
    """Return a short text preview safe for AI prompts and UI display."""
    text = str(value).replace("\n", " ").replace("\r", " ").strip()
    if len(text) > max_length:
        return text[:max_length] + "..."
    return text


def top_preview_values(series, limit=5):
    """Return compact frequent values for short categorical columns."""
    values = series.dropna().astype(str)
    if values.empty:
        return []
    return [
        safe_preview_value(value)
        for value in values.value_counts().head(limit).index.tolist()
    ]


def is_previewable_category(series):
    """Return whether a column should provide top values to AI."""
    if pd.api.types.is_numeric_dtype(series):
        return False
    values = series.dropna().astype(str)
    if values.empty:
        return False
    unique_count = values.nunique()
    if unique_count > 30:
        return False
    average_length = values.map(len).mean()
    return average_length <= 60


def clean_overview_sentence(text, max_length=120):
    """Normalize one AI-generated overview sentence."""
    text = str(text).replace("\n", " ").replace("\r", " ").strip()
    text = " ".join(text.split())
    if not text:
        return ""
    if len(text) > max_length:
        text = text[:max_length].rstrip("，。；、 ") + "。"
    return text


def clean_subject_name(text):
    """Normalize the AI subject label."""
    text = str(text).strip()
    if not text:
        return "AI 识别的数据集"
    return text[:40]


def clean_confidence(text):
    """Restrict confidence to known labels."""
    text = str(text).strip()
    if text in {"较高", "中等", "较低"}:
        return text
    return "中等"


def local_subject_overview(subject):
    """Return conservative fallback overview paragraphs from local rules."""
    subject_name = subject.get("subject", "通用表格数据")
    paragraphs = [
        f"这份数据可能主要记录{subject_name}。",
        "数据中包含若干类别、数值、时间或文本信息，可用于对表格内容做初步理解。",
    ]
    if subject_name == "短租房源或住宿平台数据":
        paragraphs[1] = "数据中可能包含房源属性、位置区域、价格费用、房东信息、评论评分和可订状态等信息。"
        paragraphs.append("这些信息适合初步分析房型构成、区域差异、价格分布、评论活跃度和可订情况。")
    elif subject_name == "房地产、房屋或租赁信息数据":
        paragraphs[1] = "数据中可能包含房屋属性、位置区域、价格费用和居住条件等信息。"
        paragraphs.append("这些信息适合初步分析区域差异、价格分布、房屋类型和居住条件之间的关系。")
    elif subject_name == "问卷调查或心理测量数据":
        paragraphs[1] = "数据中可能包含受访者特征、问题回答、得分或量表结果等信息。"
        paragraphs.append("这些信息适合初步分析回答分布、群体差异、得分水平和变量之间的关系。")
    elif subject_name == "销售订单或客户交易数据":
        paragraphs[1] = "数据中可能包含订单、客户、商品、数量、金额或时间等信息。"
        paragraphs.append("这些信息适合初步分析销售规模、商品表现、客户差异和订单变化。")
    elif subject_name == "学生成绩或课程学习数据":
        paragraphs[1] = "数据中可能包含学生、课程、成绩、考试或作业等信息。"
        paragraphs.append("这些信息适合初步分析成绩分布、课程差异、学生表现和相关影响因素。")
    else:
        paragraphs.append("这些信息适合先进行类别分布、数值分布、分组对比、缺失情况和相关性探索。")
    return paragraphs
