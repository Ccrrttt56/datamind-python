"""Dataset profiling utilities.

Source: Student + AI
"""

import pandas as pd


def profile_table(df):
    """Build a basic profile for a DataFrame."""
    missing_counts = df.isna().sum()
    missing_rates = (missing_counts / len(df) * 100) if len(df) else missing_counts
    duplicate_rows = int(df.duplicated().sum())

    return {
        "rows": len(df),
        "columns": len(df.columns),
        "column_names": list(df.columns),
        "dtypes": {column: str(dtype) for column, dtype in df.dtypes.items()},
        "missing_counts": missing_counts.astype(int).to_dict(),
        "missing_rates": missing_rates.round(2).to_dict(),
        "duplicate_rows": duplicate_rows,
        "numeric_columns": list(df.select_dtypes(include="number").columns),
        "datetime_columns": list(df.select_dtypes(include=["datetime", "datetimetz"]).columns),
        "text_columns": list(df.select_dtypes(include=["object", "string"]).columns),
    }


def dtype_summary(df):
    """Return a compact table of column data types and missing values."""
    profile = profile_table(df)
    return pd.DataFrame(
        {
            "column": profile["column_names"],
            "dtype": [profile["dtypes"][column] for column in profile["column_names"]],
            "missing_count": [
                profile["missing_counts"][column] for column in profile["column_names"]
            ],
            "missing_rate_%": [
                profile["missing_rates"][column] for column in profile["column_names"]
            ],
        }
    )


def numeric_summary(df):
    """Return descriptive statistics for numeric columns."""
    numeric_df = df.select_dtypes(include="number")
    if numeric_df.empty:
        return pd.DataFrame()
    return numeric_df.describe().T.reset_index().rename(columns={"index": "column"})
