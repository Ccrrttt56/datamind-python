"""AI configuration switch and status helpers.

Source: Student + AI
"""

from __future__ import annotations

import os
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]
ENV_PATH = PROJECT_ROOT / ".env"


def load_env_file(path=None):
    """Load simple KEY=VALUE pairs from a local .env file without extra deps."""
    path = path or ENV_PATH
    values = {}
    if not path.exists():
        return values

    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key:
            values[key] = value
    return values


def get_config_value(name, default=""):
    """Read config from environment variables first, then .env."""
    if name in os.environ:
        return os.environ.get(name, default)
    return load_env_file().get(name, default)


def is_truthy(value):
    """Return True for common enabled values."""
    return str(value).strip().lower() in {"1", "true", "yes", "y", "on", "启用", "开启"}


def ai_enabled():
    """Return whether AI calls are allowed by configuration."""
    return is_truthy(get_config_value("DATAMIND_AI_ENABLED", "false"))


def ai_api_key():
    """Return the configured AI API key, if any."""
    return (
        get_config_value("DATAMIND_AI_API_KEY", "")
        or get_config_value("DEEPSEEK_API_KEY", "")
        or get_config_value("OPENAI_API_KEY", "")
    )


def ai_provider():
    """Return the configured AI provider name."""
    return get_config_value("DATAMIND_AI_PROVIDER", "DeepSeek")


def ai_model():
    """Return the configured AI model name."""
    return get_config_value("DATAMIND_AI_MODEL", "deepseek-chat")


def ai_base_url():
    """Return the configured AI base URL."""
    return get_config_value("DATAMIND_AI_BASE_URL", "https://api.deepseek.com")


def ai_use_system_proxy():
    """Return whether AI requests should use system proxy variables."""
    return is_truthy(get_config_value("DATAMIND_AI_USE_SYSTEM_PROXY", "false"))


def debug_mode_enabled():
    """Return whether developer debug UI/logging is enabled."""
    return is_truthy(get_config_value("DATAMIND_DEBUG_MODE", "false"))


def ai_status():
    """Return a user-facing AI status summary."""
    enabled = ai_enabled()
    has_key = bool(ai_api_key())
    if not enabled:
        state = "未启用"
        message = "当前使用本地规则，不调用外部 AI。"
        can_call = False
    elif not has_key:
        state = "已开启但缺少 API Key"
        message = "已打开 AI 开关，但没有配置 DATAMIND_AI_API_KEY 或 DEEPSEEK_API_KEY，系统会继续使用本地规则兜底。"
        can_call = False
    else:
        state = "可调用"
        message = "AI 开关已开启且 API Key 已配置。后续 AI 功能会先生成建议，再经过本地 Skill 校验。"
        can_call = True

    return {
        "enabled": enabled,
        "has_api_key": has_key,
        "can_call": can_call,
        "provider": ai_provider(),
        "model": ai_model(),
        "base_url": ai_base_url(),
        "use_system_proxy": ai_use_system_proxy(),
        "debug_mode": debug_mode_enabled(),
        "state": state,
        "message": message,
    }
