"""Field semantic detection utilities.

Source: Student + AI
"""

import pandas as pd


SEMANTIC_KEYWORDS = {
    "时间字段": ["date", "time", "year", "month", "day", "scraped", "日期", "时间", "年份", "月份"],
    "金额/价格字段": ["price", "cost", "fee", "amount", "sales", "revenue", "单价", "价格", "金额", "销售额"],
    "数量字段": ["quantity", "count", "number", "nights", "accommodates", "beds", "bedrooms", "数量", "次数"],
    "地区字段": ["country", "city", "region", "neighbourhood", "neighborhood", "location", "地区", "城市", "国家"],
    "ID 字段": ["id", "code", "no", "url", "编号", "编码"],
    "类别字段": ["type", "category", "room", "property", "source", "类别", "类型"],
    "评分字段": ["score", "rating", "review_scores", "评分", "得分"],
    "经纬度字段": ["latitude", "longitude", "lat", "lng", "lon", "经度", "纬度"],
    "文本描述字段": ["name", "description", "about", "overview", "comments", "名称", "描述"],
}


def detect_field_semantics(df):
    """Detect semantic roles for columns based on names, dtypes, and simple stats."""
    rows = []
    for column in df.columns:
        semantic = detect_column_semantic(df, column)
        rows.append(
            {
                "column": column,
                "dtype": str(df[column].dtype),
                "semantic_role": semantic,
                "missing_rate_%": round(float(df[column].isna().mean() * 100), 2),
                "unique_count": int(df[column].nunique(dropna=True)),
            }
        )
    return pd.DataFrame(rows)


def detect_column_semantic(df, column):
    """Detect one column's semantic role."""
    name = str(column).lower()
    series = df[column]

    for role, keywords in SEMANTIC_KEYWORDS.items():
        if any(keyword in name for keyword in keywords):
            return role

    if pd.api.types.is_datetime64_any_dtype(series):
        return "时间字段"

    if pd.api.types.is_numeric_dtype(series):
        unique_ratio = series.nunique(dropna=True) / max(len(series), 1)
        if unique_ratio < 0.05:
            return "类别字段"
        return "数值字段"

    if pd.api.types.is_bool_dtype(series):
        return "类别字段"

    if series.nunique(dropna=True) <= min(30, max(len(series) * 0.1, 1)):
        return "类别字段"

    return "文本字段"
