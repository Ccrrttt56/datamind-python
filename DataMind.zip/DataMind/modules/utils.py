"""Shared utility functions.

Source: Student + AI
"""


def safe_filename(name):
    """Return a simple safe filename."""
    return "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in name)
