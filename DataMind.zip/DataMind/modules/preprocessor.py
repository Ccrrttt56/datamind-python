"""Data cleaning and preprocessing utilities.

Source: Student + AI
"""

import pandas as pd


DATE_KEYWORDS = ["date", "time", "year", "month", "day", "日期", "时间", "年份", "月份"]
TEXT_HEAVY_KEYWORDS = ["description", "overview", "about", "comment", "comments", "amenities", "name"]


def clean_table(
    df,
    drop_duplicates=True,
    convert_types=True,
    strip_text=True,
    empty_string_as_missing=True,
    standardize_category_values=False,
    handle_nonpositive=True,
    outlier_strategy="mark",
    outlier_strategies_by_column=None,
    numeric_fill="median",
    category_fill="Unknown",
    drop_high_missing=False,
    high_missing_threshold=0.6,
):
    """Clean a DataFrame and return the cleaned data with a processing log."""
    cleaned = df.copy()
    log = []

    if cleaned.empty:
        return cleaned, ["数据为空，未执行清洗。"]

    if strip_text or empty_string_as_missing:
        cleaned, text_log = clean_text_format(
            cleaned,
            strip_text=strip_text,
            empty_string_as_missing=empty_string_as_missing,
        )
        log.extend(text_log)

    if standardize_category_values:
        cleaned, category_log = standardize_category_text_values(cleaned)
        log.extend(category_log)

    if drop_duplicates:
        before_rows = len(cleaned)
        cleaned = cleaned.drop_duplicates()
        removed = before_rows - len(cleaned)
        if removed:
            log.append(f"删除重复行 {removed} 行。")
        else:
            log.append("未发现重复行。")

    if drop_high_missing:
        missing_rates = cleaned.isna().mean()
        drop_columns = missing_rates[missing_rates > high_missing_threshold].index.tolist()
        if drop_columns:
            cleaned = cleaned.drop(columns=drop_columns)
            log.append(
                f"删除缺失比例超过 {int(high_missing_threshold * 100)}% 的字段："
                + "、".join(drop_columns)
                + "。"
            )

    if convert_types:
        cleaned, convert_log = auto_convert_types(cleaned)
        log.extend(convert_log)

    if handle_nonpositive:
        cleaned, nonpositive_log = handle_nonpositive_values(cleaned)
        log.extend(nonpositive_log)

    if outlier_strategy and outlier_strategy != "none" or outlier_strategies_by_column:
        cleaned, outlier_log = handle_outliers(
            cleaned,
            strategy=outlier_strategy,
            strategies_by_column=outlier_strategies_by_column,
        )
        log.extend(outlier_log)

    cleaned, fill_log = fill_missing_values(
        cleaned,
        numeric_strategy=numeric_fill,
        category_strategy=category_fill,
    )
    log.extend(fill_log)

    if not log:
        log.append("未执行任何清洗操作。")

    return cleaned, log


def clean_text_format(df, strip_text=True, empty_string_as_missing=True):
    """Clean text spacing and blank values."""
    cleaned = df.copy()
    log = []
    text_columns = list(cleaned.select_dtypes(include=["object", "string"]).columns)
    stripped_cells = 0
    blank_cells = 0

    for column in text_columns:
        original = cleaned[column]
        text = original.astype("string")
        if strip_text:
            stripped = text.str.strip()
            changed = original.notna() & (text != stripped)
            stripped_cells += int(changed.sum())
            text = stripped
        if empty_string_as_missing:
            blank_mask = text.notna() & (text.str.strip() == "")
            blank_cells += int(blank_mask.sum())
            text = text.mask(blank_mask, pd.NA)
        cleaned[column] = text

    if strip_text:
        log.append(f"文本格式整理：去除前后空格 {stripped_cells} 处。")
    if empty_string_as_missing:
        log.append(f"文本格式整理：将空字符串统一为缺失值 {blank_cells} 处。")
    return cleaned, log


def standardize_category_text_values(df, max_unique=100):
    """Merge category values that only differ by spaces or letter case."""
    cleaned = df.copy()
    log = []
    for column in cleaned.select_dtypes(include=["object", "string"]).columns:
        series = cleaned[column].dropna().astype(str)
        if series.empty or series.nunique() > max_unique:
            continue
        normalized = series.str.strip().str.casefold()
        canonical = {}
        for key in normalized.unique():
            values = series[normalized == key].str.strip()
            if values.empty:
                continue
            canonical[key] = values.value_counts().index[0]
        new_values = cleaned[column].astype("string")
        mapped = new_values.dropna().astype(str).str.strip().str.casefold().map(canonical)
        changed_index = mapped.index[mapped.notna() & (new_values.loc[mapped.index].astype(str) != mapped)]
        if len(changed_index):
            cleaned.loc[mapped.index, column] = mapped
            log.append(f"字段 {column} 已合并 {len(changed_index)} 个大小写或空格差异导致的类别值。")
    if not log:
        log.append("未发现需要合并的类别大小写或空格差异。")
    return cleaned, log


def handle_outliers(df, strategy="mark", strategies_by_column=None):
    """Mark or handle numeric outliers with IQR rules."""
    cleaned = df.copy()
    log = []
    strategies_by_column = strategies_by_column or {}
    for column in cleaned.select_dtypes(include="number").columns:
        column_strategy = strategies_by_column.get(column, strategy)
        if column_strategy == "default":
            column_strategy = strategy
        if not column_strategy or column_strategy == "none":
            continue

        series = pd.to_numeric(cleaned[column], errors="coerce")
        clean_series = series.dropna()
        if len(clean_series) < 8:
            continue
        mask, lower, upper = iqr_outlier_mask(clean_series)
        outlier_index = clean_series[mask].index
        count = len(outlier_index)
        if count == 0:
            continue

        if column_strategy == "mark":
            cleaned[f"{column}_是否极端值"] = False
            cleaned.loc[outlier_index, f"{column}_是否极端值"] = True
            log.append(f"字段 {column} 标记 {count} 条极端值记录，原值保留。")
        elif column_strategy == "missing":
            cleaned.loc[outlier_index, column] = pd.NA
            log.append(f"字段 {column} 将 {count} 条极端值替换为缺失值，后续按缺失值策略处理。")
        elif column_strategy == "winsorize":
            if pd.api.types.is_integer_dtype(cleaned[column]):
                cleaned[column] = cleaned[column].astype(float)
            cleaned.loc[series < lower, column] = lower
            cleaned.loc[series > upper, column] = upper
            log.append(f"字段 {column} 对 {count} 条极端值执行截尾处理，限制在常见范围内。")

    if not log:
        log.append("未发现需要处理的明显极端值。")
    return cleaned, log


def iqr_outlier_mask(series):
    """Return IQR outlier mask and bounds for a numeric series."""
    q1 = series.quantile(0.25)
    q3 = series.quantile(0.75)
    iqr = q3 - q1
    if iqr == 0:
        return pd.Series(False, index=series.index), q1, q3
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    return (series < lower) | (series > upper), lower, upper


def auto_convert_types(df):
    """Try converting object columns to numeric or datetime types."""
    converted = df.copy()
    log = []

    for column in converted.select_dtypes(include=["object", "string"]).columns:
        series = converted[column]
        non_null_count = int(series.notna().sum())
        if non_null_count == 0:
            continue

        normalized_series = normalize_numeric_text(series)
        numeric_series = pd.to_numeric(normalized_series, errors="coerce")
        numeric_success_rate = numeric_series.notna().sum() / non_null_count
        if numeric_success_rate >= 0.9:
            converted[column] = numeric_series
            log.append(f"字段 {column} 已自动转换为数值类型。")
            continue

        if should_try_datetime_conversion(column, series):
            datetime_series = pd.to_datetime(series, errors="coerce")
            datetime_success_rate = datetime_series.notna().sum() / non_null_count
            if datetime_success_rate >= 0.9:
                converted[column] = datetime_series
                log.append(f"字段 {column} 已自动转换为日期时间类型。")

    return converted, log


def should_try_datetime_conversion(column, series):
    """Avoid expensive date parsing on long descriptive text columns."""
    name = str(column).lower()
    if any(keyword in name for keyword in TEXT_HEAVY_KEYWORDS):
        return False
    if any(keyword in name for keyword in DATE_KEYWORDS):
        return True

    sample = series.dropna().astype(str).head(30)
    if sample.empty:
        return False
    average_length = sample.str.len().mean()
    if average_length > 30:
        return False
    date_like = sample.str.contains(r"\d{4}[-/]\d{1,2}[-/]\d{1,2}", regex=True).mean()
    return date_like >= 0.6


def normalize_numeric_text(series):
    """Normalize common numeric text formats such as currency and percentages."""
    text = series.astype("string").str.strip()
    text = text.str.replace(r"^\((.*)\)$", r"-\1", regex=True)
    text = text.str.replace(",", "", regex=False)
    text = text.str.replace(r"[$€£¥￥]", "", regex=True)
    text = text.str.replace("%", "", regex=False)
    return text


def handle_nonpositive_values(df):
    """Mark clearly invalid non-positive values in price and quantity fields as missing."""
    cleaned = df.copy()
    log = []

    for column in cleaned.select_dtypes(include="number").columns:
        lower_name = str(column).lower()
        rule = nonpositive_rule_for_column(lower_name)
        if rule is None:
            continue

        if rule == "nonpositive":
            invalid_mask = cleaned[column] <= 0
            description = "小于等于 0"
        else:
            invalid_mask = cleaned[column] < 0
            description = "小于 0"

        invalid_count = int(invalid_mask.sum())
        if invalid_count:
            cleaned.loc[invalid_mask, column] = float("nan")
            log.append(f"字段 {column} 中 {invalid_count} 个{description}的值已标记为缺失，后续按缺失值策略处理。")

    if not log:
        log.append("未发现需要处理的价格/数量非正值。")
    return cleaned, log


def nonpositive_rule_for_column(name):
    """Return how to handle non-positive values for a numeric field."""
    safe_zero_tokens = ["availability", "review", "rating", "score", "rate", "count_reviews"]
    if any(token in name for token in safe_zero_tokens):
        return None

    price_tokens = ["price", "cost", "fee", "amount", "revenue", "sales", "unitprice"]
    quantity_tokens = ["quantity", "qty", "number", "nights", "beds", "bedrooms", "bathrooms", "accommodates"]

    if any(token in name for token in price_tokens):
        return "nonpositive"
    if any(token in name for token in quantity_tokens):
        return "nonpositive"
    return None


def fill_missing_values(df, numeric_strategy="median", category_strategy="Unknown"):
    """Fill missing values for numeric, datetime, and category-like columns."""
    filled = df.copy()
    log = []
    if numeric_strategy == "none" and category_strategy == "none":
        log.append("已选择不填充缺失值，缺失内容保持原样。")
        return filled, log

    for column in filled.columns:
        missing_count = int(filled[column].isna().sum())
        if missing_count == 0:
            continue

        if pd.api.types.is_numeric_dtype(filled[column]):
            if numeric_strategy == "none":
                log.append(f"字段 {column} 保留 {missing_count} 个数值缺失值。")
                continue
            if numeric_strategy == "mean":
                value = filled[column].mean()
                strategy_name = "均值"
            else:
                value = filled[column].median()
                strategy_name = "中位数"

            if pd.isna(value):
                log.append(f"字段 {column} 全部为空，无法使用{strategy_name}填充。")
                continue

            filled[column] = filled[column].fillna(value)
            log.append(f"字段 {column} 使用{strategy_name}填充 {missing_count} 个缺失值。")
            continue

        if pd.api.types.is_datetime64_any_dtype(filled[column]):
            log.append(f"字段 {column} 为日期字段，保留 {missing_count} 个缺失值。")
            continue

        if category_strategy == "none":
            log.append(f"字段 {column} 保留 {missing_count} 个类别/文本缺失值。")
            continue

        if category_strategy == "mode":
            mode_values = filled[column].mode(dropna=True)
            value = mode_values.iloc[0] if not mode_values.empty else "Unknown"
            strategy_name = "众数"
        else:
            value = "Unknown"
            strategy_name = "Unknown"

        filled[column] = filled[column].fillna(value)
        log.append(f"字段 {column} 使用{strategy_name}填充 {missing_count} 个缺失值。")

    if not log:
        log.append("未发现需要填充的缺失值。")

    return filled, log
