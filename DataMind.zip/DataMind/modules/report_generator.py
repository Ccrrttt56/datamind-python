"""Report generation helpers.

Source: Student + AI
"""


def build_markdown_report(title, sections):
    """Build a simple Markdown report from named sections."""
    lines = [f"# {title}", ""]
    for heading, content in sections:
        lines.extend([f"## {heading}", str(content), ""])
    return "\n".join(lines)
