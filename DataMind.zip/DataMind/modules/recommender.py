"""Question and chart recommendation utilities.

Source: Student + AI
"""

import pandas as pd

from modules.ai_client import request_structured_json
from modules.ai_config import ai_status
from modules.dataset_subject import infer_dataset_subject
from modules.field_translator import local_translate_field_name
from modules.qa_engine import parse_question
from modules.semantic_detector import detect_field_semantics
from modules.skill_registry import allowed_skill_ids, get_skill, validate_skill_instruction


HIGH_MISSING_FIELD_RATE = 40.0

LAST_RECOMMENDATION_STATUS = {
    "provider": "local",
    "used_ai": False,
    "fallback": False,
    "message": "当前使用本地规则推荐问题。",
}

LAST_DIRECTION_STATUS = {
    "provider": "local",
    "used_ai": False,
    "fallback": False,
    "message": "当前使用本地规则推荐分析方向。",
}

ALLOWED_ANALYSIS_ENTRIES = {
    "清洗预处理 → 清洗设置",
    "清洗预处理 → 极端值影响",
    "统计可视化 → 分析向导",
    "统计可视化 → 基础图表分析 → 类别分布",
    "统计可视化 → 基础图表分析 → 分组对比",
    "统计可视化 → 基础图表分析 → 数值分布",
    "统计可视化 → 基础图表分析 → 趋势变化",
    "统计可视化 → 基础图表分析 → 关系分析",
    "统计可视化 → 基础图表分析 → 缺失情况",
    "统计可视化 → 高级分析 → 智能分群",
    "统计可视化 → 高级分析 → 文本词云",
    "自然语言问答 → 提问向导",
    "分析报告 → 生成报告",
}


def recommend_questions(df, limit=8, provider="auto"):
    """Recommend natural-language analysis questions for the current dataset.

    The provider argument reserves the AI recommendation interface. The current
    project does not call an external AI service, so "auto" falls back to local
    deterministic rules. Later, generate_ai_question_recommendations can be
    wired to an AI client without changing the Streamlit page or QA executor.
    """
    global LAST_RECOMMENDATION_STATUS
    status = ai_status()
    if provider == "ai" and not status["can_call"]:
        LAST_RECOMMENDATION_STATUS = {
            "provider": "ai",
            "used_ai": False,
            "fallback": False,
            "message": "AI 当前不可调用，无法生成 AI 推荐问题。",
        }
        return empty_question_recommendations()

    if provider in ["auto", "ai"] and status["can_call"]:
        ai_questions, ai_message = generate_ai_question_recommendations(df, limit=limit)
        if ai_questions is not None and not ai_questions.empty:
            LAST_RECOMMENDATION_STATUS = {
                "provider": "ai",
                "used_ai": True,
                "fallback": False,
                "message": "AI 推荐已生成，并已通过本地字段和 Skill 校验。",
            }
            normalized = _normalize_question_recommendations(ai_questions, limit=limit, source="AI 预留接口")
            return sanitize_question_recommendations(df, normalized).head(limit).reset_index(drop=True)
        if provider == "ai":
            LAST_RECOMMENDATION_STATUS = {
                "provider": "ai",
                "used_ai": False,
                "fallback": False,
                "message": ai_message or "AI 未返回可用推荐问题。",
            }
            return empty_question_recommendations()

        LAST_RECOMMENDATION_STATUS = {
            "provider": "local",
            "used_ai": False,
            "fallback": True,
            "message": ai_message or "AI 未返回可用推荐问题，已使用本地规则兜底。",
        }
    else:
        LAST_RECOMMENDATION_STATUS = {
            "provider": "local",
            "used_ai": False,
            "fallback": False,
            "message": "当前使用本地规则推荐问题。",
        }

    local_questions = local_question_recommendations(df, limit=limit)
    return sanitize_question_recommendations(df, local_questions).head(limit).reset_index(drop=True)


def recommendation_status():
    """Return status for the most recent question recommendation run."""
    return LAST_RECOMMENDATION_STATUS.copy()


def recommend_analysis_directions(df, limit=3, provider="auto"):
    """Recommend user-facing analysis directions with AI and local fallback."""
    global LAST_DIRECTION_STATUS
    status = ai_status()
    if provider == "ai" and not status["can_call"]:
        LAST_DIRECTION_STATUS = {
            "provider": "ai",
            "used_ai": False,
            "fallback": False,
            "message": "AI 当前不可调用，无法生成 AI 推荐分析方向。",
        }
        return []

    if provider in ["auto", "ai"] and status["can_call"]:
        directions, message = generate_ai_analysis_directions(df, limit=limit)
        if directions:
            LAST_DIRECTION_STATUS = {
                "provider": "ai",
                "used_ai": True,
                "fallback": False,
                "message": "AI 推荐分析方向已生成，并通过本地字段和入口校验。",
            }
            return directions[:limit]
        if provider == "ai":
            LAST_DIRECTION_STATUS = {
                "provider": "ai",
                "used_ai": False,
                "fallback": False,
                "message": message or "AI 未返回可用分析方向。",
            }
            return []

        LAST_DIRECTION_STATUS = {
            "provider": "local",
            "used_ai": False,
            "fallback": True,
            "message": message or "AI 未返回可用分析方向，已使用本地规则兜底。",
        }
    else:
        LAST_DIRECTION_STATUS = {
            "provider": "local",
            "used_ai": False,
            "fallback": False,
            "message": "当前使用本地规则推荐分析方向。",
        }
    return []


def analysis_direction_status():
    """Return status for the most recent analysis direction recommendation."""
    return LAST_DIRECTION_STATUS.copy()


def generate_ai_analysis_directions(df, limit=3):
    """Generate analysis directions with AI and local validation."""
    payload = build_ai_direction_payload(df, limit=limit)
    prompt = (
        "你是 DataMind 的数据分析方向推荐器。请根据下面的数据摘要，推荐用户最值得优先看的分析方向。"
        "你只能推荐当前网页真实存在的入口，不能编造新功能；不能生成代码，不能执行分析。"
        "推荐必须贴合字段含义和用户理解数据的需求。"
        "这些文字会直接展示给普通用户，请使用清楚、自然、面向用户的中文表达。"
        "不要写内部实现、字段校验、白名单、Skill、groupby、聚合函数等技术词。"
        "不要解释某个字段为什么没有使用，也不要写“因为某字段缺失所以改用另一个字段”这类内部处理过程。"
        "如果某个字段不适合推荐，直接围绕可用字段生成自然的推荐方向，不要在标题、原因或产出里提到被排除字段。"
        "推荐方向必须值得研究、有实际分析意义，不能只是泛泛描述字段；各个方向要有不同侧重，尽量覆盖不同对象、字段组合和分析角度。"
        "三个推荐方向最好覆盖不同分析方法或不同功能入口，尽量不要出现两个相同入口的方法，例如不要同时给出两个分组对比。"
        "推荐方向只能围绕数据摘要 fields 中列出的字段生成；excluded_fields 中的字段不要用于推荐方向。"
        f"不要推荐涉及缺失率达到 {HIGH_MISSING_FIELD_RATE:.0f}% 或全部缺失的字段的分析方向，除非推荐入口本身就是缺失情况分析。"
        "如果必须提到英文字段名，请把它自然放在句子中，页面会自动补充中文含义。\n\n"
        f"允许推荐的入口：{sorted(ALLOWED_ANALYSIS_ENTRIES)}\n\n"
        f"数据摘要：{payload}\n\n"
        "必须只返回 JSON，格式为："
        '{"directions":[{"title":"...","reason":"...","entry":"统计可视化 → 基础图表分析 → 分组对比","fields":["字段名"],"output":"用户会得到什么"}]}'
    )
    data, error = request_structured_json(prompt, analysis_direction_schema())
    if error or not data:
        return None, error or "AI 没有返回数据。"
    rows = data.get("directions", [])
    filtered = filter_ai_direction_rows(rows, df)
    if not filtered:
        return None, "AI 返回的分析方向未通过本地字段或入口校验。"
    return filtered[:limit], None


def build_ai_direction_payload(df, limit=3):
    """Build raw dataset summary for AI analysis direction recommendations."""
    semantics = detect_field_semantics(df)
    fields = []
    excluded_fields = []
    for _, row in semantics.head(80).iterrows():
        item = {
            "column": str(row["column"]),
            "semantic_role": str(row["semantic_role"]),
            "dtype": str(row["dtype"]),
            "missing_rate_%": float(row["missing_rate_%"]),
            "unique_count": int(row["unique_count"]),
        }
        if field_is_recommendation_usable(row):
            fields.append(item)
        else:
            excluded_fields.append(
                {
                    "column": item["column"],
                    "reason": "missing_or_identifier",
                    "missing_rate_%": item["missing_rate_%"],
                    "semantic_role": item["semantic_role"],
                }
            )
        if len(fields) >= 40:
            break
    return {
        "row_count": int(len(df)),
        "column_count": int(len(df.columns)),
        "fields": fields,
        "excluded_fields": excluded_fields[:20],
        "max_directions": int(limit),
    }


def analysis_direction_schema():
    """Return the JSON schema expected from AI analysis directions."""
    return {
        "name": "datamind_analysis_directions",
        "schema": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "directions": {
                    "type": "array",
                    "maxItems": 5,
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "title": {"type": "string"},
                            "reason": {"type": "string"},
                            "entry": {"type": "string"},
                            "fields": {"type": "array", "items": {"type": "string"}},
                            "output": {"type": "string"},
                        },
                        "required": ["title", "reason", "entry", "fields", "output"],
                    },
                }
            },
            "required": ["directions"],
        },
    }


def filter_ai_direction_rows(rows, df):
    """Keep AI directions that use known fields and whitelisted entries."""
    columns = {str(column) for column in df.columns}
    filtered = []
    used_entries = set()
    for row in rows:
        title = str(row.get("title", "")).strip()
        reason = str(row.get("reason", "")).strip()
        entry = str(row.get("entry", "")).strip()
        fields = [str(field).strip() for field in row.get("fields", []) if str(field).strip()]
        output = str(row.get("output", "")).strip()
        if not title or not reason or not entry:
            continue
        if entry not in ALLOWED_ANALYSIS_ENTRIES:
            continue
        if entry in used_entries:
            continue
        if fields and any(field not in columns for field in fields):
            continue
        display_text = " ".join([title, reason, output])
        text_fields = question_referenced_fields(df, display_text)
        referenced_fields = list(dict.fromkeys([*fields, *text_fields]))
        if referenced_fields and any(field not in columns for field in referenced_fields):
            continue
        if referenced_fields and fields_not_suitable_for_recommendation(df, referenced_fields) and "缺失情况" not in entry:
            continue
        used_entries.add(entry)
        filtered.append(
            {
                "行动": title[:80],
                "为什么": reason[:160],
                "入口": entry,
                "产出": output[:120] or "得到适合当前数据的图表或分析结果。",
                "字段": referenced_fields,
                "来源": "AI 推荐 + 本地校验",
            }
        )
    return filtered


def generate_ai_question_recommendations(df, limit=8, context=None):
    """Reserved AI hook for question recommendations.

    Future AI integration should pass only a safe dataset summary to the model,
    such as column names, inferred roles, missing rates, sample-size metadata and
    a few masked example values. The AI output should be normalized into the
    columns: question, reason and method. It should not execute code or decide
    final calculations; actual answers still go through the controlled QA engine.
    """
    payload = build_ai_question_payload(df, limit=limit)
    prompt = (
        "你是 DataMind 的数据分析问题推荐器。请只根据下面的数据摘要推荐用户最值得先问的问题。"
        "不要编造字段，不要生成代码，不要提出当前 Skill 白名单无法执行的问题。"
        "问题必须使用原始字段名，方便系统后续解析和校验。\n\n"
        f"数据摘要：{payload}\n\n"
        "请优先推荐贴合数据主题、关键字段和数据质量风险的问题。"
        "多个推荐问题必须尽可能多样且有意义：分析方案不要重复，例如不要都是 Top N、不要都是分组对比；涉及字段也要尽量多样。"
        "每个问题都应该值得用户进一步研究，能够帮助用户理解数据里的结构、差异、关系、风险或值得解释的现象。"
        "推荐问题只能围绕数据摘要 fields 中列出的字段生成；不要因为 subject 或 subject_description 提到某个业务概念，就推荐 fields 中没有列出的字段或概念。"
        "不要在问题里提出一个字段或概念，却在 fields 中换成另一个字段来执行；如果当前没有对应字段，就不要推荐这个问题。"
        "fields 必须完整列出这个问题实际需要使用的原始字段名，不能只写一部分字段。"
        "例如 groupby_agg 必须同时包含分组字段和数值字段，outlier_detection 必须包含被检查的数值字段，trend_analysis 必须包含时间字段和数值字段。"
        f"如果问题需要分析某个字段的具体取值、均值、相关性、趋势或分组差异，不要推荐缺失率达到 {HIGH_MISSING_FIELD_RATE:.0f}% 或全部缺失的字段；只有缺失值检查类问题可以涉及高缺失字段。"
        "你必须只返回一个 JSON 对象，格式为："
        '{"questions":[{"question":"...","reason":"...","method":"...","priority":"优先","skill_id":"groupby_agg","fields":["字段名"]}]}'
    )
    data, error = request_structured_json(prompt, question_recommendation_schema())
    if error or not data:
        return None, error or "AI 没有返回数据。"
    rows = data.get("questions", [])
    filtered = filter_ai_question_rows(rows, df)
    if not filtered:
        return None, "AI 返回的问题未通过本地字段或 Skill 校验。"
    return add_missing_instructions(pd.DataFrame(filtered), df), None


def build_ai_question_payload(df, limit=8):
    """Build a safe dataset summary for AI question recommendations."""
    semantics = detect_field_semantics(df)
    subject = infer_dataset_subject(df)
    fields = []
    excluded_fields = []
    for _, row in semantics.head(80).iterrows():
        item = {
            "column": str(row["column"]),
            "semantic_role": str(row["semantic_role"]),
            "dtype": str(row["dtype"]),
            "missing_rate_%": float(row["missing_rate_%"]),
            "unique_count": int(row["unique_count"]),
        }
        if field_is_recommendation_usable(row):
            fields.append(item)
        else:
            excluded_fields.append(
                {
                    "column": item["column"],
                    "reason": "missing_or_identifier",
                    "missing_rate_%": item["missing_rate_%"],
                    "semantic_role": item["semantic_role"],
                }
            )
        if len(fields) >= 40:
            break
    return {
        "row_count": int(len(df)),
        "column_count": int(len(df.columns)),
        "subject": subject.get("subject", "通用表格数据"),
        "subject_description": "数据主题仅用于理解场景，推荐问题必须以 fields 中列出的可用字段为准。",
        "fields": fields,
        "excluded_fields": excluded_fields[:20],
        "allowed_skill_ids": allowed_skill_ids(),
        "max_questions": int(limit),
    }


def question_recommendation_schema():
    """Return the JSON schema expected from AI question recommendations."""
    return {
        "name": "datamind_question_recommendations",
        "schema": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "questions": {
                    "type": "array",
                    "maxItems": 8,
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "question": {"type": "string"},
                            "reason": {"type": "string"},
                            "method": {"type": "string"},
                            "priority": {"type": "string", "enum": ["优先", "建议", "基础"]},
                            "skill_id": {"type": "string"},
                            "fields": {"type": "array", "items": {"type": "string"}},
                        },
                        "required": ["question", "reason", "method", "priority", "skill_id", "fields"],
                    },
                }
            },
            "required": ["questions"],
        },
    }


def filter_ai_question_rows(rows, df):
    """Keep only AI recommendations that match known fields and whitelisted skills."""
    columns = {str(column) for column in df.columns}
    allowed = set(allowed_skill_ids())
    filtered = []
    for row in rows:
        question = str(row.get("question", "")).strip()
        skill_id = str(row.get("skill_id", "")).strip()
        fields = [str(field) for field in row.get("fields", [])]
        if not question or skill_id not in allowed:
            continue
        if fields and any(field not in columns for field in fields):
            continue
        fields = complete_ai_question_fields(df, skill_id, fields, question)
        if fields and any(field not in columns for field in fields):
            continue
        instruction = build_instruction_from_ai_row(skill_id, fields, df=df, question=question)
        if not ai_question_has_required_fields(skill_id, instruction):
            continue
        referenced_fields = sorted(set(fields) | set(instruction_fields(instruction)) | set(question_referenced_fields(df, question)))
        text_fields = set(question_referenced_fields(df, question))
        executed_fields = set(instruction_fields(instruction))
        if text_fields and not text_fields.issubset(executed_fields) and skill_id != "missing_values":
            continue
        if fields_not_suitable_for_recommendation(df, referenced_fields) and skill_id != "missing_values":
            continue
        filtered.append(
            {
                "question": question,
                "reason": str(row.get("reason", "")).strip() or "AI 根据当前数据摘要推荐的问题。",
                "method": str(row.get("method", "")).strip() or skill_id,
                "priority": row.get("priority", "建议"),
                "source": "AI 推荐 + 本地校验",
                "instruction": instruction,
            }
        )
    return filtered


def complete_ai_question_fields(df, skill_id, fields, question):
    """Fill fields omitted by AI from the natural-language question."""
    completed = [field for field in fields if field]
    parsed = parse_question(df, question)
    parsed_fields = instruction_fields(parsed)
    text_fields = question_referenced_fields(df, question)

    def add_missing(field):
        if field and field in df.columns and field not in completed:
            completed.append(field)

    if skill_id in ["groupby_sum", "groupby_agg"]:
        if len(completed) < 1:
            add_missing(parsed.get("group_column"))
        if len(completed) < 2:
            add_missing(parsed.get("value_column"))
        if len(completed) < 2:
            for field in text_fields:
                add_missing(field)
    elif skill_id == "groupby_count":
        if len(completed) < 1:
            add_missing(parsed.get("group_column") or parsed.get("column"))
        if len(completed) < 1 and text_fields:
            add_missing(text_fields[0])
    elif skill_id == "trend_analysis":
        if len(completed) < 1:
            add_missing(parsed.get("time_column"))
        if len(completed) < 2:
            add_missing(parsed.get("value_column"))
        if len(completed) < 2:
            for field in text_fields:
                add_missing(field)
    elif skill_id in ["top_n", "column_profile", "numeric_summary", "outlier_detection"]:
        if len(completed) < 1:
            add_missing(parsed.get("column") or parsed.get("sort_column"))
        if len(completed) < 1 and text_fields:
            add_missing(text_fields[0])
    elif skill_id == "top_records":
        if len(completed) < 1:
            add_missing(parsed.get("sort_column") or parsed.get("column"))
        if len(completed) < 1 and text_fields:
            add_missing(text_fields[0])
    elif skill_id == "correlation":
        for field in parsed_fields:
            add_missing(field)

    return completed


def ai_question_has_required_fields(skill_id, instruction):
    """Check that AI output contains the fields required by the selected Skill."""
    skill = get_skill(skill_id)
    if not skill:
        return False
    return all(instruction.get(field) for field in skill["required_fields"])


def field_has_high_missing(df, field, threshold=HIGH_MISSING_FIELD_RATE):
    """Return whether a field is too incomplete for proactive recommendations."""
    if field not in df.columns:
        return True
    return float(df[field].isna().mean() * 100) >= threshold


def fields_have_high_missing(df, fields, threshold=HIGH_MISSING_FIELD_RATE):
    """Return whether any referenced field is too incomplete for recommendations."""
    return any(field_has_high_missing(df, field, threshold=threshold) for field in fields if field)


def field_is_identifier_like(field):
    """Return whether a field name is likely an identifier, not an analysis metric."""
    name = str(field).lower()
    return name == "id" or name.endswith("_id") or "url" in name or "identifier" in name


def fields_not_suitable_for_recommendation(df, fields, threshold=HIGH_MISSING_FIELD_RATE):
    """Return whether any field should not be used in proactive recommendations."""
    return any(
        field_has_high_missing(df, field, threshold=threshold) or field_is_identifier_like(field)
        for field in fields
        if field
    )


def usable_recommendation_fields(df, fields, threshold=HIGH_MISSING_FIELD_RATE):
    """Keep fields suitable for proactive questions or analysis directions."""
    return [
        field
        for field in fields
        if field in df.columns and not fields_not_suitable_for_recommendation(df, [field], threshold=threshold)
    ]


def instruction_fields(instruction):
    """Return fields referenced by a structured instruction."""
    if not isinstance(instruction, dict):
        return []
    fields = []
    for key in ["column", "group_column", "value_column", "time_column", "sort_column"]:
        value = instruction.get(key)
        if value:
            fields.append(str(value))
    for key in ["columns", "fields"]:
        value = instruction.get(key)
        if isinstance(value, list):
            fields.extend(str(item) for item in value if item)
    return fields


def question_referenced_fields(df, question):
    """Infer fields mentioned in an AI question text for recommendation filtering."""
    parsed = parse_question(df, question)
    fields = set(instruction_fields(parsed))
    lowered = str(question).lower()
    for column in df.columns:
        name = str(column)
        translation = str(local_translate_field_name(name) or "")
        if name.lower() and name.lower() in lowered:
            fields.add(name)
        if translation and translation != name and translation.lower() in lowered:
            fields.add(name)
    return list(fields)


def field_is_recommendation_usable(row, threshold=HIGH_MISSING_FIELD_RATE):
    """Return whether a semantic row is suitable for proactive recommendations."""
    return float(row["missing_rate_%"]) < threshold and str(row["semantic_role"]) != "ID 字段"


def recommendation_usable_semantic_columns(semantics):
    """Return columns that are useful enough for proactive recommendations."""
    return {
        str(row["column"])
        for _, row in semantics.iterrows()
        if field_is_recommendation_usable(row)
    }


def local_question_recommendations(df, limit=8):
    """Recommend natural-language analysis questions with local rules."""
    semantics = detect_field_semantics(df)
    subject = infer_dataset_subject(df)
    recommended_field_pool = recommendation_usable_semantic_columns(semantics)
    numeric_columns = usable_recommendation_fields(
        df,
        [column for column in df.select_dtypes(include="number").columns if column in recommended_field_pool],
    )
    category_columns = usable_recommendation_fields(df, _columns_by_roles(semantics, ["类别字段", "地区字段"]))
    time_columns = usable_recommendation_fields(df, _columns_by_roles(semantics, ["时间字段"]))
    price_columns = usable_recommendation_fields(df, _columns_by_roles(semantics, ["金额/价格字段"]))
    rating_columns = usable_recommendation_fields(df, _columns_by_roles(semantics, ["评分字段"]))
    quantity_columns = usable_recommendation_fields(df, _columns_by_roles(semantics, ["数量字段"]))
    rows = []

    missing_count = int(df.isna().sum().sum())
    if missing_count:
        rows.append(
            _question(
                "哪些字段缺失最多？",
                "先确认数据里哪些信息不完整，避免后面把不可靠字段写进结论。",
                "缺失值检查",
                "优先",
            )
        )

    value_column = _first_available(price_columns, numeric_columns)
    subject_name = subject.get("subject", "")

    if "短租房源" in subject_name or "房地产" in subject_name:
        room_column = _first_name_match(category_columns, ["room", "property", "type"])
        area_column = _first_name_match(category_columns, ["neighbourhood", "neighborhood", "city", "region"])
        review_column = _first_name_match(numeric_columns, ["review", "rating", "score"])
        if room_column and value_column:
            rows.append(
                _question(
                    f"不同 {room_column} 的 {value_column} 平均值有什么差异？",
                    "这能帮助判断房源类型是否对应明显的价格差异，是房源数据里通常最先看的问题。",
                    "分组聚合分析",
                    "优先",
                )
            )
        if area_column and value_column:
            rows.append(
                _question(
                    f"不同 {area_column} 的 {value_column} 平均值有什么差异？",
                    "这能帮助判断位置或区域是否影响价格，适合继续做分组对比图。",
                    "分组聚合分析",
                    "优先",
                )
            )
        if review_column and value_column and review_column != value_column:
            rows.append(
                _question(
                    f"{value_column} 和 {review_column} 的相关性如何？",
                    "这能初步判断价格与评价或热度是否同步变化，但不能直接说明因果。",
                    "相关性分析",
                    "建议",
                )
            )

    if "销售订单" in subject_name:
        product_column = _first_name_match(category_columns, ["product", "category", "type"])
        customer_column = _first_name_match(category_columns, ["customer", "region", "city"])
        sales_column = _first_available(price_columns, quantity_columns, numeric_columns)
        if product_column:
            rows.append(
                _question(
                    f"{product_column} 前 10 个频次是什么？",
                    "这能帮助判断订单或商品是否集中在少数类别上。",
                    "类别频次分析",
                    "优先",
                )
            )
        if customer_column and sales_column:
            rows.append(
                _question(
                    f"按 {customer_column} 对 {sales_column} 求和，前 10 组是什么？",
                    "这能帮助定位贡献较高的客户、地区或渠道。",
                    "分组求和分析",
                    "优先",
                )
            )

    if "学生成绩" in subject_name or "问卷调查" in subject_name:
        group_column = _first_name_match(category_columns, ["class", "course", "gender", "major", "group", "type"])
        score_column = _first_available(rating_columns, _first_name_columns(numeric_columns, ["score", "grade", "scale"]), numeric_columns)
        if group_column and score_column:
            rows.append(
                _question(
                    f"不同 {group_column} 的 {score_column} 平均值有什么差异？",
                    "这能帮助比较不同群体之间的得分或量表结果是否存在明显差异。",
                    "分组聚合分析",
                    "优先",
                )
            )

    if category_columns:
        column = category_columns[0]
        rows.append(
            _question(
                f"{column} 前 10 个频次是什么？",
                "先看主要类别分布，可以判断数据是否集中在少数类别或地区。",
                "类别频次分析",
                "建议",
            )
        )

    if category_columns and value_column:
        group_column = category_columns[0]
        rows.append(
            _question(
                f"不同 {group_column} 的 {value_column} 平均值有什么差异？",
                "这能帮助比较不同类别之间是否存在明显差异，比只看总体平均值更有信息量。",
                "分组聚合分析",
                "建议",
            )
        )

    if time_columns and value_column:
        rows.append(
            _question(
                f"{value_column} 是否随 {time_columns[0]} 发生变化？",
                "如果数据有时间字段，这个问题能帮助发现上升、下降或周期波动。",
                "时间趋势分析",
                "建议",
            )
        )

    if len(numeric_columns) >= 2:
        first, second = _best_numeric_pair(numeric_columns, price_columns, rating_columns, quantity_columns)
        rows.append(
            _question(
                f"{first} 和 {second} 的相关性如何？",
                "这能帮助判断两个数值指标是否存在同步变化，但不能直接说明因果。",
                "相关性分析",
                "建议",
            )
        )

    rows.append(
        _question(
            "这份数据有多少行、多少列？",
            "如果你准备写报告，样本规模是最基础的背景信息。",
            "数据规模统计",
            "基础",
        )
    )

    recommendations = pd.DataFrame(_dedupe_questions(rows))
    recommendations = add_missing_instructions(recommendations, df)
    return _normalize_question_recommendations(recommendations, limit=limit, source="本地规则")


def add_missing_instructions(questions, df):
    """Fill missing structured instructions from question text when possible."""
    if questions is None or questions.empty:
        return questions
    enriched = questions.copy()
    if "instruction" not in enriched:
        enriched["instruction"] = None
    for index, row in enriched.iterrows():
        instruction = row.get("instruction")
        if isinstance(instruction, dict) and instruction.get("intent") and instruction["intent"] != "unsupported":
            valid, _ = validate_skill_instruction(df, instruction.copy())
            if valid:
                continue
        elif instruction:
            continue
        parsed = parse_question(df, str(row.get("question", "")))
        if parsed.get("intent") != "unsupported":
            enriched.at[index, "instruction"] = parsed
    return enriched


def _normalize_question_recommendations(questions, limit=8, source="本地规则"):
    """Normalize question recommendations from local rules or the reserved AI hook."""
    expected_columns = ["question", "reason", "method", "priority", "source", "instruction"]
    if questions is None or questions.empty:
        return empty_question_recommendations()

    normalized = questions.copy()
    for column in ["question", "reason", "method", "priority"]:
        if column not in normalized:
            normalized[column] = ""
    if "instruction" not in normalized:
        normalized["instruction"] = None
    normalized["priority"] = normalized["priority"].replace("", "建议")
    if "source" not in normalized:
        normalized["source"] = source
    normalized["source"] = normalized["source"].fillna(source).replace("", source)
    normalized = normalized[expected_columns]
    normalized = normalized[normalized["question"].astype(str).str.strip() != ""]
    return normalized.head(limit).reset_index(drop=True)


def sanitize_question_recommendations(df, questions):
    """Remove recommendations that still reference unusable fields."""
    if questions is None or questions.empty:
        return questions
    kept_rows = []
    for _, row in questions.iterrows():
        instruction = row.get("instruction")
        text = " ".join(str(row.get(column, "")) for column in ["question", "reason", "method"])
        referenced_fields = sorted(
            set(instruction_fields(instruction))
            | set(question_referenced_fields(df, text))
        )
        skill_id = ""
        if isinstance(instruction, dict):
            skill_id = str(instruction.get("intent", ""))
        if fields_not_suitable_for_recommendation(df, referenced_fields) and skill_id != "missing_values":
            continue
        kept_rows.append(row)
    if not kept_rows:
        return empty_question_recommendations()
    return pd.DataFrame(kept_rows).reset_index(drop=True)


def empty_question_recommendations():
    """Return an empty recommendation table with stable columns."""
    return pd.DataFrame(columns=["question", "reason", "method", "priority", "source", "instruction"])


def recommend_charts(df, limit=8):
    """Recommend charts for the current dataset."""
    semantics = detect_field_semantics(df)
    numeric_columns = list(df.select_dtypes(include="number").columns)
    category_columns = _columns_by_roles(semantics, ["类别字段", "地区字段"])
    time_columns = _columns_by_roles(semantics, ["时间字段"])
    text_columns = _columns_by_roles(semantics, ["文本字段", "文本描述字段"])

    rows = []
    if category_columns:
        rows.append(
            {
                "chart": "柱状图",
                "fields": category_columns[0],
                "reason": "查看类别或地区的频次分布。",
                "priority": "高",
            }
        )

    if category_columns and numeric_columns:
        rows.append(
            {
                "chart": "柱状图",
                "fields": f"{category_columns[0]} + {numeric_columns[0]}",
                "reason": "比较不同类别的数值总量或平均值。",
                "priority": "高",
            }
        )

    if time_columns and numeric_columns:
        rows.append(
            {
                "chart": "折线图",
                "fields": f"{time_columns[0]} + {numeric_columns[0]}",
                "reason": "观察数值随时间变化的趋势。",
                "priority": "高",
            }
        )

    if numeric_columns:
        rows.append(
            {
                "chart": "直方图",
                "fields": numeric_columns[0],
                "reason": "查看数值字段的分布形态。",
                "priority": "中",
            }
        )
        rows.append(
            {
                "chart": "箱线图",
                "fields": numeric_columns[0],
                "reason": "查看数值字段的离散程度和异常值。",
                "priority": "中",
            }
        )

    if len(numeric_columns) >= 2:
        rows.append(
            {
                "chart": "热力图",
                "fields": ", ".join(map(str, numeric_columns[:6])),
                "reason": "查看多个数值字段之间的相关性。",
                "priority": "中",
            }
        )
        rows.append(
            {
                "chart": "散点图",
                "fields": f"{numeric_columns[0]} + {numeric_columns[1]}",
                "reason": "查看两个数值字段之间的关系。",
                "priority": "中",
            }
        )

    if text_columns:
        rows.append(
            {
                "chart": "词云",
                "fields": text_columns[0],
                "reason": "查看文本字段中的高频关键词。",
                "priority": "低",
            }
        )

    return pd.DataFrame(rows[:limit])


def _columns_by_roles(semantics, roles):
    return semantics.loc[semantics["semantic_role"].isin(roles), "column"].tolist()


def _question(question, reason, method, priority="建议"):
    instruction = build_instruction_from_local_question(question, method)
    return {
        "question": question,
        "reason": reason,
        "method": method,
        "priority": priority,
        "source": "本地规则",
        "instruction": instruction,
    }


def build_instruction_from_ai_row(skill_id, fields, df=None, question=""):
    """Convert an AI recommendation row into a structured Skill instruction."""
    if df is not None:
        return build_instruction_from_ai_fields(df, skill_id, fields, question)

    if skill_id == "count_rows":
        return {"intent": "count_rows"}
    if skill_id == "missing_values":
        return {"intent": "missing_values"}
    if skill_id == "duplicate_rows":
        return {"intent": "duplicate_rows", "n": 10}
    if skill_id in ["column_profile", "numeric_summary", "outlier_detection"] and fields:
        instruction = {"intent": skill_id, "column": fields[0]}
        if skill_id == "outlier_detection":
            instruction.update({"method": "iqr", "n": 10})
        return instruction
    if skill_id == "top_n" and fields:
        return {"intent": "top_n", "column": fields[0], "n": 10}
    if skill_id == "groupby_count" and fields:
        return {"intent": "groupby_count", "group_column": fields[0], "n": 10}
    if skill_id in ["groupby_sum", "groupby_agg"] and len(fields) >= 2:
        instruction = {"intent": skill_id, "group_column": fields[0], "value_column": fields[1], "n": 10}
        if skill_id == "groupby_agg":
            instruction["agg"] = "mean"
        return instruction
    if skill_id == "correlation":
        return {"intent": "correlation", "method": "pearson"}
    if skill_id == "trend_analysis" and len(fields) >= 2:
        return {"intent": "trend_analysis", "time_column": fields[0], "value_column": fields[1], "freq": "M", "agg": "sum"}
    if skill_id == "top_records" and fields:
        return {"intent": "top_records", "sort_column": fields[0], "n": 10, "ascending": False}
    return {"intent": skill_id}


def build_instruction_from_ai_fields(df, skill_id, fields, question):
    """Build a Skill instruction by assigning candidate fields to required roles."""
    candidates = complete_ai_question_fields(df, skill_id, fields, question)
    parsed = parse_question(df, question)

    if skill_id == "count_rows":
        return {"intent": "count_rows"}
    if skill_id == "missing_values":
        return {"intent": "missing_values"}
    if skill_id == "duplicate_rows":
        return {"intent": "duplicate_rows", "n": 10}

    if skill_id == "groupby_count":
        group_column = choose_group_field(df, candidates, parsed)
        return {"intent": "groupby_count", "group_column": group_column, "n": 10}

    if skill_id in ["groupby_sum", "groupby_agg"]:
        group_column = choose_group_field(df, candidates, parsed)
        value_column = choose_numeric_field(df, candidates, parsed, exclude={group_column})
        instruction = {"intent": skill_id, "group_column": group_column, "value_column": value_column, "n": 10}
        if skill_id == "groupby_agg":
            instruction["agg"] = parsed.get("agg", "mean")
        return instruction

    if skill_id == "trend_analysis":
        time_column = choose_time_field(df, candidates, parsed)
        value_column = choose_numeric_field(df, candidates, parsed, exclude={time_column})
        return {"intent": "trend_analysis", "time_column": time_column, "value_column": value_column, "freq": "M", "agg": "sum"}

    if skill_id in ["numeric_summary", "outlier_detection"]:
        column = choose_numeric_field(df, candidates, parsed)
        instruction = {"intent": skill_id, "column": column}
        if skill_id == "outlier_detection":
            instruction.update({"method": "iqr", "n": 10})
        return instruction

    if skill_id in ["column_profile", "top_n"]:
        column = choose_any_field(df, candidates, parsed)
        instruction = {"intent": skill_id, "column": column}
        if skill_id == "top_n":
            instruction["n"] = 10
        return instruction

    if skill_id == "top_records":
        sort_column = choose_numeric_field(df, candidates, parsed)
        return {"intent": "top_records", "sort_column": sort_column, "n": 10, "ascending": False}

    if skill_id == "correlation":
        numeric_fields = [field for field in candidates if field_is_numeric(df, field)]
        instruction = {"intent": "correlation", "method": "pearson"}
        if len(numeric_fields) >= 2:
            instruction["columns"] = numeric_fields[:4]
        return instruction

    return {"intent": skill_id}


def choose_group_field(df, candidates, parsed):
    """Choose the best categorical/group field from candidates."""
    parsed_group = parsed.get("group_column") or parsed.get("column")
    if parsed_group in candidates and field_is_group_like(df, parsed_group):
        return parsed_group
    for field in candidates:
        if field_is_group_like(df, field):
            return field
    return parsed_group if parsed_group in df.columns else (candidates[0] if candidates else None)


def choose_numeric_field(df, candidates, parsed, exclude=None):
    """Choose the best numeric field from candidates."""
    exclude = {field for field in (exclude or set()) if field}
    for key in ["value_column", "column", "sort_column"]:
        field = parsed.get(key)
        if field in candidates and field not in exclude and field_is_numeric(df, field):
            return field
    for field in candidates:
        if field not in exclude and field_is_numeric(df, field):
            return field
    return None


def choose_time_field(df, candidates, parsed):
    """Choose the best time field from candidates."""
    parsed_time = parsed.get("time_column")
    if parsed_time in candidates and field_is_time_like(df, parsed_time):
        return parsed_time
    for field in candidates:
        if field_is_time_like(df, field):
            return field
    return parsed_time if parsed_time in df.columns else None


def choose_any_field(df, candidates, parsed):
    """Choose any available field, preferring parsed fields."""
    for key in ["column", "group_column", "value_column", "sort_column"]:
        field = parsed.get(key)
        if field in candidates:
            return field
    return candidates[0] if candidates else None


def field_is_numeric(df, field):
    """Return whether a field is numeric in the current dataframe."""
    return field in df.columns and pd.api.types.is_numeric_dtype(df[field])


def field_is_time_like(df, field):
    """Return whether a field can serve as a time field."""
    if field not in df.columns:
        return False
    if pd.api.types.is_datetime64_any_dtype(df[field]):
        return True
    name = str(field).lower()
    return any(token in name for token in ["date", "time", "year", "month", "day", "日期", "时间", "年份", "月份"])


def field_is_group_like(df, field):
    """Return whether a field can serve as a grouping/category field."""
    if field not in df.columns:
        return False
    return not field_is_numeric(df, field) and not field_is_time_like(df, field)


def build_instruction_from_local_question(question, method):
    """Build a structured instruction for local recommendations when possible."""
    if method == "缺失值检查":
        return {"intent": "missing_values"}
    if method == "数据规模统计":
        return {"intent": "count_rows"}
    return None


def _dedupe_questions(rows):
    seen = set()
    deduped = []
    priority_order = {"优先": 0, "建议": 1, "基础": 2}
    for row in sorted(rows, key=lambda item: priority_order.get(item.get("priority"), 9)):
        question = row["question"]
        if question in seen:
            continue
        seen.add(question)
        deduped.append(row)
    return deduped


def _first_available(*groups):
    for group in groups:
        if isinstance(group, list) and group:
            return group[0]
        if group:
            return group
    return None


def _first_name_match(columns, keywords):
    for column in columns:
        lowered = str(column).lower()
        if any(keyword in lowered for keyword in keywords):
            return column
    return columns[0] if columns else None


def _first_name_columns(columns, keywords):
    return [column for column in columns if any(keyword in str(column).lower() for keyword in keywords)]


def _best_numeric_pair(numeric_columns, price_columns, rating_columns, quantity_columns):
    preferred = []
    for group in [price_columns, rating_columns, quantity_columns, numeric_columns]:
        for column in group:
            if column not in preferred:
                preferred.append(column)
    return preferred[0], preferred[1]
