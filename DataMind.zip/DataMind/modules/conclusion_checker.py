"""Local-rule report conclusion support checker.

Source: Student + AI
"""

import re

import pandas as pd


STRONG_WORDS = ["导致", "证明", "一定", "必然", "决定", "完全", "肯定", "最好", "最差", "显著提高", "显著降低"]
CAUSAL_WORDS = ["导致", "影响", "决定", "使得", "造成", "因为", "所以", "证明"]
POSITIVE_RELATION_WORDS = ["越高", "越多", "越大", "越强", "正相关", "同向"]
NEGATIVE_RELATION_WORDS = ["越低", "越少", "越小", "负相关", "反向"]


FIELD_ALIASES = {
    "价格": ["price", "amount", "cost", "fee", "unitprice"],
    "房价": ["price"],
    "评分": ["review_scores_rating", "rating", "score"],
    "评价": ["review_scores_rating", "rating", "number_of_reviews", "reviews_per_month"],
    "评论": ["number_of_reviews", "reviews_per_month", "review_count"],
    "评论数": ["number_of_reviews", "reviews_per_month", "review_count"],
    "销量": ["quantity", "sales", "volume"],
    "销售额": ["sales", "revenue", "amount", "total_amount"],
    "数量": ["quantity", "count", "number"],
    "房型": ["room_type", "property_type"],
    "地区": ["neighbourhood_cleansed", "neighbourhood", "neighborhood", "city", "region", "country"],
    "街区": ["neighbourhood_cleansed", "neighbourhood", "neighborhood"],
}


def check_conclusion_support(df, conclusion, candidate_fields=None):
    """Check whether a user-written conclusion is supported by current data."""
    text = str(conclusion or "").strip()
    if not text:
        return _result("请输入一句想写进报告的结论。", "证据不足", [], [], "先写出一句具体结论，再进行检查。")

    fields = merge_candidate_fields(df, find_mentioned_fields(df, text), candidate_fields)
    warnings = build_wording_warnings(text)
    evidence = []
    suggested = build_cautious_rewrite(text, warnings)
    support = "证据不足"

    numeric_fields = [field for field in fields if pd.api.types.is_numeric_dtype(df[field])]
    category_fields = [field for field in fields if field not in numeric_fields]

    if len(numeric_fields) >= 2:
        evidence.extend(correlation_evidence(df, numeric_fields[0], numeric_fields[1], text))
        support = support_from_evidence(evidence, warnings)
    elif category_fields and numeric_fields:
        evidence.extend(group_difference_evidence(df, category_fields[0], numeric_fields[0]))
        support = support_from_evidence(evidence, warnings)
    elif len(fields) == 1:
        evidence.extend(single_field_evidence(df, fields[0]))
        support = "部分支持" if evidence else "证据不足"
    else:
        warnings.append("没有识别到足够字段，暂时无法直接用当前数据验证这句话。")

    if any(word in text for word in CAUSAL_WORDS):
        warnings.append("这句话包含因果表达。当前系统只能检查统计关系，不能证明因果。")
        if support == "较支持":
            support = "表述过强"
    if any(word in text for word in STRONG_WORDS):
        support = "表述过强" if support in {"较支持", "部分支持"} else support

    if not suggested:
        suggested = default_rewrite(text, support)

    return _result(text, support, fields, evidence, suggested, warnings)


def merge_candidate_fields(df, local_fields, candidate_fields=None):
    """Merge locally detected fields with validated candidate fields."""
    fields = []
    for field in candidate_fields or []:
        if field in df.columns:
            fields.append(field)
    fields.extend(local_fields or [])
    return list(dict.fromkeys(fields))


def find_mentioned_fields(df, text):
    """Find fields mentioned by exact column name or common Chinese aliases."""
    lowered = text.lower()
    matched = []
    for column in df.columns:
        if str(column).lower() in lowered:
            matched.append(column)
    for alias, candidates in FIELD_ALIASES.items():
        if alias not in text:
            continue
        for candidate in candidates:
            column = first_existing_column(df.columns, candidate)
            if column is not None:
                matched.append(column)
                break
    return list(dict.fromkeys(matched))


def first_existing_column(columns, candidate):
    lowered = candidate.lower()
    for column in columns:
        if str(column).lower() == lowered:
            return column
    for column in columns:
        if lowered in str(column).lower():
            return column
    return None


def build_wording_warnings(text):
    warnings = []
    strong = [word for word in STRONG_WORDS if word in text]
    if strong:
        warnings.append("结论中包含较强表述：" + "、".join(strong) + "。")
    return warnings


def correlation_evidence(df, col_a, col_b, text):
    pair = df[[col_a, col_b]].apply(pd.to_numeric, errors="coerce").dropna()
    if len(pair) < 3:
        return [f"{col_a} 与 {col_b} 的有效样本不足，暂时无法稳定判断相关关系。"]
    corr = float(pair[col_a].corr(pair[col_b]))
    direction = "正相关" if corr > 0 else "负相关" if corr < 0 else "无明显方向"
    strength = "较强" if abs(corr) >= 0.6 else "中等" if abs(corr) >= 0.3 else "较弱"
    expected = expected_relation_direction(text)
    consistency = ""
    if expected == "positive" and corr < 0:
        consistency = " 这与原句中的正向关系表述不一致。"
    elif expected == "negative" and corr > 0:
        consistency = " 这与原句中的反向关系表述不一致。"
    return [f"{col_a} 与 {col_b} 的 Pearson 相关系数约为 {corr:.2f}，属于{strength}{direction}。{consistency}".strip()]


def group_difference_evidence(df, group_col, value_col):
    temp = df[[group_col, value_col]].copy()
    temp[value_col] = pd.to_numeric(temp[value_col], errors="coerce")
    grouped = temp.dropna(subset=[value_col]).groupby(group_col, dropna=False)[value_col].mean().sort_values(ascending=False)
    if len(grouped) < 2:
        return [f"{group_col} 的可比较分组不足，暂时无法支持分组差异结论。"]
    top_name = grouped.index[0]
    bottom_name = grouped.index[-1]
    top_value = grouped.iloc[0]
    bottom_value = grouped.iloc[-1]
    return [
        f"按 {group_col} 分组计算 {value_col} 平均值，最高组为 {top_name}（约 {format_number(top_value)}），最低组为 {bottom_name}（约 {format_number(bottom_value)}）。"
    ]


def single_field_evidence(df, field):
    series = df[field]
    missing_rate = series.isna().mean() * 100 if len(series) else 0
    if pd.api.types.is_numeric_dtype(series):
        clean = pd.to_numeric(series, errors="coerce").dropna()
        if clean.empty:
            return [f"{field} 当前没有可计算的有效数值。"]
        return [
            f"{field} 的中位数约为 {format_number(clean.median())}，平均值约为 {format_number(clean.mean())}，缺失率约为 {missing_rate:.1f}%。"
        ]
    unique_count = int(series.nunique(dropna=True))
    return [f"{field} 共有 {unique_count} 个不同取值，缺失率约为 {missing_rate:.1f}%。"]


def expected_relation_direction(text):
    if any(word in text for word in POSITIVE_RELATION_WORDS):
        return "positive"
    if any(word in text for word in NEGATIVE_RELATION_WORDS):
        return "negative"
    return ""


def support_from_evidence(evidence, warnings):
    joined = " ".join(evidence)
    if "不一致" in joined or "不足" in joined:
        return "证据不足"
    if warnings:
        return "部分支持"
    match = re.search(r"相关系数约为 (-?\d+\.\d+)", joined)
    if match and abs(float(match.group(1))) < 0.3:
        return "证据不足"
    return "较支持"


def build_cautious_rewrite(text, warnings):
    if any(word in text for word in CAUSAL_WORDS):
        cleaned = text
        for word in ["导致", "决定", "使得", "造成", "证明"]:
            cleaned = cleaned.replace(word, "可能与")
        return f"建议改写为：从当前数据看，{cleaned}。这一表述表示统计关系，不直接说明因果。"
    if warnings:
        return f"建议改写为：从当前数据看，{text}，但该结论仍需结合样本范围、缺失值和极端值谨慎解释。"
    return ""


def default_rewrite(text, support):
    if support == "较支持":
        return f"可以写作：从当前数据看，{text}。"
    return f"建议写作：当前数据只能为“{text}”提供有限证据，仍需补充图表或更多字段验证。"


def format_number(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)
    if abs(number) >= 100:
        return f"{number:,.0f}"
    return f"{number:.2f}".rstrip("0").rstrip(".")


def _result(conclusion, support, fields, evidence, suggestion, warnings=None):
    return {
        "conclusion": conclusion,
        "support": support,
        "fields": fields,
        "evidence": evidence,
        "suggestion": suggestion,
        "warnings": warnings or [],
    }
