"""Whitelisted deterministic analysis functions.

Source: Student + AI
"""

from collections import Counter
import re

import pandas as pd
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler


class AnalysisError(ValueError):
    """Raised when an analysis request is invalid."""


TEXT_STOPWORDS = {
    "a",
    "an",
    "and",
    "are",
    "as",
    "at",
    "be",
    "by",
    "for",
    "from",
    "has",
    "have",
    "in",
    "is",
    "it",
    "of",
    "on",
    "or",
    "that",
    "the",
    "this",
    "to",
    "with",
    "you",
    "your",
    "room",
    "rooms",
    "apartment",
    "home",
    "house",
    "bedroom",
    "bed",
    "bath",
    "private",
    "entire",
}


def count_rows(df):
    """Return the number of rows."""
    return {"row_count": int(len(df))}


def missing_values(df):
    """Return missing value counts and rates by column."""
    counts = df.isna().sum()
    rates = counts / len(df) * 100 if len(df) else counts
    return pd.DataFrame(
        {
            "column": counts.index,
            "missing_count": counts.astype(int).values,
            "missing_rate_%": rates.round(2).values,
        }
    )


def column_profile(df, column):
    """Return a compact profile for one column."""
    _require_columns(df, [column])
    series = df[column]
    total = len(series)
    missing_count = int(series.isna().sum())
    non_null = int(series.notna().sum())
    unique_count = int(series.nunique(dropna=True))
    missing_rate = round(missing_count / total * 100, 2) if total else 0
    top_values = top_n(df, column, n=5)

    return {
        "column": column,
        "dtype": str(series.dtype),
        "row_count": int(total),
        "non_null_count": non_null,
        "missing_count": missing_count,
        "missing_rate_%": missing_rate,
        "unique_count": unique_count,
        "top_values": top_values,
    }


def numeric_summary(df, column):
    """Return descriptive statistics for one numeric column."""
    _require_columns(df, [column])
    _require_numeric(df, column)
    series = df[column].dropna()
    if series.empty:
        raise AnalysisError(f"Column {column} has no valid numeric values.")

    return {
        "column": column,
        "count": int(series.count()),
        "mean": round(float(series.mean()), 4),
        "median": round(float(series.median()), 4),
        "min": round(float(series.min()), 4),
        "max": round(float(series.max()), 4),
        "std": round(float(series.std()), 4) if len(series) > 1 else 0.0,
        "q1": round(float(series.quantile(0.25)), 4),
        "q3": round(float(series.quantile(0.75)), 4),
    }


def top_n(df, column, n=10):
    """Return the most frequent values for one column."""
    _require_columns(df, [column])
    n = _validate_n(n)

    result = (
        df[column]
        .value_counts(dropna=False)
        .head(n)
        .reset_index()
        .rename(columns={"index": column, column: "count"})
    )
    result.columns = [column, "count"]
    return result


def groupby_count(df, group_column, n=10):
    """Count records by one category-like column."""
    _require_columns(df, [group_column])
    n = _validate_n(n)
    counts = df[group_column].value_counts(dropna=False).head(n).reset_index()
    counts.columns = [group_column, "count"]
    total = len(df)
    counts["share_%"] = (counts["count"] / total * 100).round(2) if total else 0
    return counts


def groupby_sum(df, group_column, value_column, n=10):
    """Group by a category-like column and sum a numeric column."""
    _require_columns(df, [group_column, value_column])
    _require_numeric(df, value_column)
    n = _validate_n(n)

    return (
        df.groupby(group_column, dropna=False)[value_column]
        .sum()
        .sort_values(ascending=False)
        .head(n)
        .reset_index()
        .rename(columns={value_column: f"{value_column}_sum"})
    )


def groupby_agg(df, group_column, value_column, agg="mean", n=10):
    """Group by one column and aggregate a numeric column."""
    _require_columns(df, [group_column, value_column])
    _require_numeric(df, value_column)
    n = _validate_n(n)

    allowed_aggs = {"sum", "mean", "median", "max", "min", "count"}
    if agg not in allowed_aggs:
        raise AnalysisError(f"Unsupported aggregation: {agg}")

    result = (
        df.groupby(group_column, dropna=False)[value_column]
        .agg(agg)
        .sort_values(ascending=False)
        .head(n)
        .reset_index()
        .rename(columns={value_column: f"{value_column}_{agg}"})
    )
    return result


def outlier_detection(df, column, method="iqr", n=20):
    """Return likely outliers for one numeric column."""
    _require_columns(df, [column])
    _require_numeric(df, column)
    n = _validate_n(n)
    series = df[column].dropna()
    if series.empty:
        raise AnalysisError(f"Column {column} has no valid numeric values.")

    if method != "iqr":
        raise AnalysisError(f"Unsupported outlier method: {method}")

    q1 = float(series.quantile(0.25))
    q3 = float(series.quantile(0.75))
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    outlier_mask = (df[column] < lower) | (df[column] > upper)
    outliers = df.loc[outlier_mask, [column]].copy()
    outliers["row_index"] = outliers.index
    outliers["direction"] = outliers[column].apply(lambda value: "偏高" if value > upper else "偏低")
    outliers["lower_bound"] = round(lower, 4)
    outliers["upper_bound"] = round(upper, 4)
    outliers["distance_from_bound"] = outliers[column].apply(
        lambda value: min(abs(float(value) - lower), abs(float(value) - upper))
    )
    outliers = outliers.sort_values("distance_from_bound", ascending=False).head(n)
    return {
        "column": column,
        "method": method,
        "outlier_count": int(outlier_mask.sum()),
        "outlier_rate_%": round(float(outlier_mask.sum()) / len(df) * 100, 2) if len(df) else 0,
        "lower_bound": round(lower, 4),
        "upper_bound": round(upper, 4),
        "outliers": outliers.reset_index(drop=True),
    }


def duplicate_rows(df, subset=None, n=20):
    """Return duplicate row counts and examples."""
    n = _validate_n(n)
    subset = subset or None
    if subset:
        _require_columns(df, subset)
    duplicate_mask = df.duplicated(subset=subset, keep=False)
    duplicates = df.loc[duplicate_mask].head(n).copy()
    duplicates.insert(0, "row_index", duplicates.index)
    return {
        "duplicate_count": int(duplicate_mask.sum()),
        "duplicate_rate_%": round(float(duplicate_mask.sum()) / len(df) * 100, 2) if len(df) else 0,
        "checked_columns": subset or "全部字段",
        "examples": duplicates.reset_index(drop=True),
    }


def top_records(df, sort_column, n=10, ascending=False):
    """Return records ranked by one sortable column."""
    _require_columns(df, [sort_column])
    n = _validate_n(n)
    result = df.sort_values(sort_column, ascending=bool(ascending), na_position="last").head(n).copy()
    result.insert(0, "row_index", result.index)
    return result.reset_index(drop=True)


def cluster_analysis(df, columns, n_clusters=3, sample_size=1000, random_state=42):
    """Cluster records with KMeans and return summaries plus PCA coordinates."""
    if not columns or len(columns) < 2:
        raise AnalysisError("Cluster analysis requires at least two numeric columns.")
    _require_columns(df, columns)
    for column in columns:
        _require_numeric(df, column)

    try:
        k = int(n_clusters)
    except (TypeError, ValueError) as exc:
        raise AnalysisError("Cluster count must be an integer.") from exc
    if k < 2 or k > 6:
        raise AnalysisError("Cluster count must be between 2 and 6.")

    numeric_df = df[columns].copy()
    usable_mask = numeric_df.notna().any(axis=1)
    numeric_df = numeric_df.loc[usable_mask]
    if len(numeric_df) < k:
        raise AnalysisError("Not enough valid rows for the selected cluster count.")

    fit_df = numeric_df
    if len(fit_df) > sample_size:
        fit_df = fit_df.sample(sample_size, random_state=random_state)

    imputer = SimpleImputer(strategy="median")
    scaler = StandardScaler()
    fit_imputed = imputer.fit_transform(fit_df)
    fit_scaled = scaler.fit_transform(fit_imputed)
    model = KMeans(n_clusters=k, random_state=random_state, n_init=10).fit(fit_scaled)
    pca = PCA(n_components=2, random_state=random_state).fit(fit_scaled)

    imputed = imputer.transform(numeric_df)
    scaled = scaler.transform(imputed)
    labels = model.predict(scaled)
    pca_values = pca.transform(scaled)
    pca_components = pd.DataFrame(
        pca.components_,
        columns=columns,
        index=["综合特征 1", "综合特征 2"],
    ).round(4)

    clustered = numeric_df.reset_index().rename(columns={"index": "row_index"})
    clustered["cluster"] = labels + 1
    clustered["pca_x"] = pca_values[:, 0]
    clustered["pca_y"] = pca_values[:, 1]

    counts = (
        clustered["cluster"]
        .value_counts()
        .sort_index()
        .reset_index()
        .rename(columns={"cluster": "分群", "count": "记录数"})
    )
    counts["占比_%"] = (counts["记录数"] / len(clustered) * 100).round(2)

    means = clustered.groupby("cluster")[columns].mean().round(3).reset_index().rename(columns={"cluster": "分群"})
    medians = clustered.groupby("cluster")[columns].median().round(3).reset_index().rename(columns={"cluster": "分群"})
    profiles = _cluster_profiles(means, counts, columns)

    return {
        "columns": columns,
        "n_clusters": k,
        "sampled_rows": int(len(clustered)),
        "fit_rows": int(len(fit_df)),
        "counts": counts,
        "means": means,
        "medians": medians,
        "profiles": profiles,
        "points": clustered,
        "pca_components": pca_components,
    }


def text_word_frequency(df, column, top_n_words=50, min_word_length=3, extra_stopwords=None):
    """Return word frequencies for a text column."""
    _require_columns(df, [column])
    n = _validate_n(top_n_words)
    try:
        min_length = int(min_word_length)
    except (TypeError, ValueError) as exc:
        raise AnalysisError("Minimum word length must be an integer.") from exc
    if min_length < 1 or min_length > 20:
        raise AnalysisError("Minimum word length must be between 1 and 20.")

    stopwords = set(TEXT_STOPWORDS)
    if extra_stopwords:
        stopwords.update(str(word).strip().lower() for word in extra_stopwords if str(word).strip())

    texts = df[column].dropna().astype(str)
    counter = Counter()
    for text in texts:
        words = re.findall(r"[A-Za-z][A-Za-z'-]*", text.lower())
        counter.update(word for word in words if len(word) >= min_length and word not in stopwords)

    rows = [{"word": word, "count": int(count)} for word, count in counter.most_common(n)]
    total_words = int(sum(counter.values()))
    result = pd.DataFrame(rows, columns=["word", "count"])
    if not result.empty and total_words:
        result["share_%"] = (result["count"] / total_words * 100).round(2)
    else:
        result["share_%"] = []
    return {
        "column": column,
        "non_empty_rows": int(len(texts)),
        "unique_words": int(len(counter)),
        "total_words": total_words,
        "frequencies": result,
    }


def _cluster_profiles(means, counts, columns):
    rows = []
    overall = means[columns].mean()
    for _, row in means.iterrows():
        cluster_id = int(row["分群"])
        count_row = counts.loc[counts["分群"] == cluster_id].iloc[0]
        high_fields = []
        low_fields = []
        for column in columns:
            if row[column] > overall[column]:
                high_fields.append(column)
            elif row[column] < overall[column]:
                low_fields.append(column)
        feature_parts = []
        if high_fields:
            feature_parts.append("较高：" + "、".join(high_fields[:3]))
        if low_fields:
            feature_parts.append("较低：" + "、".join(low_fields[:3]))
        rows.append(
            {
                "分群": cluster_id,
                "记录数": int(count_row["记录数"]),
                "占比_%": float(count_row["占比_%"]),
                "特点概括": "；".join(feature_parts) if feature_parts else "各字段接近整体平均水平",
            }
        )
    return pd.DataFrame(rows)


def correlation(df, method="pearson"):
    """Return correlation matrix for numeric columns."""
    allowed_methods = {"pearson", "spearman"}
    if method not in allowed_methods:
        raise AnalysisError(f"Unsupported correlation method: {method}")

    numeric_df = df.select_dtypes(include="number")
    if numeric_df.shape[1] < 2:
        raise AnalysisError("Correlation analysis requires at least two numeric columns.")

    return numeric_df.corr(method=method).round(4)


def trend_analysis(df, time_column, value_column, freq="M", agg="sum"):
    """Aggregate a numeric value over time."""
    _require_columns(df, [time_column, value_column])
    _require_numeric(df, value_column)

    allowed_aggs = {"sum", "mean", "median", "max", "min", "count"}
    if agg not in allowed_aggs:
        raise AnalysisError(f"Unsupported aggregation: {agg}")

    time_series = pd.to_datetime(df[time_column], errors="coerce")
    if time_series.notna().sum() == 0:
        raise AnalysisError(f"Column {time_column} cannot be converted to datetime.")

    allowed_freqs = {"D", "W", "M", "Q", "Y"}
    if freq not in allowed_freqs:
        raise AnalysisError(f"Unsupported time frequency: {freq}")
    pandas_freq = {"M": "ME", "Q": "QE", "Y": "YE"}.get(freq, freq)

    temp = df.copy()
    temp[time_column] = time_series
    temp = temp.dropna(subset=[time_column])

    result = (
        temp.set_index(time_column)[value_column]
        .resample(pandas_freq)
        .agg(agg)
        .reset_index()
        .rename(columns={value_column: f"{value_column}_{agg}"})
    )
    return result


def _require_columns(df, columns):
    missing = [column for column in columns if column not in df.columns]
    if missing:
        raise AnalysisError("Missing column(s): " + ", ".join(missing))


def _require_numeric(df, column):
    if not pd.api.types.is_numeric_dtype(df[column]):
        raise AnalysisError(f"Column {column} must be numeric.")


def _validate_n(n):
    try:
        value = int(n)
    except (TypeError, ValueError) as exc:
        raise AnalysisError("N must be an integer.") from exc

    if value <= 0:
        raise AnalysisError("N must be greater than 0.")
    return value
