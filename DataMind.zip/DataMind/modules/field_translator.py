"""Display-only field translation helpers.

Source: Student + AI
"""

from __future__ import annotations

import re

from modules.ai_client import request_structured_json


LOCAL_FIELD_TRANSLATIONS = {
    "id": "编号",
    "name": "名称",
    "description": "描述",
    "summary": "摘要",
    "about": "关于说明",
    "overview": "概览说明",
    "price": "价格",
    "cost": "成本",
    "fee": "费用",
    "amount": "金额",
    "revenue": "收入",
    "sales": "销售额",
    "neighbourhood": "街区或地区",
    "neighborhood": "街区或地区",
    "neighbourhood_cleansed": "清洗后的街区",
    "neighborhood_cleansed": "清洗后的街区",
    "city": "城市",
    "region": "地区",
    "location": "位置",
    "latitude": "纬度",
    "longitude": "经度",
    "room_type": "房型",
    "property_type": "房源类型",
    "type": "类型",
    "category": "类别",
    "status": "状态",
    "host": "房东",
    "host_id": "房东编号",
    "host_name": "房东名称",
    "host_response_time": "房东回复时间",
    "host_response_rate": "房东回复率",
    "host_acceptance_rate": "房东接受预订率",
    "review_scores_rating": "评论综合评分",
    "review_scores_accuracy": "评论准确性评分",
    "review_scores_cleanliness": "评论清洁度评分",
    "review_scores_checkin": "评论入住评分",
    "review_scores_communication": "评论沟通评分",
    "review_scores_location": "评论位置评分",
    "review_scores_value": "评论性价比评分",
    "rating": "评分",
    "score": "得分",
    "review": "评价",
    "reviews": "评价",
    "number_of_reviews": "评价数量",
    "number_of_reviews_ltm": "过去十二个月评价数量",
    "number_of_reviews_l30d": "过去三十天评价数量",
    "reviews_per_month": "每月评价数量",
    "last_review": "最近一次评价日期",
    "first_review": "首次评价日期",
    "last_scraped": "最近抓取日期",
    "date": "日期",
    "time": "时间",
    "year": "年份",
    "month": "月份",
    "day": "日期中的日",
    "availability_30": "未来三十天可订天数",
    "availability_60": "未来六十天可订天数",
    "availability_90": "未来九十天可订天数",
    "availability_365": "未来一年可订天数",
    "availability": "可订状态或可订天数",
    "minimum_nights": "最少入住晚数",
    "maximum_nights": "最多入住晚数",
    "minimum_minimum_nights": "最小的最少入住晚数",
    "maximum_minimum_nights": "最大的最少入住晚数",
    "minimum_maximum_nights": "最小的最多入住晚数",
    "maximum_maximum_nights": "最大的最多入住晚数",
    "minimum_nights_avg_ntm": "未来一段时间平均最少入住晚数",
    "maximum_nights_avg_ntm": "未来一段时间平均最多入住晚数",
    "accommodates": "可容纳人数",
    "beds": "床位数",
    "bedrooms": "卧室数",
    "bathrooms": "浴室数",
    "bathrooms_text": "浴室文字说明",
    "amenities": "设施",
    "instant_bookable": "是否可即时预订",
    "calculated_host_listings_count": "房东挂牌房源数量",
    "calculated_host_listings_count_entire_homes": "房东整套房源挂牌数量",
    "calculated_host_listings_count_private_rooms": "房东独立房间挂牌数量",
    "calculated_host_listings_count_shared_rooms": "房东合住房间挂牌数量",
}


PART_TRANSLATIONS = {
    **LOCAL_FIELD_TRANSLATIONS,
    "url": "链接",
    "listing": "房源",
    "listings": "房源",
    "count": "数量",
    "number": "数量",
    "avg": "平均",
    "ntm": "未来一段时间",
    "ltm": "过去十二个月",
    "l30d": "过去三十天",
    "cleansed": "清洗后",
    "private": "独立",
    "shared": "合住",
    "entire": "整套",
    "homes": "房源",
    "rooms": "房间",
    "scraped": "抓取",
    "license": "许可证",
    "has": "是否拥有",
    "is": "是否",
}

LOCAL_VALUE_TRANSLATIONS = {
    "t": "是",
    "f": "否",
    "true": "是",
    "false": "否",
    "yes": "是",
    "no": "否",
    "entire home/apt": "整套房源或公寓",
    "private room": "独立房间",
    "shared room": "合住房间",
    "hotel room": "酒店房间",
    "within an hour": "一小时内",
    "within a few hours": "几小时内",
    "within a day": "一天内",
    "a few days or more": "几天或更久",
    "superhost": "超赞房东",
}


def is_english_text(text):
    """Return whether text contains English letters."""
    return bool(re.search(r"[A-Za-z]", str(text)))


def display_field_label(field_name, translations=None):
    """Return field display label as original plus Chinese translation."""
    name = str(field_name)
    if not is_english_text(name):
        return name
    translation = None
    if translations:
        translation = translations.get(name)
    translation = translation or local_translate_field_name(name)
    if not translation or translation == name:
        return name
    return f"{name}（{translation}）"


def display_text_with_field_labels(text, translations):
    """Replace known field names inside display text with translated labels."""
    result = str(text)
    translations = translations or {}
    for field_name in sorted(translations, key=len, reverse=True):
        if not field_name or not is_english_text(field_name):
            continue
        label = display_field_label(field_name, translations)
        if label == field_name:
            continue
        pattern = rf"(?<![\w]){re.escape(field_name)}(?![\w])"
        result = re.sub(pattern, label, result)
    return result


def display_value_label(field_name, value, translations=None):
    """Return data value display label as original plus Chinese translation."""
    text = normalize_value_text(value)
    if not should_translate_value(text):
        return value
    translation = None
    key = value_cache_key(field_name, text)
    if translations:
        translation = translations.get(key)
    translation = translation or local_translate_value(text)
    if not is_valid_translation(text, translation):
        return value
    return f"{text}（{translation}）"


def translate_display_values(field_name, values, cache=None, use_ai=True):
    """Translate short display values on demand for one field."""
    cache = cache if cache is not None else {}
    unique_values = []
    seen = set()
    for value in values:
        text = normalize_value_text(value)
        if text in seen or not should_translate_value(text):
            continue
        seen.add(text)
        unique_values.append(text)

    result = {}
    pending = []
    for text in unique_values[:60]:
        key = value_cache_key(field_name, text)
        if key in cache:
            result[key] = cache[key]
            continue
        local = local_translate_value(text)
        if is_valid_translation(text, local):
            cache[key] = local
            result[key] = local
        else:
            pending.append(text)

    if use_ai and pending:
        ai_translations = request_ai_value_translations(field_name, pending)
        for text in pending:
            key = value_cache_key(field_name, text)
            translation = clean_translation(ai_translations.get(text, ""))
            if is_valid_translation(text, translation):
                cache[key] = translation
                result[key] = translation
    return result


def translate_field_names(field_names, cache=None, use_ai=True):
    """Translate field names with local fallback and optional AI batch translation."""
    cache = cache if cache is not None else {}
    names = [str(name) for name in field_names]
    result = {}
    pending = []

    for name in names:
        if not is_english_text(name):
            result[name] = name
            continue
        if name in cache:
            result[name] = cache[name]
            continue
        local = local_translate_field_name(name)
        if local and local != name:
            cache[name] = local
            result[name] = local
        else:
            pending.append(name)

    if use_ai and pending:
        ai_translations = request_ai_field_translations(pending)
        for name in pending:
            translation = clean_translation(ai_translations.get(name, ""))
            if not is_valid_translation(name, translation):
                translation = fallback_literal_translation(name)
            cache[name] = translation
            result[name] = translation
    else:
        for name in pending:
            translation = fallback_literal_translation(name)
            cache[name] = translation
            result[name] = translation

    return result


def local_translate_field_name(field_name):
    """Translate a field name using deterministic local rules."""
    name = str(field_name)
    lower_name = name.lower()
    if not is_english_text(name):
        return name
    if lower_name in LOCAL_FIELD_TRANSLATIONS:
        return LOCAL_FIELD_TRANSLATIONS[lower_name]

    parts = split_field_name(lower_name)
    translated_parts = [PART_TRANSLATIONS.get(part, "") for part in parts]
    if translated_parts and all(translated_parts):
        return "".join(translated_parts)
    return ""


def request_ai_field_translations(field_names):
    """Ask AI to translate full field names. Returns an empty dict on failure."""
    field_list = "\n".join(f"- {name}" for name in field_names[:80])
    prompt = f"""
请把下面这些数据表字段名完整翻译成中文。

要求：
1. 只返回 JSON，不要 Markdown。
2. JSON 格式为 {{"translations": {{"原字段名": "完整中文翻译"}}}}。
3. 必须完整覆盖整个英文字段名含义，不要只翻译其中一部分。
4. 保留字段修饰含义，例如 host、review、minimum、maximum、calculated、ltm、l30d 等都要体现在中文里。
5. 不要改写原字段名，不要添加括号，不要添加解释句。
6. 如果含义不确定，请保守直译，不要泛化成宽泛概念。

字段名：
{field_list}
""".strip()
    data, error = request_structured_json(prompt, schema={"translations": "object"}, timeout=20)
    if error or not isinstance(data, dict):
        return {}
    translations = data.get("translations", {})
    if not isinstance(translations, dict):
        return {}
    return {str(key): str(value) for key, value in translations.items()}


def request_ai_value_translations(field_name, values):
    """Ask AI to translate displayed data values. Returns an empty dict on failure."""
    value_list = "\n".join(f"- {value}" for value in values[:60])
    prompt = f"""
请把下面这些数据表字段取值完整翻译成中文。

字段名：{field_name}

要求：
1. 只返回 JSON，不要 Markdown。
2. JSON 格式为 {{"translations": {{"原取值": "完整中文翻译"}}}}。
3. 必须完整覆盖整个英文原文含义，不要只翻译其中一部分。
4. 不要改写原取值，不要添加括号，不要添加解释句。
5. 如果看起来是人名、地名、品牌名、编号、URL、邮箱或无需翻译的专有名词，请不要返回该项。
6. 如果含义不确定，请保守直译；不要泛化成宽泛概念。

字段取值：
{value_list}
""".strip()
    data, error = request_structured_json(prompt, schema={"translations": "object"}, timeout=20)
    if error or not isinstance(data, dict):
        return {}
    translations = data.get("translations", {})
    if not isinstance(translations, dict):
        return {}
    return {str(key): str(value) for key, value in translations.items()}


def split_field_name(field_name):
    """Split snake/camel/kebab field names into lowercase parts."""
    text = re.sub(r"([a-z])([A-Z])", r"\1_\2", str(field_name))
    return [part for part in re.split(r"[_\-\s/]+", text.lower()) if part]


def fallback_literal_translation(field_name):
    """Return a conservative readable fallback when AI is unavailable."""
    parts = split_field_name(field_name)
    translated = [PART_TRANSLATIONS.get(part, part) for part in parts]
    return "".join(translated) if translated else str(field_name)


def normalize_value_text(value):
    """Normalize a display value for translation checks."""
    if value is None:
        return ""
    text = str(value).replace("\n", " ").replace("\r", " ").strip()
    return re.sub(r"\s+", " ", text)


def should_translate_value(text):
    """Return whether a displayed data value is worth translating."""
    text = normalize_value_text(text)
    if not text or not is_english_text(text):
        return False
    lower = text.lower()
    if lower in LOCAL_VALUE_TRANSLATIONS:
        return True
    if len(text) > 80:
        return False
    if re.fullmatch(r"[-+]?\d+(\.\d+)?", text):
        return False
    if re.search(r"https?://|www\.|@|[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.", text):
        return False
    if re.fullmatch(r"[A-Z0-9_-]{5,}", text):
        return False
    if re.fullmatch(r"[A-Z][a-z]+", text):
        return False
    if re.fullmatch(r"[A-Z][a-z]+([ -][A-Z][a-z]+){1,3}", text):
        return False
    return True


def local_translate_value(value):
    """Translate common short category values locally."""
    text = normalize_value_text(value)
    return LOCAL_VALUE_TRANSLATIONS.get(text.lower(), "")


def value_cache_key(field_name, value):
    """Return a stable cache key for one field value."""
    return f"{str(field_name)}::{normalize_value_text(value)}"


def clean_translation(text):
    """Normalize AI translation output."""
    text = str(text).strip()
    text = re.sub(r"^[（(]|[）)]$", "", text)
    return text.strip()


def is_valid_translation(field_name, translation):
    """Reject empty or obviously useless translations."""
    if not translation:
        return False
    if translation.strip().lower() == str(field_name).strip().lower():
        return False
    return bool(re.search(r"[\u4e00-\u9fff]", translation))
