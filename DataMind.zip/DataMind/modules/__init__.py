"""Core modules for DataMind.

Source: Student + AI
"""
