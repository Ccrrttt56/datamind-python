"""Controlled question-answering engine.

Source: Student + AI
"""

import re

from modules import analyzer
from modules.ai_client import request_structured_json
from modules.dataset_subject import infer_dataset_subject
from modules.semantic_detector import detect_field_semantics
from modules.skill_registry import allowed_skill_ids, skill_display_name, validate_skill_instruction


def parse_question(df, question):
    """Convert a natural-language question into a structured instruction."""
    text = question.strip()
    lowered = text.lower()
    columns = list(df.columns)
    mentioned_columns = _find_mentioned_columns(columns, lowered)
    mentioned_columns.extend(_find_alias_columns(columns, lowered))
    mentioned_columns = _dedupe(mentioned_columns)
    numeric_columns = list(df.select_dtypes(include="number").columns)
    datetime_columns = list(df.select_dtypes(include=["datetime", "datetimetz"]).columns)
    n = _extract_n(lowered)

    if _contains_any(lowered, ["多少行", "行数", "几行", "row count", "count rows"]):
        return {"intent": "count_rows"}

    if _contains_any(lowered, ["缺失", "空值", "missing", "null", "na"]):
        return {"intent": "missing_values"}

    if _contains_any(lowered, ["重复", "重复记录", "duplicate", "duplicates"]):
        return {"intent": "duplicate_rows", "n": n}

    if _contains_any(lowered, ["相关", "相关性", "correlation", "relationship"]):
        return {"intent": "correlation", "method": "pearson"}

    if _contains_any(lowered, ["异常", "离群", "极端值", "outlier", "outliers"]):
        column = _first_match(mentioned_columns, numeric_columns) or _first_or_none(numeric_columns)
        if column:
            return {"intent": "outlier_detection", "column": column, "method": "iqr", "n": n}

    if _contains_any(lowered, ["字段情况", "字段概况", "字段画像", "字段信息", "column profile"]):
        column = mentioned_columns[0] if mentioned_columns else _first_or_none(columns)
        if column:
            return {"intent": "column_profile", "column": column}

    if _contains_any(lowered, ["趋势", "变化", "随时间", "trend", "over time"]):
        time_column = _first_match(mentioned_columns, datetime_columns) or _guess_time_column(columns)
        value_column = _first_match(mentioned_columns, numeric_columns) or _first_or_none(numeric_columns)
        if time_column and value_column:
            return {
                "intent": "trend_analysis",
                "time_column": time_column,
                "value_column": value_column,
                "freq": "M",
                "agg": "sum",
            }

    if _contains_any(lowered, ["最高", "最低", "最大", "最小", "排行", "排名", "最贵", "最便宜"]):
        sort_column = _first_match(mentioned_columns, numeric_columns) or _first_or_none(numeric_columns)
        if sort_column:
            ascending = _contains_any(lowered, ["最低", "最小", "最便宜", "lowest", "smallest", "cheapest"])
            return {"intent": "top_records", "sort_column": sort_column, "n": n, "ascending": ascending}

    if _contains_any(lowered, ["求和", "总和", "合计", "sum"]):
        value_column = _first_match(mentioned_columns, numeric_columns) or _first_or_none(numeric_columns)
        group_column = _first_non_numeric_match(mentioned_columns, numeric_columns)
        if group_column is None:
            group_column = _guess_group_column(columns, numeric_columns)
        if group_column and value_column:
            return {
                "intent": "groupby_sum",
                "group_column": group_column,
                "value_column": value_column,
                "n": n,
            }

    if _contains_any(lowered, ["中位数", "median"]):
        value_column = _first_match(mentioned_columns, numeric_columns) or _first_or_none(numeric_columns)
        group_column = _first_non_numeric_match(mentioned_columns, numeric_columns)
        if group_column is None and _question_has_grouping(lowered):
            group_column = _guess_group_column(columns, numeric_columns)
        if group_column and value_column:
            return {
                "intent": "groupby_agg",
                "group_column": group_column,
                "value_column": value_column,
                "agg": "median",
                "n": n,
            }
        if value_column:
            return {"intent": "numeric_summary", "column": value_column}

    if _contains_any(lowered, ["平均", "均值", "mean", "average"]):
        value_column = _first_match(mentioned_columns, numeric_columns) or _first_or_none(numeric_columns)
        group_column = _first_non_numeric_match(mentioned_columns, numeric_columns)
        if group_column is None and _question_has_grouping(lowered):
            group_column = _guess_group_column(columns, numeric_columns)
        if group_column and value_column:
            return {
                "intent": "groupby_agg",
                "group_column": group_column,
                "value_column": value_column,
                "agg": "mean",
                "n": n,
            }
        if value_column:
            return {"intent": "numeric_summary", "column": value_column}

    if _looks_like_group_value_question(lowered):
        value_column = _first_match(mentioned_columns, numeric_columns)
        group_column = _first_non_numeric_match(mentioned_columns, numeric_columns)
        if group_column is None and _question_has_grouping(lowered):
            group_column = _guess_group_column(columns, numeric_columns)
        if group_column and value_column:
            return {
                "intent": "groupby_agg",
                "group_column": group_column,
                "value_column": value_column,
                "agg": "mean",
                "n": n,
            }

    if _contains_any(lowered, ["数值摘要", "统计描述", "描述统计", "summary", "describe"]):
        column = _first_match(mentioned_columns, numeric_columns) or _first_or_none(numeric_columns)
        if column:
            return {"intent": "numeric_summary", "column": column}

    if _contains_any(lowered, ["数量分布", "各类数量", "类别数量", "分别有多少", "各有多少", "不同"]) and _question_has_grouping(lowered):
        group_column = _first_non_numeric_match(mentioned_columns, numeric_columns) or _guess_group_column(columns, numeric_columns)
        if group_column:
            return {"intent": "groupby_count", "group_column": group_column, "n": n}

    if _contains_any(lowered, ["top", "前", "最多", "最常见", "频次", "排名", "分布", "数量分布", "各类数量", "类别数量", "占比"]):
        column = mentioned_columns[0] if mentioned_columns else _guess_group_column(columns, numeric_columns)
        if column:
            return {"intent": "top_n", "column": column, "n": n}

    return {
        "intent": "unsupported",
        "message": "暂时无法识别这个问题。可以尝试问：有多少行？哪些字段缺失最多？某字段 Top 10 是什么？按某字段求和？",
    }


def run_controlled_query(df, instruction):
    """Run a structured instruction through whitelisted analysis functions."""
    intent = instruction.get("intent")
    ok, validation_message = validate_skill_instruction(df, instruction)
    if not ok:
        return {
            "ok": False,
            "intent": intent,
            "error": instruction.get("message", "Unsupported analysis intent."),
            "validation": validation_message,
            "allowed_intents": allowed_skill_ids(),
        }

    try:
        if intent == "count_rows":
            result = analyzer.count_rows(df)
        elif intent == "missing_values":
            result = analyzer.missing_values(df)
        elif intent == "column_profile":
            result = analyzer.column_profile(df, instruction["column"])
        elif intent == "numeric_summary":
            result = analyzer.numeric_summary(df, instruction["column"])
        elif intent == "top_n":
            result = analyzer.top_n(df, instruction["column"], instruction.get("n", 10))
        elif intent == "groupby_count":
            result = analyzer.groupby_count(df, instruction["group_column"], instruction.get("n", 10))
        elif intent == "groupby_sum":
            result = analyzer.groupby_sum(
                df,
                instruction["group_column"],
                instruction["value_column"],
                instruction.get("n", 10),
            )
        elif intent == "groupby_agg":
            result = analyzer.groupby_agg(
                df,
                instruction["group_column"],
                instruction["value_column"],
                instruction.get("agg", "mean"),
                instruction.get("n", 10),
            )
        elif intent == "correlation":
            result = analyzer.correlation(df, instruction.get("method", "pearson"))
        elif intent == "trend_analysis":
            result = analyzer.trend_analysis(
                df,
                instruction["time_column"],
                instruction["value_column"],
                instruction.get("freq", "M"),
                instruction.get("agg", "sum"),
            )
        elif intent == "outlier_detection":
            result = analyzer.outlier_detection(
                df,
                instruction["column"],
                instruction.get("method", "iqr"),
                instruction.get("n", 20),
            )
        elif intent == "duplicate_rows":
            result = analyzer.duplicate_rows(df, instruction.get("subset"), instruction.get("n", 20))
        elif intent == "top_records":
            result = analyzer.top_records(
                df,
                instruction["sort_column"],
                instruction.get("n", 10),
                instruction.get("ascending", False),
            )
    except (KeyError, analyzer.AnalysisError) as exc:
        return {
            "ok": False,
            "intent": intent,
            "instruction": instruction,
            "error": str(exc),
            "validation": "执行时发现字段或参数不适合该 Skill。",
            "allowed_intents": allowed_skill_ids(),
        }

    return {
        "ok": True,
        "intent": intent,
        "skill_name": skill_display_name(intent),
        "instruction": instruction,
        "validation": validation_message,
        "allowed_intents": allowed_skill_ids(),
        "answer": _build_answer(intent, instruction, result),
        "summary": _build_user_summary(intent, instruction, result),
        "result": result,
    }


def answer_question(df, question):
    """Parse and answer a question using local deterministic rules."""
    instruction = parse_question(df, question)
    if instruction.get("intent") != "unsupported":
        response = run_controlled_query(df, instruction)
        response["parse_source"] = "本地规则"
        return response

    ai_plan, ai_error = parse_question_with_ai(df, question)
    if ai_plan:
        return run_ai_question_plan(df, question, ai_plan)

    response = run_controlled_query(df, instruction)
    response["parse_source"] = "本地规则"
    if ai_error:
        response["ai_parse_error"] = ai_error
    return response


def parse_question_with_ai(df, question):
    """Ask AI to convert a free-form question into a safe analysis plan."""
    payload = build_ai_parse_payload(df, question)
    prompt = (
        "你是 DataMind 的自由提问解析器。请把用户问题转换为安全分析计划。"
        "不要生成代码，不要编造字段，只能使用字段摘要中存在的字段和 Skill 白名单。"
        "如果一个 Skill 无法回答，可以拆成多个 Skill；如果仍然不能直接计算，请给 analysis_route。"
        "必须只返回 JSON 对象，格式为："
        '{"answer_type":"single_skill|multi_skill|analysis_route|unsupported",'
        '"instructions":[{"intent":"top_n","column":"room_type","n":10}],'
        '"route":["先查看数据质量"],"user_explanation":"...","reason":"..."}'
        f"\n\n输入摘要：{payload}"
    )
    data, error = request_structured_json(prompt, ai_parse_schema())
    if error or not data:
        return None, error or "AI 没有返回解析结果。"
    return data, None


def build_ai_parse_payload(df, question):
    """Build a safe payload for AI question parsing."""
    semantics = detect_field_semantics(df)
    subject = infer_dataset_subject(df)
    lowered = str(question).lower()
    mentioned_columns = set(_find_mentioned_columns(list(df.columns), lowered))
    mentioned_columns.update(_find_alias_columns(list(df.columns), lowered))
    fields = []
    semantic_rows = sorted(
        semantics.to_dict("records"),
        key=lambda row: (
            str(row["column"]) not in mentioned_columns,
            "智能分群" not in str(row["column"]),
        ),
    )
    for row in semantic_rows[:50]:
        fields.append(
            {
                "column": str(row["column"]),
                "semantic_role": str(row["semantic_role"]),
                "dtype": str(row["dtype"]),
                "missing_rate_%": float(row["missing_rate_%"]),
                "unique_count": int(row["unique_count"]),
            }
        )
    return {
        "question": question,
        "row_count": int(len(df)),
        "column_count": int(len(df.columns)),
        "subject": subject.get("subject", "通用表格数据"),
        "fields": fields,
        "allowed_skill_ids": allowed_skill_ids(),
    }


def ai_parse_schema():
    """Return the expected JSON schema for AI question parsing."""
    instruction_schema = {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "intent": {"type": "string"},
            "column": {"type": "string"},
            "group_column": {"type": "string"},
            "value_column": {"type": "string"},
            "time_column": {"type": "string"},
            "sort_column": {"type": "string"},
            "subset": {"type": "array", "maxItems": 5, "items": {"type": "string"}},
            "n": {"type": "integer"},
            "agg": {"type": "string"},
            "method": {"type": "string"},
            "freq": {"type": "string"},
            "ascending": {"type": "boolean"},
        },
        "required": [
            "intent",
            "column",
            "group_column",
            "value_column",
            "time_column",
            "sort_column",
            "subset",
            "n",
            "agg",
            "method",
            "freq",
            "ascending",
        ],
    }
    return {
        "name": "datamind_free_question_plan",
        "schema": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "answer_type": {"type": "string", "enum": ["single_skill", "multi_skill", "analysis_route", "unsupported"]},
                "instructions": {"type": "array", "maxItems": 5, "items": instruction_schema},
                "route": {"type": "array", "maxItems": 6, "items": {"type": "string"}},
                "user_explanation": {"type": "string"},
                "reason": {"type": "string"},
            },
            "required": ["answer_type", "instructions", "route", "user_explanation", "reason"],
        },
    }


def run_ai_question_plan(df, question, plan):
    """Run or explain an AI-generated analysis plan through local Skill controls."""
    answer_type = plan.get("answer_type")
    instructions = normalize_ai_instructions(plan.get("instructions", []))
    if answer_type == "single_skill" and instructions:
        response = run_controlled_query(df, instructions[0])
        response["parse_source"] = "AI 理解 + Skill 校验"
        response["ai_plan"] = plan
        return response

    if answer_type == "multi_skill" and instructions:
        results = []
        for instruction in instructions[:5]:
            result = run_controlled_query(df, instruction)
            results.append(result)
        ok_results = [result for result in results if result.get("ok")]
        return {
            "ok": bool(ok_results),
            "intent": "multi_skill",
            "skill_name": "组合分析计划",
            "instruction": {"intent": "multi_skill", "instructions": instructions},
            "validation": "AI 已将问题拆成多个 Skill，系统已逐项校验并执行可用部分。",
            "allowed_intents": allowed_skill_ids(),
            "answer": plan.get("user_explanation", "已生成组合分析计划。"),
            "summary": build_multi_skill_summary(plan, results),
            "result": results,
            "parse_source": "AI 理解 + 多 Skill 校验",
            "ai_plan": plan,
        }

    if answer_type == "analysis_route":
        return {
            "ok": True,
            "intent": "analysis_route",
            "skill_name": "分析路线",
            "instruction": {"intent": "analysis_route", "route": plan.get("route", [])},
            "validation": "该问题不适合直接计算，AI 已给出受控分析路线。",
            "allowed_intents": allowed_skill_ids(),
            "answer": plan.get("user_explanation", "已生成分析路线。"),
            "summary": build_route_summary(plan),
            "result": plan.get("route", []),
            "parse_source": "AI 理解 + 分析路线",
            "ai_plan": plan,
        }

    return {
        "ok": False,
        "intent": "unsupported",
        "error": plan.get("reason", "AI 未能把该问题转换为安全分析计划。"),
        "validation": "未执行任何代码或分析函数。",
        "allowed_intents": allowed_skill_ids(),
        "parse_source": "AI 理解失败",
        "ai_plan": plan,
    }


def normalize_ai_instructions(instructions):
    """Remove empty fields from AI instructions."""
    normalized = []
    for instruction in instructions:
        item = {}
        for key, value in instruction.items():
            if value in ["", None, [], {}]:
                continue
            item[key] = value
        if item.get("intent"):
            normalized.append(item)
    return normalized


def build_multi_skill_summary(plan, results):
    """Build a user-facing summary for multi-skill answers."""
    ok_results = [result for result in results if result.get("ok")]
    failed = [result for result in results if not result.get("ok")]
    main = f"系统将问题拆成 {len(results)} 个分析步骤，其中 {len(ok_results)} 个已成功执行。"
    if failed:
        main += f" 有 {len(failed)} 个步骤因字段或参数不适合被跳过。"
    return {
        "结论": plan.get("user_explanation", "已生成组合分析结果。"),
        "主要结果": main,
        "解释": "这类开放问题通常不能靠单个指标回答，系统会组合多个安全 Skill 形成初步判断。",
        "提醒": "组合分析仍然是探索性结果，不能直接证明因果关系。",
    }


def build_route_summary(plan):
    """Build a user-facing summary for analysis-route answers."""
    route = plan.get("route", [])
    return {
        "结论": plan.get("user_explanation", "这个问题更适合按步骤分析。"),
        "主要结果": "建议路线：" + "；".join(route[:5]) if route else "当前没有形成明确路线。",
        "解释": "该问题较开放，系统先给出可执行的分析路径，而不是编造单一结论。",
        "提醒": "请按路线补充图表、问答或报告段落后，再写入正式报告。",
    }


def _build_answer(intent, instruction, result):
    if intent == "count_rows":
        return f"当前数据共有 {result['row_count']} 行。"
    if intent == "missing_values":
        return "已完成缺失值分析，下面表格显示每个字段的缺失数量和缺失比例。"
    if intent == "column_profile":
        return f"已完成字段 {instruction['column']} 的基础画像。"
    if intent == "numeric_summary":
        return f"已完成字段 {instruction['column']} 的数值摘要。"
    if intent == "top_n":
        return f"已计算字段 {instruction['column']} 的 Top {instruction.get('n', 10)} 频次。"
    if intent == "groupby_count":
        return f"已按 {instruction['group_column']} 统计记录数量。"
    if intent == "groupby_sum":
        return (
            f"已按 {instruction['group_column']} 对 {instruction['value_column']} 求和，"
            f"并返回前 {instruction.get('n', 10)} 组。"
        )
    if intent == "groupby_agg":
        return (
            f"已按 {instruction['group_column']} 对 {instruction['value_column']} "
            f"执行 {instruction.get('agg', 'mean')} 聚合。"
        )
    if intent == "correlation":
        return "已完成数值字段相关性分析。注意：相关不代表因果。"
    if intent == "trend_analysis":
        return f"已计算 {instruction['value_column']} 随 {instruction['time_column']} 的时间趋势。"
    if intent == "outlier_detection":
        return f"已检查 {instruction['column']} 中的异常值。"
    if intent == "duplicate_rows":
        return "已完成重复记录检查。"
    if intent == "top_records":
        direction = "最低" if instruction.get("ascending") else "最高"
        return f"已按 {instruction['sort_column']} 找出{direction}的记录。"
    return "已完成分析。"


def _build_user_summary(intent, instruction, result):
    """Build user-facing answer sections for one controlled QA result."""
    if intent == "count_rows":
        row_count = result["row_count"]
        return {
            "结论": f"这份数据当前共有 {row_count} 条记录。",
            "主要结果": f"样本规模为 {row_count} 行，可以作为后续分析和报告开头的基础背景。",
            "解释": "行数越多，通常越适合做分组、趋势和相关性分析；行数较少时，分组结果需要谨慎解释。",
            "提醒": "行数只说明样本大小，不代表数据一定完整或可靠，还需要结合缺失值、重复记录和极端值一起判断。",
        }

    if intent == "missing_values":
        sorted_result = result.sort_values("missing_count", ascending=False)
        nonzero = sorted_result[sorted_result["missing_count"] > 0]
        if nonzero.empty:
            conclusion = "当前没有发现明显缺失值。"
            main = "所有字段的缺失数量都为 0，数据完整性表现较好。"
        else:
            top = nonzero.iloc[0]
            conclusion = f"缺失最多的字段是 {top['column']}，缺失率为 {top['missing_rate_%']}%。"
            main = f"{top['column']} 有 {top['missing_count']} 个缺失值，是当前最需要先确认的数据质量问题。"
        return {
            "结论": conclusion,
            "主要结果": main,
            "解释": "缺失值会影响平均值、分组比较和报告结论，缺失较多的字段不适合直接作为核心依据。",
            "提醒": "缺失不一定是错误，也可能表示该信息本来不存在。处理前建议先判断缺失原因。",
        }

    if intent == "column_profile":
        top_values = result.get("top_values")
        top_text = "暂无常见取值。"
        if top_values is not None and not top_values.empty:
            first = top_values.iloc[0]
            top_text = f"最常见取值是“{first[result['column']]}”，出现 {int(first['count'])} 次。"
        return {
            "结论": f"{result['column']} 是一个 {result['dtype']} 类型字段。",
            "主要结果": f"共有 {result['unique_count']} 个不同取值，缺失率为 {result['missing_rate_%']}%。{top_text}",
            "解释": "字段画像适合用来判断这个字段更适合做分类、筛选、分组还是数值计算。",
            "提醒": "字段类型来自程序识别，少数字段可能需要先清洗后再分析，例如价格被读成文本。",
        }

    if intent == "numeric_summary":
        return {
            "结论": f"{result['column']} 的典型水平约为 {_format_number(result['median'])}。",
            "主要结果": (
                f"平均值 {_format_number(result['mean'])}，中位数 {_format_number(result['median'])}，"
                f"最小值 {_format_number(result['min'])}，最大值 {_format_number(result['max'])}。"
            ),
            "解释": "中位数更能代表一般水平，平均值容易被极端高值或低值影响。",
            "提醒": "如果最大值和中位数差距很大，建议继续检查异常值，避免后续结论被极端记录拉偏。",
        }

    if intent == "top_n":
        column = instruction["column"]
        if result.empty:
            return _empty_summary("这个字段暂时没有可统计的有效取值。")
        top = result.iloc[0]
        total = float(result["count"].sum())
        share = float(top["count"]) / total * 100 if total else 0
        return {
            "结论": f"{column} 中出现最多的是“{top[column]}”。",
            "主要结果": f"在当前 Top {instruction.get('n', 10)} 结果中，“{top[column]}”出现 {int(top['count'])} 次，占比约 {share:.1f}%。",
            "解释": "这个结果能帮助判断数据是否集中在少数类别上，也适合作为类别分布图的起点。",
            "提醒": "Top N 只展示高频类别，不代表所有类别的完整分布；如果类别很多，建议继续看完整分布或图表。",
        }

    if intent == "groupby_count":
        group_column = instruction["group_column"]
        if result.empty:
            return _empty_summary("这个字段暂时没有可统计的类别数量。")
        top = result.iloc[0]
        return {
            "结论": f"{group_column} 中数量最多的是“{top[group_column]}”。",
            "主要结果": f"“{top[group_column]}”共有 {int(top['count'])} 条记录，在当前结果中占比约 {top['share_%']}%。",
            "解释": "分组数量能帮助判断数据主要集中在哪些类别上，也适合作为后续筛选和可视化的起点。",
            "提醒": "这里显示的是记录数量，不代表该类别一定更重要，还需要结合价格、评分等指标继续分析。",
        }

    if intent in ["groupby_sum", "groupby_agg"]:
        group_column = instruction["group_column"]
        value_column = instruction["value_column"]
        agg = "sum" if intent == "groupby_sum" else instruction.get("agg", "mean")
        y_column = f"{value_column}_{agg}"
        if result.empty or y_column not in result:
            return _empty_summary("当前分组结果为空，可能是字段缺失或没有可计算的数值。")
        ranked = result.dropna(subset=[y_column]).sort_values(y_column, ascending=False)
        if ranked.empty:
            return _empty_summary("当前分组结果没有可比较的有效数值。")
        top = ranked.iloc[0]
        bottom = ranked.iloc[-1]
        agg_label = {"sum": "总和", "mean": "平均值", "median": "中位数", "count": "数量"}.get(agg, agg)
        gap_text = _format_gap(top[y_column], bottom[y_column])
        return {
            "结论": f"不同 {group_column} 的 {value_column} {agg_label}存在差异。",
            "主要结果": f"{top[group_column]} 最高，约为 {_format_number(top[y_column])}；{bottom[group_column]} 最低，约为 {_format_number(bottom[y_column])}。{gap_text}",
            "解释": "这个结果可以帮助比较不同类别之间的表现，适合继续用柱状图或表格作为报告证据。",
            "提醒": "分组结果可能受样本量、缺失值和极端值影响。差异明显不等于因果关系，需要结合业务背景解释。",
        }

    if intent == "correlation":
        pair = _strongest_correlation_pair(result)
        if pair is None:
            return {
                "结论": "当前没有发现特别明显的数值字段相关关系。",
                "主要结果": "相关系数矩阵中没有达到较明显阈值的字段组合。",
                "解释": "这说明当前数值字段之间未呈现强同步变化，或关系不是线性的。",
                "提醒": "相关性只能衡量同步变化趋势，不能证明因果关系。",
            }
        col_a, col_b, value = pair
        direction = "正相关" if value > 0 else "负相关"
        strength = _correlation_strength(abs(value))
        return {
            "结论": f"{col_a} 和 {col_b} 呈现{strength}{direction}。",
            "主要结果": f"相关系数约为 {value:.2f}。",
            "解释": "这表示两个字段可能存在同步变化倾向，适合继续用散点图检查关系形态。",
            "提醒": "相关不等于因果；如果存在极端值或样本分布不均，相关系数可能被拉偏。",
        }

    if intent == "trend_analysis":
        time_column = instruction["time_column"]
        value_column = instruction["value_column"]
        agg = instruction.get("agg", "sum")
        y_column = f"{value_column}_{agg}"
        if result.empty or y_column not in result:
            return _empty_summary("当前没有形成可比较的时间趋势结果。")
        ordered = result.dropna(subset=[y_column])
        if len(ordered) < 2:
            return _empty_summary("时间点数量太少，暂时无法判断趋势。")
        first = ordered.iloc[0][y_column]
        last = ordered.iloc[-1][y_column]
        direction = "上升" if last > first else ("下降" if last < first else "基本持平")
        return {
            "结论": f"{value_column} 随 {time_column} 的变化趋势为{direction}。",
            "主要结果": f"首期约为 {_format_number(first)}，末期约为 {_format_number(last)}。",
            "解释": "这个结果可以帮助判断是否存在时间上的增长、下降或波动。",
            "提醒": "趋势分析受时间粒度和样本量影响。如果时间字段不连续，结论需要谨慎。",
        }

    if intent == "outlier_detection":
        column = result["column"]
        count = result["outlier_count"]
        if count == 0:
            return {
                "结论": f"{column} 暂未发现明显异常值。",
                "主要结果": f"按 IQR 规则检查，合理范围约为 {_format_number(result['lower_bound'])} 到 {_format_number(result['upper_bound'])}。",
                "解释": "这说明该字段的极端高低值风险较低，后续均值和分组分析相对更稳定。",
                "提醒": "规则检测只能发现统计上的极端值，不能判断这些值一定错误。",
            }
        return {
            "结论": f"{column} 中发现 {count} 条可能的异常记录。",
            "主要结果": f"异常值占比约 {result['outlier_rate_%']}%，合理范围约为 {_format_number(result['lower_bound'])} 到 {_format_number(result['upper_bound'])}。",
            "解释": "异常值可能是真实的特殊情况，也可能是录入或格式问题；它们会明显影响平均值、总和和排行。",
            "提醒": "建议先查看异常记录，再决定保留、修正还是在报告中说明限制。",
        }

    if intent == "duplicate_rows":
        count = result["duplicate_count"]
        if count == 0:
            conclusion = "当前没有发现重复记录。"
            main = "按当前检查范围，重复记录数量为 0。"
        else:
            conclusion = f"当前发现 {count} 条重复记录。"
            main = f"重复记录占比约 {result['duplicate_rate_%']}%，检查范围为 {result['checked_columns']}。"
        return {
            "结论": conclusion,
            "主要结果": main,
            "解释": "重复记录会让数量、总和和平均值被重复计算，影响后续分析可靠性。",
            "提醒": "重复不一定都要删除，有些数据天然允许同一对象多次出现，处理前要先确认含义。",
        }

    if intent == "top_records":
        sort_column = instruction["sort_column"]
        if result.empty:
            return _empty_summary("当前没有可排序的记录。")
        direction = "最低" if instruction.get("ascending") else "最高"
        top = result.iloc[0]
        return {
            "结论": f"按 {sort_column} 排序，{direction}的记录值为 {_format_number(top[sort_column])}。",
            "主要结果": f"已返回前 {len(result)} 条记录，可直接查看具体对象和相关字段。",
            "解释": "记录排行适合回答“哪个对象最高/最低/最贵/最便宜”这类问题。",
            "提醒": "排行结果容易受异常值影响，如果数值很夸张，建议再做异常值检查。",
        }

    return _empty_summary("已完成该问题对应的受控分析。")


def _empty_summary(message):
    return {
        "结论": message,
        "主要结果": "当前没有足够结果可进一步展开。",
        "解释": "可能是字段缺失、数据量太少或字段类型不适合该分析。",
        "提醒": "可以换一个字段重新提问，或先进入数据概览查看适合分析的字段。",
    }


def _format_number(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)
    if abs(number) >= 1000:
        return f"{number:,.2f}"
    return f"{number:.2f}".rstrip("0").rstrip(".")


def _format_gap(top_value, bottom_value):
    try:
        top = float(top_value)
        bottom = float(bottom_value)
    except (TypeError, ValueError):
        return ""
    return f"两者相差约 {_format_number(top - bottom)}。"


def _strongest_correlation_pair(corr_df):
    if corr_df.empty:
        return None
    best = None
    columns = list(corr_df.columns)
    for index, col_a in enumerate(columns):
        for col_b in columns[index + 1 :]:
            value = corr_df.loc[col_a, col_b]
            if value != value:
                continue
            value = float(value)
            if best is None or abs(value) > abs(best[2]):
                best = (col_a, col_b, value)
    if best and abs(best[2]) >= 0.3:
        return best
    return None


def _correlation_strength(value):
    if value >= 0.7:
        return "较强"
    if value >= 0.5:
        return "中等"
    return "较弱"


def _find_mentioned_columns(columns, lowered_question):
    return [column for column in columns if str(column).lower() in lowered_question]


FIELD_ALIASES = {
    "房型": ["room_type", "property_type"],
    "房源类型": ["room_type", "property_type"],
    "房产类型": ["property_type", "room_type"],
    "价格": ["price", "amount", "cost", "fee"],
    "房价": ["price"],
    "街区": ["neighbourhood_cleansed", "neighbourhood", "neighborhood", "district"],
    "地区": ["neighbourhood_cleansed", "neighbourhood", "neighborhood", "city", "region"],
    "区域": ["neighbourhood_cleansed", "neighbourhood", "neighborhood", "city", "region"],
    "评分": ["review_scores_rating", "rating", "score"],
    "评价": ["review_scores_rating", "rating", "number_of_reviews", "reviews_per_month"],
    "评论数": ["number_of_reviews", "reviews_per_month", "review_count"],
    "评论": ["number_of_reviews", "reviews_per_month", "review_scores_rating"],
    "可订天数": ["availability_365", "availability_30", "availability_60", "availability_90"],
    "可住人数": ["accommodates"],
    "卧室": ["bedrooms"],
    "床位": ["beds"],
    "卫生间": ["bathrooms", "bathrooms_text"],
    "房东": ["host_id", "host_name", "host_is_superhost"],
    "超赞房东": ["host_is_superhost"],
    "智能分群": ["智能分群", "智能分群结果"],
    "分群": ["智能分群", "智能分群结果"],
    "组别": ["智能分群", "智能分群结果"],
}


def _find_alias_columns(columns, lowered_question):
    matched = []
    for alias, candidates in FIELD_ALIASES.items():
        if alias not in lowered_question:
            continue
        column = _first_existing_column(columns, candidates)
        if column:
            matched.append(column)
    return matched


def _first_existing_column(columns, candidates):
    lowered_map = {str(column).lower(): column for column in columns}
    for candidate in candidates:
        candidate_lowered = candidate.lower()
        if candidate_lowered in lowered_map:
            return lowered_map[candidate_lowered]
    for column in columns:
        lowered = str(column).lower()
        if any(candidate.lower() in lowered for candidate in candidates):
            return column
    return None


def _dedupe(values):
    seen = set()
    result = []
    for value in values:
        if value in seen:
            continue
        seen.add(value)
        result.append(value)
    return result


def _extract_n(lowered_question):
    match = re.search(r"(?:top|前)\s*(\d+)", lowered_question)
    if match:
        return int(match.group(1))
    match = re.search(r"(\d+)\s*(?:个|项|名|组)", lowered_question)
    if match:
        return int(match.group(1))
    return 10


def _contains_any(text, keywords):
    return any(keyword in text for keyword in keywords)


def _question_has_grouping(text):
    return _contains_any(text, ["不同", "按", "各", "每个", "每种", "分组", "组别", "分群", "by "])


def _looks_like_group_value_question(text):
    """Return whether a vague question asks for a metric by groups."""
    return _question_has_grouping(text) and _contains_any(text, ["情况", "如何", "怎么样", "差异", "表现", "水平"])


def _first_match(candidates, allowed):
    for candidate in candidates:
        if candidate in allowed:
            return candidate
    return None


def _first_non_numeric_match(candidates, numeric_columns):
    for candidate in candidates:
        if candidate not in numeric_columns:
            return candidate
    return None


def _first_or_none(values):
    return values[0] if values else None


def _guess_group_column(columns, numeric_columns):
    for column in columns:
        if column not in numeric_columns:
            return column
    return columns[0] if columns else None


def _guess_time_column(columns):
    time_keywords = ["date", "time", "year", "month", "日期", "时间", "年份", "月份"]
    for column in columns:
        lowered = str(column).lower()
        if any(keyword in lowered for keyword in time_keywords):
            return column
    return None
