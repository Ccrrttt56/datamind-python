"""Skill registry for controlled local data analysis.

Source: Student + AI
"""

import pandas as pd

from modules import analyzer


SKILL_REGISTRY = {
    "count_rows": {
        "name": "数据规模统计",
        "question_type": "数据有多少行",
        "description": "统计当前数据表的记录数量。",
        "required_fields": [],
        "parameters": [],
        "function": analyzer.count_rows,
    },
    "missing_values": {
        "name": "缺失值检查",
        "question_type": "哪些字段缺失最多",
        "description": "计算各字段的缺失数量和缺失比例。",
        "required_fields": [],
        "parameters": [],
        "function": analyzer.missing_values,
    },
    "column_profile": {
        "name": "字段画像",
        "question_type": "某个字段整体情况怎么样",
        "description": "查看指定字段的类型、缺失、唯一值数量和常见取值。",
        "required_fields": ["column"],
        "parameters": [],
        "function": analyzer.column_profile,
    },
    "numeric_summary": {
        "name": "数值摘要",
        "question_type": "某个数值字段的平均值、中位数和范围是多少",
        "description": "计算指定数值字段的均值、中位数、最大最小值和四分位数。",
        "required_fields": ["column"],
        "parameters": [],
        "function": analyzer.numeric_summary,
    },
    "top_n": {
        "name": "类别频次分析",
        "question_type": "某个字段里哪些类别最多",
        "description": "统计指定字段中最常见的取值。",
        "required_fields": ["column"],
        "parameters": ["n"],
        "function": analyzer.top_n,
    },
    "groupby_count": {
        "name": "分组数量统计",
        "question_type": "不同类别分别有多少条记录",
        "description": "按一个类别字段统计记录数量和占比。",
        "required_fields": ["group_column"],
        "parameters": ["n"],
        "function": analyzer.groupby_count,
    },
    "groupby_sum": {
        "name": "分组求和分析",
        "question_type": "不同类别的总量有什么差异",
        "description": "按类别字段分组，对数值字段求和。",
        "required_fields": ["group_column", "value_column"],
        "parameters": ["n"],
        "function": analyzer.groupby_sum,
    },
    "groupby_agg": {
        "name": "分组聚合分析",
        "question_type": "不同类别的平均值有什么差异",
        "description": "按类别字段分组，对数值字段求平均值等聚合。",
        "required_fields": ["group_column", "value_column"],
        "parameters": ["agg", "n"],
        "function": analyzer.groupby_agg,
    },
    "correlation": {
        "name": "相关性分析",
        "question_type": "两个或多个数值字段有没有关系",
        "description": "计算数值字段之间的相关系数。",
        "required_fields": [],
        "parameters": ["method"],
        "function": analyzer.correlation,
    },
    "trend_analysis": {
        "name": "趋势分析",
        "question_type": "某个数值是否随时间变化",
        "description": "按时间字段聚合数值字段，观察变化趋势。",
        "required_fields": ["time_column", "value_column"],
        "parameters": ["freq", "agg"],
        "function": analyzer.trend_analysis,
    },
    "outlier_detection": {
        "name": "异常值检测",
        "question_type": "某个数值字段有没有明显异常值",
        "description": "使用受控规则标记数值字段中的极端高值或低值。",
        "required_fields": ["column"],
        "parameters": ["method", "n"],
        "function": analyzer.outlier_detection,
    },
    "duplicate_rows": {
        "name": "重复记录检查",
        "question_type": "数据里有没有重复记录",
        "description": "检查整行或指定字段组合是否存在重复记录。",
        "required_fields": [],
        "parameters": ["subset", "n"],
        "function": analyzer.duplicate_rows,
    },
    "top_records": {
        "name": "记录排行",
        "question_type": "按某个数值字段找最高或最低的记录",
        "description": "按指定字段排序，返回排名靠前的原始记录。",
        "required_fields": ["sort_column"],
        "parameters": ["n", "ascending"],
        "function": analyzer.top_records,
    },
}


def allowed_skill_ids():
    """Return all whitelisted skill ids."""
    return sorted(SKILL_REGISTRY)


def get_skill(skill_id):
    """Return one registered skill, or None if it is not whitelisted."""
    return SKILL_REGISTRY.get(skill_id)


def skill_display_name(skill_id):
    """Return a user-facing skill name."""
    skill = get_skill(skill_id)
    return skill["name"] if skill else str(skill_id)


def skill_function(skill_id):
    """Return the local function bound to a skill."""
    skill = get_skill(skill_id)
    return skill["function"] if skill else None


def list_skills():
    """Return a user-facing skill registry table."""
    rows = []
    for skill_id, skill in SKILL_REGISTRY.items():
        rows.append(
            {
                "Skill ID": skill_id,
                "Skill 名称": skill["name"],
                "能回答什么": skill["question_type"],
                "需要字段": "、".join(skill["required_fields"]) if skill["required_fields"] else "无需指定字段",
                "参数": "、".join(skill["parameters"]) if skill["parameters"] else "无",
                "本地函数": skill["function"].__name__,
            }
        )
    return pd.DataFrame(rows)


def validate_skill_instruction(df, instruction):
    """Validate a structured instruction before local skill execution."""
    skill_id = instruction.get("intent")
    skill = get_skill(skill_id)
    if skill is None:
        return False, "该 Skill 不在白名单中。"

    missing_keys = [key for key in skill["required_fields"] if not instruction.get(key)]
    if missing_keys:
        return False, "缺少必要字段：" + "、".join(missing_keys)

    columns = set(df.columns)
    for key in ["column", "group_column", "value_column", "time_column", "sort_column"]:
        value = instruction.get(key)
        if value and value not in columns:
            return False, f"字段“{value}”不存在。"

    numeric_columns = set(df.select_dtypes(include="number").columns)
    if instruction.get("value_column") and instruction["value_column"] not in numeric_columns:
        return False, f"字段“{instruction['value_column']}”不是数值字段，不能用于数值计算。"
    if skill_id in {"numeric_summary", "outlier_detection"} and instruction.get("column") not in numeric_columns:
        return False, f"字段“{instruction.get('column')}”不是数值字段，不能用于数值计算。"

    if instruction.get("n") is not None:
        try:
            n = int(instruction["n"])
        except (TypeError, ValueError):
            return False, "Top N 参数必须是整数。"
        if n < 1 or n > 50:
            return False, "Top N 参数需要在 1 到 50 之间。"
        instruction["n"] = n

    if instruction.get("agg") and instruction["agg"] not in {"sum", "mean", "median", "max", "min", "count"}:
        return False, "聚合方式不在允许范围内。"

    if skill_id == "outlier_detection" and instruction.get("method") not in {None, "iqr"}:
        return False, "异常值检测方法不在允许范围内。"

    if skill_id != "outlier_detection" and instruction.get("method") and instruction["method"] not in {"pearson", "spearman", "kendall"}:
        return False, "相关性方法不在允许范围内。"

    subset = instruction.get("subset")
    if subset:
        if not isinstance(subset, list):
            return False, "重复记录字段需要是字段列表。"
        missing_subset = [column for column in subset if column not in columns]
        if missing_subset:
            return False, "字段不存在：" + "、".join(missing_subset)

    if instruction.get("ascending") is not None and not isinstance(instruction["ascending"], bool):
        return False, "排序方向参数必须是布尔值。"

    return True, "字段和参数校验通过。"
