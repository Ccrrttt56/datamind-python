"""Dataset analysis capability detection utilities.

Source: Student + AI
"""

import pandas as pd

from modules.semantic_detector import detect_field_semantics


def detect_capabilities(df):
    """Return which analysis capabilities are available for the current dataset."""
    semantics = detect_field_semantics(df)
    roles = set(semantics["semantic_role"])
    numeric_columns = list(df.select_dtypes(include="number").columns)
    datetime_columns = list(df.select_dtypes(include=["datetime", "datetimetz"]).columns)
    category_columns = semantics.loc[
        semantics["semantic_role"].isin(["类别字段", "地区字段", "ID 字段", "评分字段"]),
        "column",
    ].tolist()
    text_columns = semantics.loc[
        semantics["semantic_role"].isin(["文本字段", "文本描述字段"]),
        "column",
    ].tolist()

    possible_time_columns = datetime_columns + semantics.loc[
        semantics["semantic_role"] == "时间字段",
        "column",
    ].tolist()
    possible_time_columns = list(dict.fromkeys(possible_time_columns))

    return pd.DataFrame(
        [
            _capability_row(
                "时间趋势分析",
                bool(possible_time_columns and numeric_columns),
                "需要时间字段和至少一个数值字段。",
                {"time_columns": possible_time_columns, "numeric_columns": numeric_columns},
            ),
            _capability_row(
                "类别分布分析",
                bool(category_columns),
                "需要类别、地区、ID 或评分候选字段。",
                {"category_columns": category_columns},
            ),
            _capability_row(
                "数值分布分析",
                bool(numeric_columns),
                "需要至少一个数值字段。",
                {"numeric_columns": numeric_columns},
            ),
            _capability_row(
                "分组聚合分析",
                bool(category_columns and numeric_columns),
                "需要分组字段和数值字段。",
                {"group_columns": category_columns, "numeric_columns": numeric_columns},
            ),
            _capability_row(
                "相关性分析",
                len(numeric_columns) >= 2,
                "需要至少两个数值字段。",
                {"numeric_columns": numeric_columns},
            ),
            _capability_row(
                "异常检测",
                bool(numeric_columns),
                "需要至少一个数值字段。",
                {"numeric_columns": numeric_columns},
            ),
            _capability_row(
                "聚类分析",
                len(numeric_columns) >= 2,
                "需要至少两个数值字段。",
                {"numeric_columns": numeric_columns},
            ),
            _capability_row(
                "文本分析/词云",
                bool(text_columns) or "文本描述字段" in roles,
                "需要文本或描述字段。",
                {"text_columns": text_columns},
            ),
        ]
    )


def _capability_row(name, supported, reason, evidence):
    return {
        "capability": name,
        "supported": "支持" if supported else "暂不支持",
        "reason": reason,
        "evidence": _format_evidence(evidence),
    }


def _format_evidence(evidence):
    parts = []
    for key, values in evidence.items():
        if not values:
            continue
        preview = ", ".join(map(str, values[:5]))
        suffix = "..." if len(values) > 5 else ""
        parts.append(f"{key}: {preview}{suffix}")
    return "；".join(parts) if parts else "当前数据缺少所需字段。"
