# DataMind

DataMind is a table data analysis assistant for non-technical students.

## Goal

Help users upload CSV/Excel data, clean and understand the dataset, run analysis, create charts, ask controlled natural-language questions, and generate report materials.

## Current Status

Project skeleton created. The next step is implementing CSV/Excel loading and basic dataset profiling.

## Structure

```text
DataMind/
├── app.py
├── modules/
├── skills/
├── data/
├── outputs/
├── tests/
├── README.md
├── requirements.txt
└── AI_USAGE.md
```

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```
