# Chart Selection Rules

Source: Student + AI

- Time field + numeric field: line chart.
- Category field + numeric field: bar chart.
- Numeric field: histogram or box chart.
- Multiple numeric fields: correlation heatmap.
- Cluster result: PCA scatter plot.
