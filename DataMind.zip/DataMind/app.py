"""DataMind Streamlit entry point.

Source: Student + AI
"""

from pathlib import Path
from contextlib import contextmanager
from datetime import datetime
import hashlib
import html
import json
import re

import pandas as pd
import plotly.express as px
import streamlit as st
from wordcloud import WordCloud
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.platypus import ListFlowable, ListItem, Paragraph, SimpleDocTemplate, Spacer
from reportlab.platypus.flowables import HRFlowable
from io import BytesIO

from modules.analyzer import (
    AnalysisError,
    cluster_analysis,
    correlation,
    count_rows,
    groupby_agg,
    groupby_sum,
    missing_values,
    text_word_frequency,
    top_n,
    trend_analysis,
)
from modules.ai_config import ai_status
try:
    from modules.ai_config import debug_mode_enabled
except ImportError:
    def debug_mode_enabled():
        """Fallback for stale Streamlit imports; debug UI stays off."""
        return False
from modules.ai_client import request_structured_json
from modules.data_loader import DataLoadError, read_table
from modules.conclusion_checker import check_conclusion_support
from modules.dataset_subject import infer_dataset_subject
from modules.field_translator import (
    display_field_label,
    display_text_with_field_labels,
    display_value_label,
    local_translate_field_name,
    translate_display_values,
    translate_field_names,
)
from modules.preprocessor import auto_convert_types, clean_table
from modules.profiler import profile_table as raw_profile_table
from modules.quality_checker import quality_report
from modules.qa_engine import answer_question, run_controlled_query
from modules.recommender import (
    question_referenced_fields,
    recommend_analysis_directions,
    recommend_charts,
    recommend_questions,
    recommendation_status,
)
from modules.skill_registry import list_skills, skill_display_name
from modules.visualizer import bar_chart, box_chart, heatmap, histogram, line_chart, pie_chart, scatter_chart


st.set_page_config(
    page_title="DataMind",
    layout="wide",
    menu_items={
        "About": "DataMind：面向非技术学生的表格数据分析助手。",
    },
)

BASE_DIR = Path(__file__).resolve().parent
SAMPLE_DATASET_PATH = BASE_DIR / "data" / "sample" / "listings.csv"
RECOMMENDATION_CACHE_VERSION = "20260609-14"


def apply_theme():
    """Apply a professional DataMind workspace visual style."""
    st.markdown(
        """
        <style>
        :root {
            --dm-blue: #2457d6;
            --dm-blue-strong: #1d4ed8;
            --dm-blue-soft: #eef4ff;
            --dm-teal: #0f9f8f;
            --dm-amber: #b7791f;
            --dm-rose: #be123c;
            --dm-bg: #f5f7fb;
            --dm-surface: #ffffff;
            --dm-surface-2: #fbfcff;
            --dm-text: #101828;
            --dm-muted: #667085;
            --dm-soft: #98a2b3;
            --dm-border: #d9e1ec;
            --dm-border-soft: #edf1f7;
            --dm-sidebar-width: 22rem;
            --dm-page-x: 2.25rem;
            --dm-shadow: 0 10px 30px rgba(16, 24, 40, 0.07);
            --dm-shadow-soft: 0 4px 16px rgba(16, 24, 40, 0.045);
        }

        .stApp {
            background: var(--dm-bg);
            color: var(--dm-text);
        }

        .stApp,
        .stApp p,
        .stApp label,
        .stApp span,
        .stApp div {
            color: var(--dm-text);
        }

        [data-testid="stSidebar"] {
            background: linear-gradient(180deg, #ffffff 0%, #f8fbff 100%);
            border-right: 1px solid var(--dm-border);
            box-shadow: 6px 0 24px rgba(16, 24, 40, 0.035);
        }

        [data-testid="stSidebar"] > div {
            background: transparent;
            padding-top: 1.3rem;
        }

        [data-testid="stSidebar"] h1,
        [data-testid="stSidebar"] h2,
        [data-testid="stSidebar"] h3 {
            color: var(--dm-text);
        }

        .block-container {
            padding-top: 2.25rem;
            padding-bottom: 2.5rem;
            max-width: 1320px;
        }

        .dm-hero {
            background:
                linear-gradient(135deg, rgba(36, 87, 214, 0.08), rgba(15, 159, 143, 0.06)),
                var(--dm-surface);
            border: 1px solid var(--dm-border);
            border-radius: 8px;
            padding: 20px 22px;
            margin-bottom: 16px;
            box-shadow: var(--dm-shadow-soft);
        }

        .dm-kicker {
            color: var(--dm-blue);
            font-size: 12px;
            font-weight: 800;
            letter-spacing: 0;
            margin: 0 0 6px 0;
        }

        .dm-title {
            color: var(--dm-text);
            font-size: 29px;
            font-weight: 760;
            line-height: 1.15;
            margin: 0;
        }

        .dm-subtitle {
            color: var(--dm-muted);
            font-size: 14px;
            margin-top: 7px;
            max-width: 860px;
        }

        .dm-badge-row {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-top: 15px;
        }

        .dm-badge {
            background: #ffffff;
            border: 1px solid #c7d7fe;
            border-radius: 999px;
            color: var(--dm-blue-strong);
            font-size: 13px;
            font-weight: 650;
            padding: 5px 11px;
        }

        .dm-module-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 12px;
            margin-top: 14px;
        }

        .dm-module-card {
            background: var(--dm-surface);
            border: 1px solid var(--dm-border);
            border-radius: 8px;
            padding: 16px;
            box-shadow: var(--dm-shadow-soft);
        }

        .dm-module-card-title {
            margin: 0 0 6px 0;
            color: var(--dm-text);
            font-size: 16px;
            font-weight: 760;
        }

        .dm-module-card-text {
            margin: 0;
            color: var(--dm-muted);
            font-size: 13px;
            line-height: 1.55;
        }

        .dm-sidebar-title {
            font-size: 25px;
            font-weight: 780;
            color: var(--dm-text);
            margin: 0 0 4px 0;
        }

        .dm-sidebar-intro {
            color: var(--dm-muted);
            font-size: 13px;
            line-height: 1.55;
            margin: 0 0 14px 0;
        }

        .dm-sidebar-brand {
            padding: 4px 2px 2px 2px;
        }

        .dm-sidebar-label {
            color: #344054;
            font-size: 12px;
            font-weight: 800;
            margin: 16px 0 7px 0;
            text-transform: uppercase;
        }

        .dm-sidebar-tip {
            color: var(--dm-muted);
            font-size: 12px;
            line-height: 1.45;
            margin: -3px 0 12px 0;
        }

        [data-testid="stSidebar"] div.stButton > button[kind="primary"] {
            background: var(--dm-blue);
            border: 1px solid var(--dm-blue);
            color: #ffffff;
            font-weight: 760;
        }

        [data-testid="stSidebar"] div.stButton > button[kind="primary"] p,
        [data-testid="stSidebar"] div.stButton > button[kind="primary"] span {
            color: #ffffff;
        }

        [data-testid="stSidebar"] div.stButton > button[kind="primary"]:hover {
            background: #1d4ed8;
            border-color: #1d4ed8;
            color: #ffffff;
        }

        @media (max-width: 900px) {
            :root {
                --dm-page-x: 1rem;
            }
        }

        .dm-section {
            background: transparent;
            border-left: 4px solid var(--dm-blue);
            padding: 3px 0 3px 14px;
            margin: 20px 0 12px 0;
        }

        .dm-module-body {
            margin-top: 10px;
        }

        .dm-section-title {
            color: var(--dm-text);
            font-size: 22px;
            font-weight: 760;
            margin: 0 0 4px 0;
        }

        .dm-section-note {
            color: var(--dm-muted);
            font-size: 13px;
            margin: 0;
        }

        .dm-analysis-source {
            margin-top: 14px;
            padding-top: 4px;
        }

        .dm-speed-card {
            background: var(--dm-surface);
            border: 1px solid var(--dm-border);
            border-radius: 8px;
            padding: 18px 20px;
            margin: 14px 0;
            box-shadow: var(--dm-shadow-soft);
        }

        .dm-speed-card-blue {
            background: linear-gradient(180deg, #f8fbff 0%, #ffffff 100%);
            border-left: 4px solid var(--dm-blue);
        }

        .dm-speed-card-teal {
            background: linear-gradient(180deg, #f5fffd 0%, #ffffff 100%);
            border-left: 4px solid var(--dm-teal);
        }

        .dm-speed-card-amber {
            background: linear-gradient(180deg, #fffaf0 0%, #ffffff 100%);
            border-left: 4px solid var(--dm-amber);
        }

        .dm-speed-card-slate {
            background: linear-gradient(180deg, #f8fafc 0%, #ffffff 100%);
            border-left: 4px solid #64748b;
        }

        .dm-speed-head {
            display: flex;
            gap: 12px;
            align-items: flex-start;
            margin-bottom: 12px;
        }

        .dm-speed-index {
            flex: 0 0 auto;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 34px;
            height: 34px;
            border-radius: 8px;
            background: var(--dm-blue-soft);
            color: var(--dm-blue-strong);
            font-size: 13px;
            font-weight: 800;
        }

        .dm-speed-title {
            color: var(--dm-text);
            font-size: 18px;
            line-height: 1.3;
            font-weight: 780;
            margin: 0;
        }

        .dm-speed-note {
            color: var(--dm-muted);
            font-size: 13px;
            line-height: 1.55;
            margin: 3px 0 0 0;
        }

        .dm-speed-text {
            color: var(--dm-text);
            font-size: 15px;
            line-height: 1.8;
            margin: 0;
        }

        .dm-speed-text + .dm-speed-text {
            margin-top: 8px;
        }

        .dm-speed-list {
            margin: 0;
            padding-left: 18px;
            color: var(--dm-text);
            line-height: 1.75;
            font-size: 15px;
        }

        .dm-speed-list li {
            margin: 4px 0;
        }

        .dm-speed-metrics {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 10px;
        }

        .dm-speed-metric {
            background: rgba(255, 255, 255, 0.78);
            border: 1px solid var(--dm-border-soft);
            border-radius: 8px;
            padding: 12px 14px;
        }

        .dm-speed-metric-label {
            color: var(--dm-muted);
            font-size: 12px;
            margin: 0 0 5px 0;
        }

        .dm-speed-metric-value {
            color: var(--dm-text);
            font-size: 21px;
            font-weight: 780;
            margin: 0;
        }

        .dm-route-grid {
            display: grid;
            grid-template-columns: repeat(3, minmax(0, 1fr));
            gap: 10px;
        }

        .dm-route-item {
            background: rgba(255, 255, 255, 0.78);
            border: 1px solid var(--dm-border-soft);
            border-radius: 8px;
            padding: 13px 14px;
        }

        .dm-route-title {
            color: var(--dm-text);
            font-size: 14px;
            font-weight: 760;
            margin: 0 0 6px 0;
        }

        .dm-route-text {
            color: var(--dm-muted);
            font-size: 12px;
            line-height: 1.55;
            margin: 0;
        }

        .dm-template-head {
            border-radius: 8px;
            padding: 11px 13px;
            margin: 0 0 12px 0;
            border: 1px solid var(--dm-border-soft);
        }

        .dm-template-blue {
            background: linear-gradient(135deg, #eef4ff 0%, #ffffff 100%);
            border-left: 4px solid var(--dm-blue);
        }

        .dm-template-teal {
            background: linear-gradient(135deg, #ecfdf8 0%, #ffffff 100%);
            border-left: 4px solid var(--dm-teal);
        }

        .dm-template-green {
            background: linear-gradient(135deg, #f0fdf4 0%, #ffffff 100%);
            border-left: 4px solid #16a34a;
        }

        .dm-template-amber {
            background: linear-gradient(135deg, #fffbeb 0%, #ffffff 100%);
            border-left: 4px solid var(--dm-amber);
        }

        .dm-template-slate {
            background: linear-gradient(135deg, #f8fafc 0%, #ffffff 100%);
            border-left: 4px solid #64748b;
        }

        .dm-template-row {
            display: flex;
            align-items: flex-start;
            gap: 10px;
        }

        .dm-template-step {
            flex: 0 0 auto;
            min-width: 31px;
            height: 31px;
            border-radius: 8px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: #ffffff;
            border: 1px solid #d6e2f5;
            color: var(--dm-blue-strong);
            font-size: 12px;
            font-weight: 800;
        }

        .dm-template-title {
            margin: 0;
            color: var(--dm-text);
            font-size: 16px;
            line-height: 1.35;
            font-weight: 780;
        }

        .dm-template-note {
            margin: 3px 0 0 0;
            color: var(--dm-muted);
            font-size: 13px;
            line-height: 1.55;
        }

        @media (max-width: 900px) {
            .dm-speed-metrics,
            .dm-route-grid {
                grid-template-columns: 1fr;
            }
        }

        div[data-testid="stMetric"] {
            background: var(--dm-surface);
            border: 1px solid var(--dm-border);
            border-radius: 8px;
            padding: 14px 15px;
            box-shadow: var(--dm-shadow-soft);
        }

        div[data-testid="stMetric"] label {
            color: var(--dm-muted);
        }

        div[data-testid="stMetric"] div[data-testid="stMetricValue"] {
            color: var(--dm-text);
            font-weight: 760;
        }

        .stButton > button,
        .stDownloadButton > button,
        div[data-testid="stFormSubmitButton"] button {
            background: var(--dm-blue);
            border: 1px solid var(--dm-blue);
            border-radius: 8px;
            color: white;
            font-weight: 650;
            min-height: 40px;
            box-shadow: 0 6px 14px rgba(36, 87, 214, 0.18);
        }

        .stButton > button:hover,
        .stDownloadButton > button:hover,
        div[data-testid="stFormSubmitButton"] button:hover {
            background: #1d4ed8;
            border-color: #1d4ed8;
            color: white;
            box-shadow: 0 8px 18px rgba(36, 87, 214, 0.22);
        }

        [data-testid="stSidebar"] .stButton > button {
            width: 100%;
            min-height: 54px;
            background: rgba(255, 255, 255, 0.92);
            border: 1px solid var(--dm-border);
            color: var(--dm-text);
            text-align: left;
            justify-content: flex-start;
            box-shadow: none;
            padding-left: 14px;
        }

        [data-testid="stSidebar"] .stButton > button:hover {
            background: var(--dm-blue-soft);
            border-color: #9db7ff;
            color: var(--dm-blue-strong);
        }

        [data-testid="stSidebar"] div[role="radiogroup"] {
            gap: 8px;
        }

        [data-testid="stSidebar"] div[role="radiogroup"] label {
            width: 100%;
            min-height: 50px;
            align-items: center;
            background: rgba(255, 255, 255, 0.92);
            border: 1px solid var(--dm-border);
            border-radius: 8px;
            padding: 0 14px;
            color: var(--dm-text);
            font-weight: 720;
            cursor: pointer;
        }

        [data-testid="stSidebar"] div[role="radiogroup"] label:hover {
            background: var(--dm-blue-soft);
            border-color: #9db7ff;
        }

        [data-testid="stSidebar"] div[role="radiogroup"] label:has(input:checked) {
            background: linear-gradient(135deg, var(--dm-blue), var(--dm-blue-strong));
            border-color: var(--dm-blue);
            box-shadow: 0 8px 18px rgba(36, 87, 214, 0.20);
        }

        [data-testid="stSidebar"] div[role="radiogroup"] label:has(input:checked) span,
        [data-testid="stSidebar"] div[role="radiogroup"] label:has(input:checked) div {
            color: #ffffff;
        }

        [data-testid="stSidebar"] div[role="radiogroup"] input {
            display: none;
        }

        div[data-testid="stAlert"] {
            border-radius: 8px;
            border: 1px solid var(--dm-border-soft);
            box-shadow: none;
        }

        div[data-testid="stExpander"] {
            background: var(--dm-surface);
            border: 1px solid var(--dm-border);
            border-radius: 8px;
            box-shadow: var(--dm-shadow-soft);
        }

        div[data-testid="stExpander"] details {
            background: var(--dm-surface);
            border-radius: 8px;
        }

        div[data-testid="stDataFrame"],
        div[data-testid="stTable"] {
            background: var(--dm-surface);
            border-radius: 8px;
            border: 1px solid var(--dm-border-soft);
            overflow: hidden;
        }

        div[data-baseweb="select"] > div,
        div[data-baseweb="input"] > div,
        div[data-baseweb="textarea"] > div {
            background: var(--dm-surface);
            border-color: var(--dm-border);
            color: var(--dm-text);
        }

        div[data-baseweb="select"] span,
        div[data-baseweb="input"] input,
        div[data-baseweb="textarea"] textarea {
            color: var(--dm-text);
        }

        [data-testid="stFileUploader"] section {
            background: var(--dm-surface);
            border: 1px dashed #93c5fd;
            border-radius: 8px;
        }

        div[data-testid="stVerticalBlockBorderWrapper"] {
            border-color: var(--dm-border) !important;
            border-radius: 8px !important;
            background: var(--dm-surface) !important;
            box-shadow: var(--dm-shadow-soft);
        }

        div[data-testid="stTabs"] [role="tablist"] {
            gap: 6px;
            border-bottom: 1px solid var(--dm-border);
        }

        div[data-testid="stTabs"] button[role="tab"] {
            border-radius: 8px 8px 0 0;
            color: var(--dm-muted);
        }

        div[data-testid="stTabs"] button[aria-selected="true"] {
            color: var(--dm-blue-strong);
            font-weight: 750;
        }

        div[data-testid="stRadio"] label,
        div[data-testid="stCheckbox"] label {
            background: transparent;
            color: var(--dm-text);
        }

        hr {
            border-color: var(--dm-border);
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def section(title, note=None):
    """Render a section heading."""
    note_html = f'<p class="dm-section-note">{note}</p>' if note else ""
    st.markdown(
        f"""
        <div class="dm-section">
            <p class="dm-section-title">{title}</p>
            {note_html}
        </div>
        """,
        unsafe_allow_html=True,
    )


@contextmanager
def template_block(step, title, note=None, tone="blue"):
    """Render a consistent page block for operation, guidance, result and evidence sections."""
    note_html = f'<p class="dm-template-note">{html.escape(note)}</p>' if note else ""
    with st.container(border=True):
        st.markdown(
            f"""
            <div class="dm-template-head dm-template-{html.escape(tone)}">
                <div class="dm-template-row">
                    <span class="dm-template-step">{html.escape(str(step))}</span>
                    <div>
                        <p class="dm-template-title">{html.escape(title)}</p>
                        {note_html}
                    </div>
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        yield


def show_ai_status_notice():
    """Render a compact AI configuration status notice."""
    status = ai_status()
    label = f"AI 状态：{status['state']}"
    if status["can_call"]:
        st.success(label)
    elif status["enabled"]:
        st.warning(label)
    else:
        st.caption(label)


def show_debug_instruction(title, instruction):
    """Show a compact debug instruction block when available."""
    if not debug_mode_enabled():
        return
    instruction = coerce_instruction(instruction)
    with st.expander(title, expanded=False):
        if instruction:
            st.json(instruction)
        else:
            st.write("当前没有携带结构化 Skill 指令。")


def submodule_nav_heading(module):
    """Return title and helper text for the sticky submodule navigation."""
    if module == "数据概览":
        return "数据概览", "快速了解数据描述对象、主要内容、质量提醒和推荐分析方向。"
    if module == "清洗预处理":
        return "清洗预处理", "选择清洗设置、查看清洗变化，或下载清洗后的数据。"
    if module == "统计可视化":
        return "统计可视化", "先选择分析类别，再选择具体图表或高级分析方式。"
    if module == "自然语言问答":
        return "自然语言问答", "选择推荐问题或自由提问，系统会使用受控 Skill 执行分析。"
    if module == "分析报告":
        return "分析报告", "生成完整报告，或检查准备写进报告的结论是否有数据依据。"
    if module == "分析历史":
        return "分析历史", "查看完整分析记录，并集中下载可复用成果。"
    return module or "工作台", "选择一个功能模块开始分析。"


def normalize_cleaning_submodule():
    """Keep cleaning submodule state compatible with current data state."""
    cleaning_options = CLEANING_SUBMODULES if "cleaned_df" in st.session_state else ["清洗设置"]
    pending = st.session_state.pop("pending_cleaning_submodule", None)
    pending_map = {
        "字段处理建议": "清洗前后对比",
        "字段使用提醒": "清洗前后对比",
        "清洗日志": "清洗前后对比",
        "异常值风险标记": "清洗设置",
        "极端值提醒": "清洗设置",
        "极端值影响": "清洗设置",
    }
    pending = pending_map.get(pending, pending)
    if pending in cleaning_options:
        st.session_state["cleaning_submodule"] = pending
    if st.session_state.get("cleaning_submodule") not in cleaning_options:
        st.session_state["cleaning_submodule"] = cleaning_options[0]
    return cleaning_options


def normalize_visualization_submodule():
    """Keep visualization section and submodule state aligned."""
    pending = st.session_state.pop("pending_visualization_submodule", None)
    if pending in ["推荐图表", "分析起点", "分析向导"]:
        pending = VISUALIZATION_CHART_SUBMODULES[0]
    if pending in VISUALIZATION_CHART_SUBMODULES:
        st.session_state["visualization_section"] = "基础图表分析"
        st.session_state["visualization_submodule"] = pending
    elif pending in VISUALIZATION_ADVANCED_SUBMODULES:
        st.session_state["visualization_section"] = "高级分析"
        st.session_state["visualization_submodule"] = pending
    elif pending == "AI 需求作图":
        st.session_state["visualization_section"] = pending
        st.session_state["visualization_submodule"] = pending
    if st.session_state.get("visualization_section") not in VISUALIZATION_SECTIONS:
        st.session_state["visualization_section"] = VISUALIZATION_SECTIONS[0]
    if st.session_state["visualization_section"] == "AI 需求作图":
        st.session_state["visualization_submodule"] = "AI 需求作图"
    elif st.session_state["visualization_section"] == "基础图表分析":
        if st.session_state.get("visualization_submodule") not in VISUALIZATION_CHART_SUBMODULES:
            st.session_state["visualization_submodule"] = VISUALIZATION_CHART_SUBMODULES[0]
    else:
        if st.session_state.get("visualization_submodule") not in VISUALIZATION_ADVANCED_SUBMODULES:
            st.session_state["visualization_submodule"] = VISUALIZATION_ADVANCED_SUBMODULES[0]


def normalize_qa_submodule():
    """Apply pending QA navigation and validate state."""
    pending = st.session_state.pop("pending_qa_submodule", None)
    if pending in QA_SUBMODULES:
        st.session_state["qa_submodule"] = pending
    if st.session_state.get("qa_submodule") not in QA_SUBMODULES:
        st.session_state["qa_submodule"] = QA_SUBMODULES[0]


def coerce_instruction(instruction):
    """Normalize dict-like or JSON-string instructions from Streamlit/Pandas state."""
    if isinstance(instruction, dict):
        return instruction
    if isinstance(instruction, str) and instruction.strip():
        try:
            parsed = json.loads(instruction)
        except json.JSONDecodeError:
            return None
        return parsed if isinstance(parsed, dict) else None
    return None


def debug_qa_log(event, **payload):
    """Append temporary QA debug information to outputs/debug_qa.log."""
    if not debug_mode_enabled():
        return
    try:
        log_path = BASE_DIR / "outputs" / "debug_qa.log"
        log_path.parent.mkdir(exist_ok=True)
        safe_payload = {}
        for key, value in payload.items():
            if key.lower().endswith("key") or "api" in key.lower():
                safe_payload[key] = "***"
            else:
                safe_payload[key] = value
        record = {
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "event": event,
            **safe_payload,
        }
        with log_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
    except Exception:
        pass


def hero():
    """Render top hero area."""
    st.markdown(
        """
        <div class="dm-hero">
            <p class="dm-kicker">学习型数据分析工作台</p>
            <h1 class="dm-title">DataMind</h1>
            <p class="dm-subtitle">
                上传表格后，按左侧流程完成数据概览、清洗、统计可视化、问答、报告和记录回看。
            </p>
            <div class="dm-badge-row">
                <span class="dm-badge">受控问数</span>
                <span class="dm-badge">本地规则兜底</span>
                <span class="dm-badge">报告与成果输出</span>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )


PROFILE_SUBMODULES = [
    "数据集速读",
]

CLEANING_SUBMODULES = [
    "清洗设置",
    "清洗前后对比",
    "下载与预览",
]

CLEANING_OUTLIER_SUBMODULES = [
    "发现了什么",
    "影响了什么",
    "怎么处理",
]

VISUALIZATION_SECTIONS = [
    "基础图表分析",
    "高级分析",
    "AI 需求作图",
]

VISUALIZATION_CHART_SUBMODULES = [
    "类别分布",
    "分组对比",
    "数值分布",
    "趋势变化",
    "关系分析",
    "缺失情况",
]

VISUALIZATION_ADVANCED_SUBMODULES = [
    "智能分群",
    "文本词云",
]

VISUALIZATION_SUBMODULES = [
    *VISUALIZATION_CHART_SUBMODULES,
    *VISUALIZATION_ADVANCED_SUBMODULES,
    "AI 需求作图",
]

VISUALIZATION_DISPLAY_LABELS = {
    "类别分布": "类别分布（统计各类数量）",
    "分组对比": "分组对比（比较各组差异）",
    "数值分布": "数值分布（查看数值范围）",
    "趋势变化": "趋势变化（查看时间变化）",
    "关系分析": "关系分析（查看两个数值关系）",
    "缺失情况": "缺失情况（查看空值多少）",
    "智能分群": "智能分群（按相似度分组）",
    "文本词云": "文本词云（统计高频词语）",
}

QA_SUBMODULES = [
    "提问向导",
    "自由提问",
]

HISTORY_SUBMODULES = [
    "分析记录",
]

REPORT_SUBMODULES = [
    "生成报告",
    "结论检查",
]

SUBMODULE_NOTES = {
    "数据集速读": "快速了解这份数据描述的对象、规模、质量提醒和推荐分析方向。",
    "清洗设置": "选择需要执行的清洗策略，原始数据会保留，清洗结果用于后续分析。",
    "清洗前后对比": "查看清洗前后发生了什么变化，以及后续分析需要注意什么。",
    "下载与预览": "预览清洗后的数据，并下载可继续用于 Excel、报告或其他工具的 CSV 文件。",
    "类别分布": "统计某个字段中不同取值出现的次数，帮助判断数据主要集中在哪些类别。",
    "分组对比": "按类别分组比较同一个数值指标，帮助发现不同组之间的高低差异。",
    "数值分布": "查看一个数值字段的常见范围、集中程度，以及是否存在特别高或特别低的记录。",
    "趋势变化": "按时间查看某个数值指标是否上升、下降或出现阶段性波动。",
    "关系分析": "观察两个数值字段是否一起变化，辅助判断字段之间是否存在相关趋势。",
    "缺失情况": "统计各字段的空值数量，帮助判断哪些字段在后续分析中需要谨慎使用。",
    "智能分群": "根据多个数值字段把相似记录分成几组，用于探索数据中是否存在隐藏类型。",
    "文本词云": "从文本字段中统计高频词语，快速了解描述、评论或名称里反复出现的主题。",
    "AI 需求作图": "用一句话描述想看的图，系统会把需求转成安全的图表指令，校验后再生成结果。",
    "提问向导": "根据当前数据自动推荐适合先问的问题，帮助你从更有价值的分析入口开始。",
    "自由提问": "用普通语言输入数据问题，系统会转成受控分析指令并调用本地白名单函数。",
    "生成报告": "选择你认为重要的分析素材，生成结构清晰的 Markdown 或 HTML 报告。",
    "结论检查": "输入一句准备写进报告的结论，系统检查是否有数据依据、表述是否过强。",
    "分析记录": "记录关键操作、使用字段、执行方法和结果摘要，方便回看分析过程并写入报告。",
}


def show_profile(df, submodule="数据集速读"):
    """Render profile sections for a DataFrame."""
    if submodule not in PROFILE_SUBMODULES:
        submodule = "数据集速读"

    section(submodule, SUBMODULE_NOTES.get(submodule))
    profile = profile_table(df)

    if submodule == "数据集速读":
        report = quality_report(df)
        show_dataset_speedread(df, profile, report)
        return


def infer_dataset_themes(df):
    """Infer user-facing themes from column names."""
    columns = [str(column).lower() for column in df.columns]
    theme_rules = [
        ("价格、金额或费用信息", ["price", "cost", "fee", "amount", "revenue", "sales"]),
        ("地区、位置或空间分布信息", ["city", "region", "neighbourhood", "neighborhood", "location", "latitude", "longitude"]),
        ("类别、类型或分组信息", ["type", "category", "room", "property", "source", "status"]),
        ("评分、评价或反馈信息", ["score", "rating", "review", "comment"]),
        ("时间、日期或变化过程信息", ["date", "time", "year", "month", "day"]),
        ("数量、规模或使用频次信息", ["count", "number", "quantity", "nights", "availability", "beds", "bedrooms"]),
        ("名称、描述或文本说明信息", ["name", "description", "summary", "about", "overview"]),
    ]
    themes = []
    for theme, keywords in theme_rules:
        if any(any(keyword in column for keyword in keywords) for column in columns):
            themes.append(theme)
    return themes[:5] or ["通用表格记录信息"]


def dataset_description_text(subject, themes):
    """Describe what the dataset appears to contain."""
    theme_text = "、".join(themes[:5])
    matched = "、".join(subject.get("matched_keywords", [])) or "暂无明显关键词"
    ai_status = subject.get("ai_status", "")
    return (
        f"数据对象识别：{subject['description']}"
        f"识别来源为{subject['source']}，可信度为{subject['confidence']}。"
        f"判断依据：{subject['evidence']}匹配到的关键词包括：{matched}。"
        f"从字段内容看，它还涉及{theme_text}。{ai_status}"
    )


def prepare_field_translations(columns):
    """Prepare display-only field translations for the current dataset."""
    cache = st.session_state.setdefault("field_translation_cache", {})
    status = ai_status()
    translations = translate_field_names(columns, cache=cache, use_ai=status["can_call"])
    st.session_state["field_translation_cache"] = cache
    return translations


def current_field_translations():
    """Return cached field translations."""
    return st.session_state.get("field_translation_cache", {})


def current_value_translations():
    """Return cached displayed value translations."""
    return st.session_state.setdefault("value_translation_cache", {})


def display_field(field_name):
    """Return a display label for a field without changing its real name."""
    return display_field_label(field_name, current_field_translations())


def display_text_with_fields(text):
    """Translate field names embedded in display text."""
    return display_text_with_field_labels(text, current_field_translations())


def prepare_value_translations(field_name, values):
    """Translate displayed values for one field on demand."""
    status = ai_status()
    cache = current_value_translations()
    return translate_display_values(field_name, values, cache=cache, use_ai=status["can_call"])


def display_value(field_name, value):
    """Return a display label for one field value without changing data."""
    prepare_value_translations(field_name, [value])
    return display_value_label(field_name, value, current_value_translations())


def display_text_with_values(text, field_name, values):
    """Translate short English values mentioned inside user-facing text."""
    if text is None:
        return ""
    words = [str(value) for value in values if str(value).strip()]
    if not words:
        return str(text)
    prepare_value_translations(field_name, words)
    result = str(text)
    for word in sorted(set(words), key=len, reverse=True):
        label = display_value_label(field_name, word, current_value_translations())
        if label == word:
            continue
        pattern = rf"(?<![\w]){re.escape(word)}(?![\w（(])"
        result = re.sub(pattern, label, result)
    return result


def display_field_list(field_names, limit=None):
    """Return a joined display label list for fields."""
    names = list(field_names)
    if limit is not None:
        names = names[:limit]
    return "、".join(display_field(name) for name in names)


def first_available_field(fields):
    """Return the first available field name from a list."""
    return list(fields or [None])[0]


def chart_request_placeholder(category_columns, numeric_columns, datetime_columns=None):
    """Build a chart request example that can be answered by current data."""
    category = first_available_field(category_columns)
    numeric = first_available_field(numeric_columns)
    datetime_field = first_available_field(datetime_columns)
    if category and numeric:
        return f"例如：比较不同{display_field(category)}的{display_field(numeric)}有什么差异。"
    if len(numeric_columns or []) >= 2:
        return f"例如：看看{display_field(numeric_columns[0])}和{display_field(numeric_columns[1])}有没有关系。"
    if datetime_field and numeric:
        return f"例如：查看{display_field(numeric)}随{display_field(datetime_field)}的变化趋势。"
    if category:
        return f"例如：统计不同{display_field(category)}的记录数量。"
    return "例如：统计当前数据中适合分析的字段分布。"


def qa_question_placeholder(df):
    """Build a QA example that can be answered by current data."""
    profile = profile_table(df)
    category_columns = category_like_columns(df)
    numeric_columns = analysis_numeric_columns(df, profile["numeric_columns"])
    category = first_available_field(category_columns)
    numeric = first_available_field(numeric_columns)
    if category and numeric:
        return f"例如：不同{display_field(category)}的{display_field(numeric)}平均值是多少？"
    if category:
        return f"例如：{display_field(category)}中出现最多的类别是什么？"
    if numeric:
        return f"例如：{display_field(numeric)}的数值分布情况如何？"
    return "例如：哪些字段缺失最多？"


def conclusion_placeholder(df):
    """Build a conclusion-checking example that matches current usable fields."""
    profile = profile_table(df)
    category_columns = category_like_columns(df)
    numeric_columns = analysis_numeric_columns(df, profile["numeric_columns"])
    category = first_available_field(category_columns)
    numeric = first_available_field(numeric_columns)
    if category and numeric:
        return f"例如：不同{display_field(category)}的{display_field(numeric)}存在明显差异。"
    if len(numeric_columns) >= 2:
        return f"例如：{display_field(numeric_columns[0])}和{display_field(numeric_columns[1])}之间存在关系。"
    if category:
        return f"例如：{display_field(category)}的记录主要集中在少数类别。"
    if numeric:
        return f"例如：{display_field(numeric)}存在明显极端值。"
    return "例如：当前数据存在较多缺失值。"


def display_field_series(series):
    """Return a Series with field-like values translated for display."""
    return series.astype(str).map(display_field)


def dataset_description_paragraphs(subject, themes):
    """Return user-facing dataset description paragraphs."""
    if subject.get("overview_paragraphs"):
        return subject["overview_paragraphs"]

    subject_name = subject.get("subject", "通用表格数据")
    theme_text = "、".join(themes[:5])
    paragraphs = [
        f"这份数据主要描述的是{subject_name}。",
        f"从字段内容看，数据涉及{theme_text}。",
    ]
    if subject_name == "短租房源或住宿平台数据":
        paragraphs.append("它适合用于观察房源类型、价格差异、位置分布、评分评价和可订情况等问题。")
    elif subject_name == "房地产、房屋或租赁信息数据":
        paragraphs.append("它适合用于比较不同房屋类型、区域、价格和居住条件之间的差异。")
    elif subject_name == "问卷调查或心理测量数据":
        paragraphs.append("它适合用于分析受访者特征、回答分布、得分差异和变量之间的关系。")
    elif subject_name == "销售订单或客户交易数据":
        paragraphs.append("它适合用于分析销售规模、商品表现、客户差异和订单变化。")
    elif subject_name == "学生成绩或课程学习数据":
        paragraphs.append("它适合用于分析成绩分布、课程差异、学生表现和影响因素。")
    else:
        paragraphs.append("它适合先进行字段分布、分组对比、缺失情况和数值关系等基础探索。")
    return paragraphs


def show_dataset_identification_basis(subject):
    """Show subject identification basis in a collapsed block."""
    matched = "、".join(subject.get("matched_keywords", [])) or "暂无明显关键词"
    validation = "检查是否返回数据对象、信息构成、可支持分析三段内容。"
    if subject.get("source") != "AI 增强识别":
        validation = f"根据字段关键词进行保守匹配；匹配到的关键词：{matched}。"
    show_evidence_box(
        source=subject.get("source", "未知"),
        inputs=subject.get("evidence", "字段名、字段类型、缺失比例和少量样例值。"),
        validation=validation,
        fallback="AI 不可用、返回为空或格式不完整时，使用本地规则生成保守概览。",
        note="该概览用于帮助理解数据内容，不代表最终分析结论。",
    )


@st.cache_data(show_spinner=False)
def dataframe_signature(df):
    """Return a stable signature for recommendation caches tied to current data."""
    if df is None:
        return "no-data"
    schema = {
        "rows": int(len(df)),
        "columns": [str(column) for column in df.columns],
        "dtypes": {str(column): str(dtype) for column, dtype in df.dtypes.items()},
        "missing": {
            str(column): int(count)
            for column, count in df.isna().sum().items()
        },
    }
    sample = df.head(200).copy()
    sample = sample.astype("string").fillna("<NA>")
    payload = json.dumps(schema, ensure_ascii=False, sort_keys=True)
    sample_hash = pd.util.hash_pandas_object(sample, index=True).values.tobytes()
    digest = hashlib.sha256(payload.encode("utf-8") + sample_hash).hexdigest()
    return digest


@st.cache_data(show_spinner=False)
def profile_table(df):
    """Cached table profile used by many page modules."""
    return raw_profile_table(df)


def get_recommendation_cache(cache_name, cache_key):
    """Read one recommendation cache entry."""
    cache = st.session_state.setdefault(cache_name, {})
    return cache.get(cache_key)


def set_recommendation_cache(cache_name, cache_key, value):
    """Store one recommendation cache entry."""
    cache = st.session_state.setdefault(cache_name, {})
    cache[cache_key] = value
    st.session_state[cache_name] = cache


def get_cached_analysis_directions(df, limit=3):
    """Return stable analysis directions for the current dataset."""
    cache_key = (RECOMMENDATION_CACHE_VERSION, dataframe_signature(df), int(limit))
    cached = get_recommendation_cache("analysis_direction_cache", cache_key)
    if cached is not None:
        directions = final_filter_analysis_directions(df, cached)
        set_recommendation_cache("analysis_direction_cache", cache_key, directions)
        return directions

    directions = recommend_analysis_directions(df, limit=limit)
    if not directions:
        directions = build_analysis_route(df)[:limit]
    directions = final_filter_analysis_directions(df, directions)
    if len(directions) < limit:
        existing = {str(item.get("行动", "")) for item in directions}
        for item in final_filter_analysis_directions(df, build_analysis_route(df)):
            if str(item.get("行动", "")) in existing:
                continue
            directions.append(item)
            existing.add(str(item.get("行动", "")))
            if len(directions) >= limit:
                break
    set_recommendation_cache("analysis_direction_cache", cache_key, directions)
    return directions


def final_filter_analysis_directions(df, directions):
    """Final app-side guard for profile analysis direction cards."""
    kept = []
    for item in directions or []:
        fields = item.get("字段", [])
        if isinstance(fields, str):
            fields = [fields]
        display_fields = analysis_direction_display_fields(df, item)
        fields = list(dict.fromkeys([field for field in [*fields, *display_fields] if field in df.columns]))
        if recommendation_fields_unusable(df, fields):
            continue
        kept.append(item)
    return kept


def analysis_direction_display_fields(df, item):
    """Find dataset fields mentioned in user-visible analysis direction text."""
    text = " ".join(
        str(item.get(key, ""))
        for key in ["行动", "为什么", "入口", "产出"]
        if item.get(key) is not None
    )
    return referenced_display_fields(df, text)


def referenced_display_fields(df, text):
    """Find any current dataset fields mentioned in display text."""
    fields = set(question_referenced_fields(df, text))
    lowered = text.lower()
    normalized_text = normalize_field_reference_text(text)
    translations = current_field_translations()
    for column in df.columns:
        name = str(column)
        candidates = {
            name,
            local_translate_field_name(name),
            translations.get(name, ""),
            display_field_label(name, translations),
        }
        for candidate in candidates:
            candidate = str(candidate or "").strip()
            if not candidate:
                continue
            if candidate.lower() in lowered or normalize_field_reference_text(candidate) in normalized_text:
                fields.add(name)
    return list(fields)


def get_cached_dataset_subject(df):
    """Return stable dataset content overview for the current dataset."""
    cache_key = (RECOMMENDATION_CACHE_VERSION, dataframe_signature(df))
    cached = get_recommendation_cache("dataset_subject_cache", cache_key)
    if cached is not None:
        return cached
    subject = infer_dataset_subject(df)
    set_recommendation_cache("dataset_subject_cache", cache_key, subject)
    return subject


def get_cached_question_recommendations(df, limit=8):
    """Return stable question recommendations and their generation status."""
    cache_key = question_recommendation_cache_key(df, limit)
    cached = get_recommendation_cache("question_recommendation_cache", cache_key)
    if cached is not None:
        recommendations = sanitize_recommendation_questions(df, cached["recommendations"])
        cached["recommendations"] = recommendations
        set_recommendation_cache("question_recommendation_cache", cache_key, cached)
        return recommendations, cached["status"]

    recommendations = recommend_questions(df, limit=limit)
    recommendations = sanitize_recommendation_questions(df, recommendations)
    status = recommendation_status()
    cached = {"recommendations": recommendations, "status": status}
    set_recommendation_cache("question_recommendation_cache", cache_key, cached)
    return recommendations, status


def question_recommendation_cache_key(df, limit=8):
    """Build the cache key for QA recommendations."""
    return (RECOMMENDATION_CACHE_VERSION, dataframe_signature(df), int(limit))


def get_cached_question_recommendations_if_ready(df, limit=8):
    """Read cached QA recommendations without triggering generation."""
    cache_key = question_recommendation_cache_key(df, limit)
    cached = get_recommendation_cache("question_recommendation_cache", cache_key)
    if cached is None:
        return None, None
    recommendations = sanitize_recommendation_questions(df, cached["recommendations"])
    cached["recommendations"] = recommendations
    set_recommendation_cache("question_recommendation_cache", cache_key, cached)
    return recommendations, cached["status"]


def sanitize_recommendation_questions(df, recommendations):
    """Filter recommendation cards without making app startup depend on this helper."""
    try:
        from modules.recommender import sanitize_question_recommendations as sanitizer
    except ImportError:
        sanitized = recommendations
    else:
        sanitized = sanitizer(df, recommendations)
    return final_filter_question_recommendations(df, sanitized)


def final_filter_question_recommendations(df, recommendations, threshold=40.0):
    """Final app-side guard for recommendation cards before display."""
    if recommendations is None or recommendations.empty:
        return recommendations
    kept_rows = []
    for _, row in recommendations.iterrows():
        instruction = coerce_instruction(row.get("instruction")) or row.get("instruction")
        fields = recommendation_instruction_fields(instruction)
        if recommendation_fields_unusable(df, fields, threshold=threshold):
            continue
        kept_rows.append(row)
    if not kept_rows:
        return recommendations.iloc[0:0].copy()
    return pd.DataFrame(kept_rows).reset_index(drop=True)


def recommendation_instruction_fields(instruction):
    """Extract field names from a recommendation Skill instruction."""
    if not isinstance(instruction, dict):
        return []
    fields = []
    for key in ["column", "group_column", "value_column", "time_column", "sort_column"]:
        value = instruction.get(key)
        if value:
            fields.append(str(value))
    for key in ["columns", "fields"]:
        value = instruction.get(key)
        if isinstance(value, list):
            fields.extend(str(item) for item in value if item)
    return list(dict.fromkeys(fields))


def recommendation_fields_unusable(df, fields, threshold=40.0):
    """Return whether any final recommendation field is unusable."""
    for field in fields:
        if field not in df.columns:
            return True
        name = str(field).lower()
        if name == "id" or name.endswith("_id") or "url" in name or "identifier" in name:
            return True
        missing_rate = float(df[field].isna().mean() * 100)
        if missing_rate >= threshold:
            return True
    return False


def show_analysis_direction_basis(route_items):
    """Show recommendation source and validation details in a collapsed block."""
    sources = {str(item.get("来源", "本地规则")) for item in route_items}
    source_text = "、".join(sorted(sources))
    show_evidence_box(
        source=source_text,
        inputs="字段语义摘要、字段类型、缺失比例，以及当前网页允许推荐的功能入口。",
        validation="检查推荐字段是否存在于当前数据集中，推荐入口是否属于当前网页已有功能。",
        fallback="AI 不可用、返回格式不正确，或推荐了不存在的入口/字段时，使用本地规则推荐。",
        note="推荐方向只是下一步分析建议，不代表已经完成分析或得到结论。",
    )


def show_evidence_box(source, inputs, validation, fallback, note, title="查看生成依据"):
    """Render a consistent evidence box with scene-specific content."""
    with st.expander(title):
        st.write(f"生成方式：{source}")
        st.write(f"输入依据：{inputs}")
        st.write(f"本地校验：{validation}")
        st.write(f"兜底方式：{fallback}")
        st.write(f"注意事项：{note}")


def dataset_quality_text(df, profile, report):
    """Describe size and quality signals for users."""
    missing_columns = sum(v > 0 for v in profile["missing_counts"].values())
    quality_text = "整体质量较好，可以继续探索。"
    if report["score"] < 60:
        quality_text = "质量问题较明显，建议先清洗再做结论。"
    elif report["score"] < 80:
        quality_text = "存在一些质量提醒，分析时需要留意缺失、重复或异常值。"

    return (
        f"这份数据包含 {len(df)} 条记录和 {len(df.columns)} 个字段，"
        f"其中有 {missing_columns} 个字段存在缺失值，"
        f"重复记录为 {int(df.duplicated().sum())} 行。{quality_text}"
    )


def show_dataset_speedread(df, profile, report):
    """Render the merged speed-read page with clear user-facing layers."""
    themes = infer_dataset_themes(df)
    subject = get_cached_dataset_subject(df)
    description_html = "".join(
        f'<p class="dm-speed-text">{html.escape(paragraph)}</p>'
        for paragraph in dataset_description_paragraphs(subject, themes)
    )
    h = html.escape

    st.markdown(
        '<div class="dm-speed-card dm-speed-card-blue">'
        '<div class="dm-speed-head">'
        '<span class="dm-speed-index">01</span>'
        '<div>'
        '<p class="dm-speed-title">数据内容概览</p>'
        '</div>'
        '</div>'
        f'{description_html}'
        '</div>',
        unsafe_allow_html=True,
    )
    show_dataset_identification_basis(subject)

    metric_items = dataset_speed_metrics(df, profile)
    metric_html = "".join(
        '<div class="dm-speed-metric">'
        f'<p class="dm-speed-metric-label">{h(label)}</p>'
        f'<p class="dm-speed-metric-value">{h(value)}</p>'
        '</div>'
        for label, value in metric_items
    )
    st.markdown(
        '<div class="dm-speed-card dm-speed-card-teal">'
        '<div class="dm-speed-head">'
        '<span class="dm-speed-index">02</span>'
        '<div>'
        '<p class="dm-speed-title">数据规模概览</p>'
        '</div>'
        '</div>'
        f'<div class="dm-speed-metrics">{metric_html}</div>'
        '</div>',
        unsafe_allow_html=True,
    )

    attention_items = dataset_attention_items(df, profile, report)
    attention_html = "".join(f"<li>{h(item)}</li>" for item in attention_items)
    st.markdown(
        '<div class="dm-speed-card dm-speed-card-amber">'
        '<div class="dm-speed-head">'
        '<span class="dm-speed-index">03</span>'
        '<div>'
        '<p class="dm-speed-title">分析注意事项</p>'
        '</div>'
        '</div>'
        f'<ul class="dm-speed-list">{attention_html}</ul>'
        '</div>',
        unsafe_allow_html=True,
    )

    route_items = get_cached_analysis_directions(df, limit=3)
    route_html = "".join(
        '<div class="dm-route-item">'
        f'<p class="dm-route-title">{index}. {h(display_text_with_fields(step["行动"]))}</p>'
        f'<p class="dm-route-text">{h(display_text_with_fields(step["为什么"]))}</p>'
        f'<p class="dm-route-text">入口：{h(display_text_with_fields(step["入口"]))}</p>'
        f'<p class="dm-route-text">产出：{h(display_text_with_fields(step.get("产出", "得到适合当前数据的图表或分析结果。")))}</p>'
        '</div>'
        for index, step in enumerate(route_items, start=1)
    )
    st.markdown(
        '<div class="dm-speed-card dm-speed-card-slate">'
        '<div class="dm-speed-head">'
        '<span class="dm-speed-index">04</span>'
        '<div>'
        '<p class="dm-speed-title">推荐分析方向</p>'
        '</div>'
        '</div>'
        f'<div class="dm-route-grid">{route_html}</div>'
        '</div>',
        unsafe_allow_html=True,
    )
    show_analysis_direction_basis(route_items)


def dataset_speed_metrics(df, profile):
    """Return compact metrics for the speed-read page."""
    missing_columns = sum(v > 0 for v in profile["missing_counts"].values())
    return [
        ("行数", str(profile["rows"])),
        ("列数", str(profile["columns"])),
        ("有空缺的列", str(missing_columns)),
        ("重复行", str(profile["duplicate_rows"])),
    ]


def dataset_attention_items(df, profile, report):
    """Return practical pre-analysis reminders for users."""
    items = []
    missing_rates = pd.Series(profile["missing_rates"]).sort_values(ascending=False)
    missing_nonzero = missing_rates[missing_rates > 0]
    high_missing = missing_rates[missing_rates >= 30]
    duplicate_count = int(df.duplicated().sum())
    impact = extreme_value_impact_table(df)

    if not high_missing.empty:
        examples = display_field_list(high_missing.head(3).index)
        items.append(f"有 {len(high_missing)} 个字段缺失较多，例如 {examples}，这些字段不适合直接作为核心结论依据。")
    elif not missing_nonzero.empty:
        examples = display_field_list(missing_nonzero.head(3).index)
        items.append(f"有 {len(missing_nonzero)} 个字段存在缺失，例如 {examples}，做图表或分组前建议留意样本是否完整。")
    else:
        items.append("暂时没有发现明显缺失字段，可以先进行基础探索。")

    if duplicate_count:
        items.append(f"发现 {duplicate_count} 行重复记录，涉及计数、求和或平均值时建议先到清洗预处理确认是否删除。")
    else:
        items.append("暂时没有发现重复行，计数类分析的基础比较稳定。")

    if not impact.empty:
        strongest = impact.sort_values("平均值变化数值", ascending=False).iloc[0]
        items.append(
            f"“{display_field(strongest['字段'])}”的平均值可能受极端值影响，建议同时查看中位数、箱线图或极端值影响页面。"
        )
    else:
        items.append("暂时没有发现会明显拉偏平均值的极端值影响。")

    if report["score"] < 60:
        items.append("当前数据不建议直接写最终结论，最好先完成清洗并在报告里说明处理过程。")
    elif report["score"] < 80:
        items.append("当前数据可以做初步分析，但正式写结论前建议先处理缺失、重复或极端值影响。")
    else:
        items.append("当前数据适合先做探索性分析，再根据图表结果决定是否需要进一步清洗。")

    return items


def important_fields(df, limit=10):
    """Recommend fields that are likely useful for first exploration."""
    rows = []
    for column in df.columns:
        series = df[column]
        missing_rate = float(series.isna().mean() * 100)
        unique_count = int(series.nunique(dropna=True))
        lower_name = str(column).lower()
        if is_identifier_field(lower_name, series, unique_count):
            continue
        reason, analysis = field_reason_and_analysis(lower_name, series, unique_count)
        if not reason:
            continue
        caution = "缺失较多，使用前建议先处理或说明。" if missing_rate >= 30 else "可优先用于探索。"
        rows.append(
            {
                "字段": display_field(column),
                "原字段": column,
                "中文释义": translate_field_name(column),
                "可以帮助发现": analysis,
                "缺失率": f"{missing_rate:.2f}%",
                "提醒": caution,
            }
        )
    return pd.DataFrame(rows[:limit])


def translate_field_name(column):
    """Translate common English field names into concise Chinese labels."""
    return current_field_translations().get(str(column)) or local_translate_field_name(column) or str(column)


def is_identifier_field(name, series, unique_count):
    """Return True for identifiers that are not useful as core analysis fields."""
    identifier_tokens = ["id", "url", "code", "uuid", "编号", "编码", "链接"]
    normalized = name.replace("-", "_").replace(" ", "_")
    name_parts = [part for part in normalized.split("_") if part]

    if any(token in name_parts for token in identifier_tokens):
        return True
    if normalized.endswith("_id") or normalized.startswith("id_"):
        return True
    if "url" in normalized or "link" in normalized:
        return True

    unique_ratio = unique_count / max(len(series), 1)
    if unique_ratio > 0.9 and ("name" not in normalized and "description" not in normalized):
        return True
    return False


def field_reason_and_analysis(name, series, unique_count):
    """Return a user-facing reason and possible analysis for one field."""
    if any(keyword in name for keyword in ["price", "cost", "fee", "amount", "revenue", "sales"]):
        return "它通常代表价格、金额或费用。", "查看分布、极端值，以及不同类别之间的差异。"
    if any(keyword in name for keyword in ["neighbourhood", "neighborhood", "city", "region", "location"]):
        return "它通常代表地区或位置。", "比较不同地区的数量、价格或其他指标差异。"
    if any(keyword in name for keyword in ["room", "property", "type", "category", "status"]):
        return "它通常代表类别或类型。", "查看主要类别构成，并做分组对比。"
    if any(keyword in name for keyword in ["score", "rating", "review"]):
        return "它通常代表评分、评价或反馈。", "分析满意度、评价数量，以及它们和其他指标的关系。"
    if any(keyword in name for keyword in ["date", "time", "year", "month", "day"]):
        return "它通常代表时间或日期。", "观察数据是否存在趋势、周期或时间变化。"
    if any(keyword in name for keyword in ["availability", "count", "number", "quantity", "nights", "beds", "bedrooms"]):
        return "它通常代表数量、规模或使用频次。", "查看分布范围，并比较不同类别之间的差异。"
    if series.dtype == "object" and 2 <= unique_count <= 30:
        return "它的取值种类不多，适合作为分组维度。", "查看不同组之间的数量或指标差异。"
    if hasattr(series, "dtype") and str(series.dtype).startswith(("int", "float")):
        return "它是可计算的数值字段。", "查看分布、异常值和与其他数值字段的关系。"
    return None, None


def discoverable_insights(df):
    """List user-facing things the dataset may reveal."""
    fields = important_fields(df, limit=20)
    field_names = fields["原字段"].astype(str).tolist() if not fields.empty and "原字段" in fields else []
    numeric_columns = list(df.select_dtypes(include="number").columns)
    category_like = [
        str(column)
        for column in df.columns
        if df[column].dtype == "object" and 2 <= df[column].nunique(dropna=True) <= 30
    ]

    insights = []
    if numeric_columns:
        insights.append(f"可以查看 {display_field(numeric_columns[0])} 等数值字段的分布，判断常见范围和极端值。")
    if category_like:
        insights.append(f"可以按 {display_field(category_like[0])} 等类别字段做对比，找出不同群体之间的差异。")
    if len(numeric_columns) >= 2:
        insights.append(f"可以比较 {display_field(numeric_columns[0])} 和 {display_field(numeric_columns[1])} 之间是否存在相关关系。")
    if any(any(keyword in name.lower() for keyword in ["date", "time", "year", "month"]) for name in map(str, df.columns)):
        insights.append("可以尝试查看时间趋势，观察指标是否随时间变化。")
    if field_names:
        insights.append(f"建议先关注这些字段：{display_field_list(field_names, limit=5)}。")
    insights.append("如果还不知道从哪里开始，可以去“自然语言问答”选择推荐问题。")
    return insights


def show_quality_reminders(df):
    """Show data quality reminders in user language."""
    report = quality_report(df)
    st.metric("数据质量评分", report["score"])

    duplicate_count = int(df.duplicated().sum())
    if duplicate_count:
        st.warning(f"发现 {duplicate_count} 行重复记录，可能会影响计数、平均值和分组结果。")
    else:
        st.success("没有发现重复记录。")

    missing = df.isna().mean().sort_values(ascending=False)
    missing = missing[missing > 0].head(8)
    if missing.empty:
        st.success("没有发现明显缺失值。")
    else:
        st.write("缺失较多的字段：")
        for column, rate in missing.items():
            st.write(f"- {column}：{rate * 100:.2f}% 缺失")

    outliers = report["outlier_summary"]
    if outliers.empty:
        st.success("当前未发现明显异常值风险字段。")
    else:
        st.write("可能存在异常值风险的字段：")
        for _, row in outliers.head(8).iterrows():
            st.write(f"- {row['column']}：约 {row['outlier_rate_%']}% 的值偏离常见范围")
        impact = extreme_value_impact_table(df)
        if not impact.empty:
            strongest = impact.sort_values("平均值变化数值", ascending=False).iloc[0]
            st.warning(
                f"极端值对“{strongest['字段']}”平均值影响最大，变化幅度约 {strongest['平均值变化幅度']}。"
                "建议在报告中同时参考中位数或说明极端值影响。"
            )


def show_analysis_route(df):
    """Show a user-facing analysis route."""
    section("分析路线", "基于当前数据质量、字段和可发现信息，给出一条更适合继续分析的路径。")
    route = build_analysis_route(df)
    for index, step in enumerate(route, start=1):
        with st.container(border=True):
            st.markdown(f"**第 {index} 步：{step['行动']}**")
            st.write(step["为什么"])
            st.caption(f"建议入口：{step['入口']}")
            st.caption(f"你会得到：{step['产出']}")
            if step.get("暂不建议"):
                st.warning(step["暂不建议"])


def next_step_suggestions(df):
    """Return compact next-step suggestions for reports."""
    return [f"{step['行动']}：{step['为什么']}" for step in build_analysis_route(df)]


def build_analysis_route(df):
    """Build a dynamic route that tells users what to do next."""
    profile = profile_table(df)
    report = quality_report(df)
    important = important_fields(df, limit=6)
    numeric_columns = recommendation_usable_fields(df, analysis_numeric_columns(df, profile["numeric_columns"]))
    category_columns = recommendation_usable_fields(df, category_like_columns(df))
    datetime_columns = recommendation_usable_fields(df, profile["datetime_columns"] or likely_time_columns(profile["column_names"]))
    missing_columns = sum(v > 0 for v in profile["missing_counts"].values())
    duplicate_count = int(df.duplicated().sum())
    impact = extreme_value_impact_table(df)

    route = []
    quality_reasons = []
    if missing_columns:
        quality_reasons.append(f"{missing_columns} 个字段存在缺失")
    if duplicate_count:
        quality_reasons.append(f"{duplicate_count} 行重复记录")
    if not impact.empty:
        strongest = impact.sort_values("平均值变化数值", ascending=False).iloc[0]
        quality_reasons.append(f"{display_field(strongest['字段'])} 的平均值受极端值影响约 {strongest['平均值变化幅度']}")

    if report["score"] < 80 or quality_reasons:
        route.append(
            {
                "行动": "先确认数据质量是否会影响结论",
                "为什么": "当前数据存在" + "、".join(quality_reasons or ["一些质量提醒"]) + "，直接分析可能影响报告可信度。",
                "入口": "清洗预处理 → 清洗设置 / 极端值影响",
                "产出": "清洗日志、极端值影响说明、可写进报告的数据质量说明。",
            }
        )
    else:
        route.append(
            {
                "行动": "可以先进入探索分析",
                "为什么": "当前数据质量评分较好，没有发现明显重复或高风险缺失，可以先寻找主要发现。",
                "入口": "统计可视化 → 基础图表分析",
                "产出": "带推荐方案的具体图表和初步结论。",
            }
        )

    if numeric_columns:
        target = numeric_columns[0]
        route.append(
            {
                "行动": f"查看“{display_field(target)}”的数值分布",
                "为什么": f"“{display_field(target)}”是当前较适合优先分析的数值字段，能帮助判断常见范围、极端值和报告中的核心指标。",
                "入口": "统计可视化 → 基础图表分析 → 数值分布",
                "产出": "数值集中范围、箱线图、极端值判断和图表结论。",
            }
        )

    if category_columns and numeric_columns:
        route.append(
            {
                "行动": f"按“{display_field(category_columns[0])}”比较“{display_field(numeric_columns[0])}”",
                "为什么": "类别字段和数值字段组合通常最容易形成报告里的对比结论。",
                "入口": "统计可视化 → 基础图表分析 → 分组对比",
                "产出": "不同类别之间的差异证据，以及可写进报告的分组结论。",
            }
        )
    elif category_columns:
        route.append(
            {
                "行动": f"先看“{display_field(category_columns[0])}”的类别构成",
                "为什么": "当前识别到可分组字段，但缺少清晰数值指标，先了解主要类别分布更稳妥。",
                "入口": "统计可视化 → 基础图表分析 → 类别分布",
                "产出": "主要类别、类别集中程度和 Top N 频次。",
            }
        )

    if datetime_columns and numeric_columns:
        route.append(
            {
                "行动": f"观察“{display_field(numeric_columns[0])}”是否随时间变化",
                "为什么": f"识别到时间字段“{display_field(datetime_columns[0])}”，可以进一步判断是否存在趋势或阶段变化。",
                "入口": "统计可视化 → 基础图表分析 → 趋势变化",
                "产出": "时间趋势图和趋势方向说明。",
            }
        )
    else:
        route.append(
            {
                "行动": "暂时不优先做时间趋势",
                "为什么": "当前没有稳定识别到时间字段，或缺少可用于趋势分析的数值字段。",
                "入口": "清洗预处理 → 清洗设置",
                "产出": "如果日期字段能被成功转换，后续再补充趋势分析。",
                "暂不建议": "不建议强行画趋势图，否则时间轴可能不可靠。",
            }
        )

    if not important.empty:
        first_fields = "、".join(important["字段"].astype(str).head(3).tolist())
        route.append(
            {
                "行动": "围绕关键字段继续做图表或问答",
                "为什么": f"当前最值得积累证据的字段包括 {first_fields}，可以通过图表和问答继续验证。",
                "入口": "统计可视化 / 自然语言问答",
                "产出": "图表结论、问答结果、字段依据和局限提醒。",
            }
        )

    route.append(
        {
            "行动": "最后生成报告并检查完整性",
            "为什么": "前面的质量说明、图表和问答记录可以共同支撑最终报告。",
            "入口": "分析报告 → 生成报告 / 结论检查",
            "产出": "Markdown/HTML 报告和结论检查结果。",
        }
    )
    return route[:6]


def show_result_table_and_chart(result, chart_kind=None, x=None, y=None, title=None):
    """Show an analysis table and an optional chart."""
    if isinstance(result, dict):
        st.json(result)
        return

    chart_df = display_chart_dataframe(result, x=x)
    chart_title = display_chart_title(title or default_chart_title(chart_kind, x, y))

    if chart_kind == "bar":
        fig = bar_chart(chart_df, x=x, y=y, title=chart_title)
        apply_display_axis_labels(fig, x=x, y=y)
        show_plotly_chart(fig)
    elif chart_kind == "line":
        fig = line_chart(chart_df, x=x, y=y, title=chart_title)
        apply_display_axis_labels(fig, x=x, y=y)
        show_plotly_chart(fig)
    elif chart_kind == "heatmap":
        show_plotly_chart(heatmap(display_correlation_matrix(result), title=chart_title))

    show_detail_table(result)


def show_detail_table(result, label="查看详细数据"):
    """Show result table as collapsible evidence for the visible answer."""
    if not isinstance(result, pd.DataFrame):
        return
    with st.expander(label, expanded=False):
        st.dataframe(display_analysis_table(result), use_container_width=True)


def default_chart_title(chart_kind, x=None, y=None):
    """Return a readable fallback chart title."""
    if chart_kind == "bar" and x and y:
        return f"{display_chart_label(x)} 与 {display_chart_label(y)}"
    if chart_kind == "line" and x and y:
        return f"{display_chart_label(y)} 随 {display_chart_label(x)} 的变化"
    if chart_kind == "heatmap":
        return "相关性热力图"
    return "分析图表"


def apply_display_axis_labels(fig, x=None, y=None):
    """Apply translated axis labels to a Plotly figure."""
    if x:
        fig.update_xaxes(title_text=display_chart_label(x))
    if y:
        fig.update_yaxes(title_text=display_chart_label(y))
    return fig


def show_plotly_chart(fig, **kwargs):
    """Render a Plotly figure after translating field names in user-visible labels."""
    st.plotly_chart(localize_figure_fields(fig), use_container_width=kwargs.pop("use_container_width", True), **kwargs)


def localize_figure_fields(fig):
    """Translate dataset field names in Plotly titles, axes, legends and hover templates."""
    if fig is None:
        return fig
    try:
        title = getattr(fig.layout.title, "text", None)
        if title:
            fig.update_layout(title_text=display_text_with_fields(str(title)))
        for axis_name in ["xaxis", "yaxis", "xaxis2", "yaxis2"]:
            axis = getattr(fig.layout, axis_name, None)
            axis_title = getattr(getattr(axis, "title", None), "text", None) if axis else None
            if axis_title:
                translated_title = display_chart_label(axis_title)
                if axis_name.startswith("x"):
                    fig.update_xaxes(title_text=translated_title)
                else:
                    fig.update_yaxes(title_text=translated_title)
        legend_title = getattr(getattr(fig.layout, "legend", None), "title", None)
        if getattr(legend_title, "text", None):
            fig.update_layout(legend_title_text=display_chart_label(legend_title.text))
        for trace in fig.data:
            if getattr(trace, "name", None):
                trace.name = display_text_with_fields(str(trace.name))
            if getattr(trace, "hovertemplate", None):
                trace.hovertemplate = display_text_with_fields(str(trace.hovertemplate))
    except Exception:
        return fig
    return fig


def display_correlation_matrix(result):
    """Return a display-only correlation matrix with translated field labels."""
    if not isinstance(result, pd.DataFrame):
        return result
    display_matrix = result.copy()
    display_matrix.index = [display_chart_label(label) for label in display_matrix.index]
    display_matrix.columns = [display_chart_label(label) for label in display_matrix.columns]
    return display_matrix


def display_analysis_table(result):
    """Return a display-only copy with field names translated where safe."""
    if not isinstance(result, pd.DataFrame):
        return result
    display_df = result.copy()
    for column in list(display_df.columns):
        original_column = str(column)
        if original_column in current_field_translations() and should_translate_column_values(display_df[column]):
            prepare_value_translations(original_column, display_df[column].dropna().astype(str).head(80).tolist())
            display_df[column] = display_df[column].map(lambda value: display_value_label(original_column, value, current_value_translations()))
        elif original_column == "word":
            prepare_value_translations(original_column, display_df[column].dropna().astype(str).head(80).tolist())
            display_df[column] = display_df[column].map(lambda value: display_value_label(original_column, value, current_value_translations()))
    rename_map = {
        column: display_field(column)
        for column in display_df.columns
        if str(column) in current_field_translations()
    }
    if rename_map:
        display_df = display_df.rename(columns=rename_map)
    for column in ["column", "字段", "依据字段"]:
        if column in display_df.columns:
            display_df[column] = display_field_series(display_df[column])
    return display_df


def display_chart_dataframe(result, x=None):
    """Return chart data with display-only translated x values."""
    if not isinstance(result, pd.DataFrame):
        return result
    display_df = result.copy()
    if not x or x not in display_df.columns:
        return display_df
    if x == "column":
        display_df[x] = display_field_series(display_df[x])
    elif x == "word":
        prepare_value_translations("word", display_df[x].dropna().astype(str).head(80).tolist())
        display_df[x] = display_df[x].map(lambda value: display_value_label("word", value, current_value_translations()))
    elif str(x) in current_field_translations() and should_translate_column_values(display_df[x]):
        prepare_value_translations(str(x), display_df[x].dropna().astype(str).head(80).tolist())
        display_df[x] = display_df[x].map(lambda value: display_value_label(str(x), value, current_value_translations()))
    return display_df


def should_translate_column_values(series):
    """Return whether a displayed column is suitable for value translation."""
    if pd.api.types.is_numeric_dtype(series):
        return False
    non_null = series.dropna()
    if non_null.empty:
        return False
    unique_count = non_null.astype(str).nunique()
    return unique_count <= 80


def display_chart_title(title):
    """Translate cached field names inside a chart title."""
    if not title:
        return title
    return display_text_with_fields(str(title))


def display_chart_label(label):
    """Translate chart axis, legend and generated metric labels."""
    if label is None:
        return ""
    text = str(label)
    generated_label = display_generated_chart_label(text)
    if generated_label:
        return generated_label
    known_labels = {
        "word": "词语",
        "count": "数量",
        "missing_count": "缺失数量",
        "missing_rate_%": "缺失率",
        "share_%": "占比",
    }
    if text in known_labels:
        return known_labels[text]
    if text in current_field_translations() or local_translate_field_name(text) != text:
        return display_field(text)
    return display_text_with_fields(text)


def display_generated_chart_label(text):
    """Translate generated columns such as review_scores_rating_mean before generic matching."""
    agg_labels = {
        "median": "中位数",
        "count": "数量",
        "mean": "平均值",
        "sum": "总和",
        "max": "最大值",
        "min": "最小值",
    }
    for suffix, label_text in agg_labels.items():
        marker = f"_{suffix}"
        if str(text).endswith(marker):
            base = str(text)[: -len(marker)]
            if base:
                return display_generated_metric_label(base, label_text)
    return ""


def display_generated_metric_label(base_field, metric_label):
    """Translate generated chart columns such as review_scores_rating_mean."""
    base = str(base_field)
    if base in current_field_translations() or local_translate_field_name(base):
        return f"{display_field(base)} {metric_label}"
    return f"{display_text_with_fields(base)} {metric_label}"


def ensure_analysis_history():
    """Ensure the in-memory analysis history exists."""
    if "analysis_history" not in st.session_state:
        st.session_state["analysis_history"] = []
    if "history_signatures" not in st.session_state:
        st.session_state["history_signatures"] = set()


def add_history_event(event_type, action, data_source="", fields="", method="", result="", dedupe_key=None):
    """Record a user-facing analysis event for traceability."""
    ensure_analysis_history()
    signature = dedupe_key or f"{event_type}|{action}|{data_source}|{fields}|{method}|{result}"
    if signature in st.session_state["history_signatures"]:
        return
    st.session_state["history_signatures"].add(signature)
    st.session_state["analysis_history"].append(
        {
            "时间": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "类型": event_type,
            "操作内容": action,
            "使用数据": data_source or "当前数据",
            "字段/对象": fields or "-",
            "方法": method or "-",
            "结果摘要": result or "-",
        }
    )


def history_dataframe(event_type=None):
    """Return analysis history as a DataFrame."""
    ensure_analysis_history()
    rows = st.session_state["analysis_history"]
    if event_type:
        rows = [row for row in rows if row["类型"] == event_type]
    return pd.DataFrame(rows)


def history_report_lines():
    """Return Markdown lines for report history."""
    ensure_analysis_history()
    if not st.session_state["analysis_history"]:
        return ["- 当前还没有分析记录。"]
    lines = []
    for row in st.session_state["analysis_history"][-12:]:
        detail = row["操作内容"]
        if row["字段/对象"] != "-":
            detail += f"；字段/对象：{row['字段/对象']}"
        if row["方法"] != "-":
            detail += f"；方法：{row['方法']}"
        if row["结果摘要"] != "-":
            detail += f"；结果：{row['结果摘要']}"
        lines.append(f"- {row['时间']} [{row['类型']}] {detail}")
    return lines


def show_analysis_panel(df, submodule=None):
    """Render user-facing visualization tasks."""
    if submodule in ["推荐图表", "分析起点", "分析向导", None]:
        submodule = VISUALIZATION_CHART_SUBMODULES[0]
    if submodule not in VISUALIZATION_SUBMODULES:
        submodule = VISUALIZATION_CHART_SUBMODULES[0]

    profile = profile_table(df)
    columns = profile["column_names"]
    numeric_columns = analysis_numeric_columns(df, profile["numeric_columns"])
    datetime_columns = profile["datetime_columns"]
    category_columns = category_like_columns(df)
    text_columns = text_like_columns(df)

    try:
        if submodule == "类别分布":
            show_category_distribution(df, category_columns)
        elif submodule == "分组对比":
            show_group_comparison(df, category_columns, numeric_columns)
        elif submodule == "数值分布":
            show_numeric_distribution(df, numeric_columns)
        elif submodule == "趋势变化":
            show_trend_visualization(df, columns, datetime_columns, numeric_columns)
        elif submodule == "关系分析":
            show_relationship_visualization(df, numeric_columns)
        elif submodule == "缺失情况":
            show_missing_visualization(df)
        elif submodule == "智能分群":
            show_cluster_analysis_panel(df, numeric_columns)
        elif submodule == "文本词云":
            show_text_wordcloud_panel(df, text_columns)
        elif submodule == "AI 需求作图":
            show_ai_chart_request_panel(df, category_columns, numeric_columns, datetime_columns)

    except AnalysisError as exc:
        st.error(str(exc))


def category_like_columns(df):
    """Return columns that are useful for category-oriented charts."""
    columns = []
    for column in df.columns:
        if not is_scalar_display_column(df[column]):
            continue
        unique_count = int(df[column].nunique(dropna=True))
        if unique_count < 2:
            continue
        columns.append(column)
    return sorted(columns, key=lambda column: category_priority(column, df))


def analysis_numeric_columns(df, numeric_columns):
    """Return numeric columns that are useful for user-facing charts."""
    useful_columns = []
    for column in numeric_columns:
        if int(df[column].notna().sum()) == 0:
            continue
        useful_columns.append(column)
    return sorted(useful_columns, key=lambda column: numeric_priority(column, df))


def recommendation_usable_fields(df, fields, threshold=40.0):
    """Keep fields suitable for proactive recommendations."""
    return [
        field
        for field in fields
        if field in df.columns and float(df[field].isna().mean() * 100) < threshold
    ]


def numeric_like_columns(df):
    """Return columns that are numeric or can be safely converted for charts."""
    columns = []
    for column in df.columns:
        if is_numeric_usable(df[column]):
            columns.append(column)
    return sorted(columns, key=lambda column: numeric_priority(column, df))


def text_like_columns(df):
    """Return columns suitable for text frequency and word cloud analysis."""
    columns = []
    for column in df.columns:
        if not is_scalar_display_column(df[column]):
            continue
        series = df[column].dropna()
        if series.empty:
            continue
        if pd.api.types.is_numeric_dtype(df[column]) or pd.api.types.is_datetime64_any_dtype(df[column]):
            continue
        lower_name = str(column).lower()
        sample = series.astype(str).head(200)
        avg_length = sample.str.len().mean()
        unique_count = int(series.nunique(dropna=True))
        unique_ratio = unique_count / max(len(series), 1)
        if avg_length >= 2:
            columns.append(column)
    return sorted(list(dict.fromkeys(columns)), key=lambda column: text_priority(column, df))


def text_priority(column, df):
    """Rank text columns by usefulness for word cloud analysis."""
    name = str(column).lower()
    series = df[column].dropna().astype(str)
    sample = series.head(200).str.strip()
    avg_length = float(sample.str.len().mean()) if not sample.empty else 0
    unique_count = int(series.nunique(dropna=True))
    unique_ratio = unique_count / max(len(series), 1)
    penalty = 0
    if any(keyword in name for keyword in ["url", "link", "href", "photo", "picture", "thumbnail", "image"]):
        penalty += 120
    if name == "id" or name.endswith("_id") or "identifier" in name:
        penalty += 120
    if any(keyword in name for keyword in ["date", "time", "scraped", "since", "first_review", "last_review"]):
        penalty += 90
    if name in {"source", "status"} or any(keyword in name for keyword in ["response_time", "license"]):
        penalty += 60
    if unique_ratio > 0.95 and not any(keyword in name for keyword in ["description", "overview", "about", "comment", "review", "amenities", "name"]):
        penalty += 50
    if avg_length < 8:
        penalty += 25
    priority_groups = [
        ["description", "overview", "summary", "about", "comments", "comment", "review", "reviews", "描述", "评论", "评价"],
        ["amenities", "notes", "neighborhood_overview", "host_about", "设施", "说明"],
        ["name", "title", "名称", "标题"],
    ]
    for index, keywords in enumerate(priority_groups):
        if any(keyword in name for keyword in keywords):
            return penalty + index
    return penalty + len(priority_groups)


def is_scalar_display_column(series):
    """Return whether a column is safe for grouping and display."""
    sample = series.dropna().head(20)
    return not any(isinstance(value, (list, dict, tuple, set)) for value in sample)


def category_priority(column, df):
    """Rank category columns by user-facing usefulness."""
    name = str(column).lower()
    series = df[column]
    unique_count = int(series.nunique(dropna=True))
    unique_ratio = unique_count / max(len(series), 1)
    penalty = 0
    if pd.api.types.is_numeric_dtype(series):
        penalty += 40
    if pd.api.types.is_datetime64_any_dtype(series):
        penalty += 50
    if is_identifier_field(name, series, unique_count):
        penalty += 80
    if unique_count > 80:
        penalty += 30
    elif unique_ratio > 0.5:
        penalty += 20
    if any(keyword in name for keyword in ["description", "overview", "about", "comment", "amenities"]):
        penalty += 25
    priority_groups = [
        ["room_type", "property_type", "category", "type"],
        ["neighbourhood", "neighborhood", "city", "region", "country", "location"],
        ["status", "source"],
        ["superhost", "verified", "bookable"],
    ]
    for index, keywords in enumerate(priority_groups):
        if any(keyword in name for keyword in keywords):
            return penalty + index
    return penalty + len(priority_groups)


def numeric_priority(column, df):
    """Rank numeric columns by user-facing usefulness."""
    name = str(column).lower()
    series = df[column]
    unique_count = int(series.nunique(dropna=True))
    penalty = 0
    if is_identifier_field(name, series, unique_count):
        penalty += 80
    if any(keyword in name for keyword in ["latitude", "longitude"]):
        penalty += 20
    priority_groups = [
        ["price", "cost", "fee", "amount", "revenue", "sales"],
        ["rating", "score"],
        ["review"],
        ["availability"],
        ["quantity", "count", "number", "nights", "beds", "bedrooms", "bathrooms", "accommodates"],
        ["latitude", "longitude"],
        ["host"],
    ]
    for index, keywords in enumerate(priority_groups):
        if any(keyword in name for keyword in keywords):
            return penalty + index
    return penalty + len(priority_groups)


CHART_RECOMMENDATION_SCHEMAS = {
    "类别分布": {
        "required": ["category_field"],
        "roles": {"category_field": "可用于统计数量的字段"},
        "params": [],
    },
    "分组对比": {
        "required": ["group_field", "value_field", "agg"],
        "roles": {"group_field": "分组字段", "value_field": "数值字段"},
        "params": ["agg"],
    },
    "数值分布": {
        "required": ["value_field"],
        "roles": {"value_field": "数值字段"},
        "params": [],
    },
    "趋势变化": {
        "required": ["time_field", "value_field", "freq", "agg"],
        "roles": {"time_field": "时间字段", "value_field": "数值字段"},
        "params": ["freq", "agg"],
    },
    "关系分析": {
        "required": ["x_field", "y_field"],
        "roles": {"x_field": "横轴数值字段", "y_field": "纵轴数值字段"},
        "params": [],
    },
    "文本词云": {
        "required": ["text_field"],
        "roles": {"text_field": "文本字段"},
        "params": [],
    },
    "智能分群": {
        "required": ["numeric_fields", "n_clusters"],
        "roles": {"numeric_fields": "参与分群的数值字段"},
        "params": ["n_clusters"],
    },
}


def show_chart_field_recommendations(df, chart_type, available_fields, widget_keys, on_use=None):
    """Recommend field selections for the current chart with AI and local fallback."""
    recommendations, status = get_chart_field_recommendations_if_ready(df, chart_type, available_fields)
    if recommendations is None:
        with template_block("01", "推荐字段组合", "根据当前数据推荐适合本图表的字段组合。", "teal"):
            st.caption("你也可以直接在下方自定义设置中搜索并选择字段。")
            if st.button("生成推荐方案", key=f"generate_chart_rec_{chart_type}", use_container_width=True):
                chart_field_recommendations(df, chart_type, available_fields)
                st.rerun()
        return
    if not recommendations:
        return

    with template_block("01", "推荐字段组合", "可直接使用推荐组合，也可以在上方自己搜索字段。", "teal"):
        for index, item in enumerate(recommendations, start=1):
            with st.container(border=True):
                st.write(display_chart_recommendation_title(chart_type, item))
                st.caption(display_text_with_fields(item.get("reason", "适合当前图表的字段组合。")))
                if st.button("使用这个组合", key=f"use_chart_rec_{chart_type}_{index}", use_container_width=True):
                    apply_chart_recommendation_to_state(item, widget_keys)
                    if on_use:
                        on_use(item)
                    else:
                        st.session_state["pending_generate_chart_type"] = chart_type
                    st.rerun()

    show_evidence_box(
        source=status["source"],
        inputs=status["inputs"],
        validation=status["validation"],
        fallback=status["fallback"],
        note=status["note"],
        title="查看推荐依据",
    )


def chart_field_recommendations(df, chart_type, available_fields, limit=3):
    """Return chart field recommendations and evidence status."""
    cache_key = chart_field_recommendation_cache_key(df, chart_type, available_fields, limit)
    cached = get_recommendation_cache("chart_field_recommendation_cache", cache_key)
    if cached is not None:
        recommendations = final_filter_chart_recommendations(df, cached["recommendations"], chart_type, available_fields)
        cached["recommendations"] = recommendations
        set_recommendation_cache("chart_field_recommendation_cache", cache_key, cached)
        return recommendations, cached["status"]

    local_rows = local_chart_field_recommendations(df, chart_type, available_fields, limit=limit)
    status = ai_status()
    if status["can_call"]:
        ai_rows, message = ai_chart_field_recommendations(df, chart_type, available_fields, limit=limit)
        if ai_rows:
            recommendations = final_filter_chart_recommendations(df, ai_rows[:limit], chart_type, available_fields)
            if not recommendations:
                retry_rows, retry_message = ai_chart_field_recommendations(
                    df,
                    chart_type,
                    available_fields,
                    limit=limit,
                    retry_feedback=message or "首轮推荐未通过本地字段适配和图表意义校验，请重新选择更适合当前图表的字段组合。",
                )
                recommendations = final_filter_chart_recommendations(df, (retry_rows or [])[:limit], chart_type, available_fields)
                if recommendations:
                    result = recommendations, {
                    "source": "AI 重新推荐 + 本地校验",
                    "inputs": "当前图表类型、字段名、字段中文含义、字段类型、缺失率、唯一值数量、字段角色和首轮本地校验反馈。",
                    "validation": "系统校验字段存在性、缺失率、类型适配、唯一值数量、是否像 ID/链接字段，以及图表是否具有基本分析意义。",
                    "fallback": "首轮 AI 推荐不可用时，系统会让 AI 根据本地拒绝原因重新生成；重试仍失败时使用本地规则兜底。",
                    "note": "AI 只推荐字段组合，不执行代码；最终图表仍由本地白名单函数生成。",
                    }
                    set_recommendation_cache(
                        "chart_field_recommendation_cache",
                        cache_key,
                        {"recommendations": result[0], "status": result[1]},
                    )
                    return result
                fallback_note = retry_message or "AI 返回的字段组合包含缺失率过高、全空或不适合当前图表的字段，已使用本地规则兜底。"
            else:
                result = recommendations, {
                "source": "AI 推荐 + 本地校验",
                "inputs": "当前图表类型、字段名、字段中文含义、字段类型、缺失率、唯一值数量和少量样例值。",
                "validation": "系统校验字段存在性、缺失率、类型适配、唯一值数量、是否像 ID/链接字段，以及图表是否具有基本分析意义。",
                "fallback": "AI 不可用、返回格式不正确或字段/参数校验失败时，先尝试 AI 重新推荐，再使用本地规则兜底。",
                "note": "AI 只推荐字段组合，不执行代码；最终图表仍由本地白名单函数生成。",
                }
                set_recommendation_cache(
                    "chart_field_recommendation_cache",
                    cache_key,
                    {"recommendations": result[0], "status": result[1]},
                )
                return result
        else:
            fallback_note = message or "AI 未返回可用字段组合，已使用本地规则兜底。"
    else:
        fallback_note = "AI 当前不可调用，使用本地规则推荐字段组合。"

    recommendations = final_filter_chart_recommendations(df, local_rows[:limit], chart_type, available_fields)
    result = recommendations, {
        "source": "本地规则兜底",
        "inputs": "当前图表类型、字段类型、字段名关键词、缺失率和唯一值数量。",
        "validation": "系统只从当前图表可选字段中推荐，并限制统计方式、时间粒度和分群数量。",
        "fallback": fallback_note,
        "note": "字段推荐是起点建议，用户仍可以在下方搜索并选择其他可用字段。",
    }
    set_recommendation_cache(
        "chart_field_recommendation_cache",
        cache_key,
        {"recommendations": result[0], "status": result[1]},
    )
    return result


def chart_field_recommendation_cache_key(df, chart_type, available_fields, limit=3):
    """Build the cache key for chart field recommendations."""
    fields_key = json.dumps(
        {
            role: [str(field) for field in fields]
            for role, fields in available_fields.items()
            if isinstance(fields, list)
        },
        ensure_ascii=False,
        sort_keys=True,
    )
    return (RECOMMENDATION_CACHE_VERSION, dataframe_signature(df), str(chart_type), fields_key, int(limit))


def get_chart_field_recommendations_if_ready(df, chart_type, available_fields, limit=3):
    """Read cached chart field recommendations without triggering generation."""
    cache_key = chart_field_recommendation_cache_key(df, chart_type, available_fields, limit)
    cached = get_recommendation_cache("chart_field_recommendation_cache", cache_key)
    if cached is None:
        return None, None
    recommendations = final_filter_chart_recommendations(df, cached["recommendations"], chart_type, available_fields)
    cached["recommendations"] = recommendations
    set_recommendation_cache("chart_field_recommendation_cache", cache_key, cached)
    return recommendations, cached["status"]


def final_filter_chart_recommendations(df, recommendations, chart_type=None, available_fields=None):
    """Final app-side guard for chart field recommendation cards."""
    kept = []
    for item in recommendations or []:
        fields = list(dict.fromkeys([*chart_recommendation_fields(item), *chart_recommendation_display_fields(df, item)]))
        if recommendation_fields_unusable(df, fields):
            continue
        if chart_type and available_fields and not chart_recommendation_is_valid(item, chart_type, available_fields, df):
            continue
        kept.append(item)
    return kept


def chart_recommendation_display_fields(df, item):
    """Find dataset fields mentioned in user-visible chart recommendation text."""
    text = " ".join(
        str(value)
        for key, value in item.items()
        if isinstance(value, str) and key not in {"source"}
    )
    return referenced_display_fields(df, text)


def chart_recommendation_fields(item):
    """Extract all data fields used by one chart recommendation."""
    fields = []
    for key in ["category_field", "group_field", "value_field", "time_field", "x_field", "y_field", "text_field"]:
        value = item.get(key)
        if value:
            fields.append(str(value))
    numeric_fields = item.get("numeric_fields")
    if isinstance(numeric_fields, list):
        fields.extend(str(field) for field in numeric_fields if field)
    return list(dict.fromkeys(fields))


def ai_chart_field_recommendations(df, chart_type, available_fields, limit=3, retry_feedback=None):
    """Ask AI for chart field recommendations, then validate locally."""
    payload = build_chart_recommendation_payload(df, chart_type, available_fields, limit=limit)
    schema = chart_recommendation_response_schema()
    retry_prompt = ""
    if retry_feedback:
        retry_prompt = (
            "\n上一轮推荐没有通过本地校验，原因如下："
            f"{retry_feedback}\n"
            "请不要重复这些无效组合，重新选择能实际生成且有分析意义的字段组合。\n"
        )
    prompt = (
        "你是 DataMind 的图表字段推荐器。请只为用户当前打开的图表推荐字段组合。"
        "不要推荐不存在的字段，不要生成代码，不要推荐网页当前不支持的图表。"
        "返回内容会直接展示给普通用户，请用清楚、自然、面向用户的中文解释推荐理由。"
        "只能从数据摘要 fields 中选择字段；excluded_fields 中的字段缺失率过高、全空或不适合推荐，不要使用。"
        "不要推荐缺失率达到 40% 或全部缺失的字段；如果某字段缺失过高，即使它看起来语义相关，也不要作为推荐字段组合。"
        "不要推荐 ID、URL、图片链接、几乎每行都唯一、只有一个有效取值、全空、常量或与当前图表角色不匹配的字段。"
        "推荐结果必须能生成有意义的图像：类别图需要合理类别，数值图需要可计算且有变化，关系图需要两个不同且有变化的数值字段，趋势图需要可用时间字段和数值字段，词云需要足够文本内容，分群需要至少两个有变化的数值字段。"
        "不要解释某个字段为什么没有使用，也不要写“因为某字段缺失所以改用另一个字段”这类内部处理过程。"
        "如果某个字段不适合推荐，直接围绕可用字段生成自然的推荐说明，不要在标题或理由里提到被排除字段。"
        "推荐字段组合必须值得研究、有实际分析意义，不能只是随便凑字段；多个推荐组合之间要有不同侧重，尽量覆盖不同字段和分析角度。"
        "必须只返回 JSON，不要使用 Markdown，不要添加解释文字。\n\n"
        f"当前图表：{chart_type}\n"
        f"允许字段角色和参数：{CHART_RECOMMENDATION_SCHEMAS.get(chart_type, {}) }\n"
        f"必须使用的 JSON 格式：{chart_recommendation_format_hint(chart_type)}\n"
        "字段名必须逐字使用数据摘要里的 column 原文，不能使用中文翻译，不能自己改写字段名。\n\n"
        f"{retry_prompt}"
        f"数据摘要：{payload}\n"
    )
    data, error = request_structured_json(prompt, schema)
    if error or not data:
        return None, error or "AI 没有返回数据。"
    rows = data.get("recommendations", [])
    filtered, reject_reasons = validate_chart_recommendation_rows(rows, chart_type, available_fields, df)
    if not filtered:
        reason_text = "；".join(reject_reasons[:3]) if reject_reasons else "没有返回可用字段组合。"
        return None, f"AI 返回的字段组合未通过本地校验：{reason_text}"
    return filtered, None


def chart_recommendation_format_hint(chart_type):
    """Return exact JSON format requirements for one chart type."""
    formats = {
        "类别分布": '{"recommendations":[{"chart_type":"类别分布","category_field":"字段名","reason":"推荐理由"}]}',
        "分组对比": '{"recommendations":[{"chart_type":"分组对比","group_field":"字段名","value_field":"字段名","agg":"mean","reason":"推荐理由"}]}',
        "数值分布": '{"recommendations":[{"chart_type":"数值分布","value_field":"字段名","reason":"推荐理由"}]}',
        "趋势变化": '{"recommendations":[{"chart_type":"趋势变化","time_field":"字段名","value_field":"字段名","freq":"M","agg":"mean","reason":"推荐理由"}]}',
        "关系分析": '{"recommendations":[{"chart_type":"关系分析","x_field":"字段名","y_field":"字段名","reason":"推荐理由"}]}',
        "文本词云": '{"recommendations":[{"chart_type":"文本词云","text_field":"字段名","reason":"推荐理由"}]}',
        "智能分群": '{"recommendations":[{"chart_type":"智能分群","numeric_fields":["字段名","字段名"],"n_clusters":3,"reason":"推荐理由"}]}',
    }
    return formats.get(chart_type, '{"recommendations":[{"chart_type":"当前图表","reason":"推荐理由"}]}')


def build_chart_recommendation_payload(df, chart_type, available_fields, limit=3):
    """Build compact dataset summary for chart field recommendation."""
    fields = []
    excluded_fields = []
    ordered_columns = []
    for columns in available_fields.values():
        if isinstance(columns, list):
            ordered_columns.extend(columns)
    ordered_columns.extend(list(df.columns))
    ordered_columns = list(dict.fromkeys([column for column in ordered_columns if column in df.columns]))
    for column in ordered_columns[:120]:
        series = df[column]
        item = {
            "column": str(column),
            "display_label": display_field(column),
            "dtype": str(series.dtype),
            "missing_rate_%": round(float(series.isna().mean() * 100), 2),
            "non_empty_count": int(series.notna().sum()),
            "unique_count": int(series.nunique(dropna=True)),
            "numeric_usable": bool(is_numeric_usable(series)),
            "examples": [
                str(value)[:40]
                for value in series.dropna().head(3).tolist()
                if str(value).strip()
            ],
            "available_roles": roles_for_column(column, available_fields),
        }
        if chart_field_not_recommendable(df, column):
            excluded_fields.append(
                {
                    "column": item["column"],
                    "missing_rate_%": item["missing_rate_%"],
                    "non_empty_count": item["non_empty_count"],
                    "available_roles": item["available_roles"],
                    "reason": "missing_or_identifier",
                }
            )
            continue
        examples = [
            str(value)[:40]
            for value in series.dropna().head(3).tolist()
            if str(value).strip()
        ]
        item["examples"] = examples
        fields.append(item)
    return {
        "row_count": int(len(df)),
        "chart_type": chart_type,
        "max_recommendations": int(limit),
        "fields": fields,
        "excluded_fields": excluded_fields[:30],
    }


def roles_for_column(column, available_fields):
    """Return role names for which a field is available."""
    roles = []
    for role, columns in available_fields.items():
        if isinstance(columns, list) and column in columns:
            roles.append(role)
    return roles


def chart_recommendation_response_schema():
    """Return JSON schema for chart field recommendations."""
    return {
        "name": "datamind_chart_field_recommendations",
        "schema": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "recommendations": {
                    "type": "array",
                    "maxItems": 5,
                    "items": {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "chart_type": {"type": "string"},
                            "category_field": {"type": "string"},
                            "group_field": {"type": "string"},
                            "value_field": {"type": "string"},
                            "time_field": {"type": "string"},
                            "x_field": {"type": "string"},
                            "y_field": {"type": "string"},
                            "text_field": {"type": "string"},
                            "numeric_fields": {"type": "array", "items": {"type": "string"}},
                            "agg": {"type": "string"},
                            "freq": {"type": "string"},
                            "n_clusters": {"type": "integer"},
                            "reason": {"type": "string"},
                        },
                        "required": ["chart_type", "reason"],
                    },
                }
            },
            "required": ["recommendations"],
        },
    }


def validate_chart_recommendation_rows(rows, chart_type, available_fields, df):
    """Keep only AI chart recommendations that match local rules."""
    filtered = []
    reject_reasons = []
    for row in rows:
        item = normalize_chart_recommendation(row, chart_type)
        if not item:
            reject_reasons.append("返回的图表类型与当前图表不一致，或缺少必要字段。")
            continue
        if chart_recommendation_is_valid(item, chart_type, available_fields, df):
            item["source"] = "AI 推荐 + 本地校验"
            filtered.append(item)
        else:
            reject_reasons.append(chart_recommendation_failure_reason(item, chart_type, available_fields, df))
    return dedupe_chart_recommendations(filtered), reject_reasons


def normalize_chart_recommendation(row, chart_type):
    """Normalize one chart recommendation row."""
    item = dict(row)
    if item.get("chart_type") != chart_type:
        return None
    item["reason"] = str(item.get("reason", "")).strip()[:180] or "适合当前图表的字段组合。"
    if "numeric_fields" in item and not isinstance(item["numeric_fields"], list):
        item["numeric_fields"] = []
    if item.get("agg") not in [None, "", "sum", "mean", "median", "max", "min", "count"]:
        item["agg"] = "mean"
    if item.get("freq") not in [None, "", "D", "W", "M", "Q", "Y"]:
        item["freq"] = "M"
    try:
        item["n_clusters"] = int(item.get("n_clusters", 3))
    except (TypeError, ValueError):
        item["n_clusters"] = 3
    item["n_clusters"] = min(max(item["n_clusters"], 2), 6)
    return item


def chart_recommendation_is_valid(item, chart_type, available_fields, df):
    """Validate chart recommendation fields against available roles."""
    def has(role, field):
        return (
            bool(field)
            and field in available_fields.get(role, [])
            and not chart_field_not_recommendable(df, field)
            and chart_field_role_meaningful(df, field, role)
        )

    if chart_type == "类别分布":
        return has("category_field", item.get("category_field"))
    if chart_type == "分组对比":
        return has("group_field", item.get("group_field")) and has("value_field", item.get("value_field"))
    if chart_type == "数值分布":
        return has("value_field", item.get("value_field"))
    if chart_type == "趋势变化":
        return has("time_field", item.get("time_field")) and has("value_field", item.get("value_field"))
    if chart_type == "关系分析":
        return has("x_field", item.get("x_field")) and has("y_field", item.get("y_field")) and item.get("x_field") != item.get("y_field")
    if chart_type == "文本词云":
        return has("text_field", item.get("text_field"))
    if chart_type == "智能分群":
        fields = [
            field
            for field in item.get("numeric_fields", [])
            if field in available_fields.get("numeric_fields", [])
            and not chart_field_not_recommendable(df, field)
            and chart_field_role_meaningful(df, field, "numeric_fields")
        ]
        item["numeric_fields"] = fields[:4]
        return len(item["numeric_fields"]) >= 2
    return False


def chart_field_high_missing(df, field, threshold=40.0):
    """Return whether a chart recommendation field is too incomplete."""
    return field not in df.columns or float(df[field].isna().mean() * 100) >= threshold


def chart_field_identifier_like(field):
    """Return whether a field name is likely an identifier, not an analysis metric."""
    name = str(field).lower()
    return name == "id" or name.endswith("_id") or "url" in name or "identifier" in name


def chart_field_not_recommendable(df, field):
    """Return whether a field should not appear in proactive chart recommendations."""
    return chart_field_high_missing(df, field) or chart_field_identifier_like(field) or field not in df.columns


def chart_field_role_meaningful(df, field, role):
    """Return whether a field can produce a meaningful chart in a given role."""
    if field not in df.columns:
        return False
    series = df[field]
    non_null = series.dropna()
    if len(non_null) < 2:
        return False
    unique_count = int(non_null.nunique(dropna=True))
    unique_ratio = unique_count / max(len(non_null), 1)
    if role in {"category_field", "group_field"}:
        if unique_count < 2:
            return False
        if unique_count > 80 or unique_ratio > 0.6:
            return False
        if pd.api.types.is_numeric_dtype(series) and unique_count > 20:
            return False
        return is_scalar_display_column(series)
    if role in {"value_field", "x_field", "y_field", "numeric_fields"}:
        numeric = pd.to_numeric(series, errors="coerce").dropna()
        if len(numeric) < 3:
            return False
        return int(numeric.nunique(dropna=True)) >= 2
    if role == "time_field":
        parsed = pd.to_datetime(series, errors="coerce").dropna()
        return len(parsed) >= 2 and int(parsed.nunique(dropna=True)) >= 2
    if role == "text_field":
        text = non_null.astype(str).str.strip()
        text = text[text != ""]
        if len(text) < 3:
            return False
        return float(text.str.len().mean()) >= 3 and int(text.str.split().map(len).sum()) >= 5
    return True


def chart_field_role_failure_reason(df, field, role):
    """Explain why a field is not meaningful enough for a chart role."""
    if field not in df.columns:
        return f"{field} 不存在于当前数据中"
    if chart_field_high_missing(df, field):
        return f"{field} 缺失率过高，不适合作为推荐字段"
    if chart_field_identifier_like(field):
        return f"{field} 更像编号或链接字段，不适合作为推荐字段"
    if not chart_field_role_meaningful(df, field, role):
        return f"{field} 虽然存在，但不适合当前图表角色，生成图像的分析意义不足"
    return ""


def chart_recommendation_failure_reason(item, chart_type, available_fields, df):
    """Return a concise reason why one chart recommendation failed."""
    def field_state(role, field):
        if not field:
            return f"缺少 {role}"
        if field not in available_fields.get(role, []):
            return f"{field} 不在当前图表的 {role} 可选字段中"
        return chart_field_role_failure_reason(df, field, role)

    if chart_type == "类别分布":
        return field_state("category_field", item.get("category_field"))
    if chart_type == "分组对比":
        return "；".join(
            reason
            for reason in [
                field_state("group_field", item.get("group_field")),
                field_state("value_field", item.get("value_field")),
            ]
            if reason
        )
    if chart_type == "数值分布":
        return field_state("value_field", item.get("value_field"))
    if chart_type == "趋势变化":
        return "；".join(
            reason
            for reason in [
                field_state("time_field", item.get("time_field")),
                field_state("value_field", item.get("value_field")),
            ]
            if reason
        )
    if chart_type == "关系分析":
        if item.get("x_field") == item.get("y_field"):
            return "关系分析需要两个不同的数值字段"
        return "；".join(
            reason
            for reason in [
                field_state("x_field", item.get("x_field")),
                field_state("y_field", item.get("y_field")),
            ]
            if reason
        )
    if chart_type == "文本词云":
        return field_state("text_field", item.get("text_field"))
    if chart_type == "智能分群":
        fields = item.get("numeric_fields", [])
        if len(fields) < 2:
            return "智能分群至少需要两个在可选范围内的数值字段"
        invalid = [field for field in fields if field not in available_fields.get("numeric_fields", [])]
        if invalid:
            return "、".join(invalid[:3]) + " 不在智能分群可选字段中"
    return "字段组合不符合当前图表要求"


def local_chart_field_recommendations(df, chart_type, available_fields, limit=3):
    """Recommend chart fields with deterministic local rules."""
    rows = []
    usable_fields = {
        role: [
            field
            for field in fields
            if field in df.columns
            and not chart_field_not_recommendable(df, field)
            and chart_field_role_meaningful(df, field, role)
        ]
        for role, fields in available_fields.items()
    }
    if chart_type == "类别分布":
        for field in usable_fields.get("category_field", [])[:limit]:
            rows.append({"chart_type": chart_type, "category_field": field, "reason": f"“{display_field(field)}”可以用来统计不同取值出现的数量。"})
    elif chart_type == "分组对比":
        groups = usable_fields.get("group_field", [])
        values = usable_fields.get("value_field", [])
        for group in groups[:3]:
            for value in values[:3]:
                rows.append({"chart_type": chart_type, "group_field": group, "value_field": value, "agg": "mean", "reason": f"比较不同“{display_field(group)}”在“{display_field(value)}”上的平均差异。"})
                break
    elif chart_type == "数值分布":
        for field in usable_fields.get("value_field", [])[:limit]:
            rows.append({"chart_type": chart_type, "value_field": field, "reason": f"“{display_field(field)}”适合查看常见范围、集中程度和极端值。"})
    elif chart_type == "趋势变化":
        times = usable_fields.get("time_field", [])
        values = usable_fields.get("value_field", [])
        for time_field in times[:2]:
            if values:
                rows.append({"chart_type": chart_type, "time_field": time_field, "value_field": values[0], "freq": "M", "agg": "mean", "reason": f"按时间查看“{display_field(values[0])}”是否出现上升、下降或波动。"})
    elif chart_type == "关系分析":
        values = usable_fields.get("x_field", [])
        for index in range(min(len(values) - 1, limit)):
            rows.append({"chart_type": chart_type, "x_field": values[index], "y_field": values[index + 1], "reason": f"查看“{display_field(values[index])}”和“{display_field(values[index + 1])}”是否存在同步变化。"})
    elif chart_type == "文本词云":
        for field in usable_fields.get("text_field", [])[:limit]:
            rows.append({"chart_type": chart_type, "text_field": field, "reason": f"“{display_field(field)}”适合提取高频词语，帮助理解文本内容集中在哪些主题。"})
    elif chart_type == "智能分群":
        fields = usable_fields.get("numeric_fields", [])[:4]
        if len(fields) >= 2:
            rows.append({"chart_type": chart_type, "numeric_fields": fields, "n_clusters": 3, "reason": "这些数值字段可以共同描述记录特征，适合尝试按相似度分组。"})
    return dedupe_chart_recommendations(rows)[:limit]


def dedupe_chart_recommendations(rows):
    """Remove duplicate recommendation configurations."""
    seen = set()
    deduped = []
    for row in rows:
        key = json.dumps({k: v for k, v in row.items() if k not in ["reason", "source"]}, ensure_ascii=False, sort_keys=True)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(row)
    return deduped


def display_chart_recommendation_title(chart_type, item):
    """Return one-line chart recommendation title."""
    if chart_type == "类别分布":
        return f"使用 {display_field(item.get('category_field'))}"
    if chart_type == "分组对比":
        return f"使用 {display_field(item.get('group_field'))} + {display_field(item.get('value_field'))}，统计方式：{aggregation_label(item.get('agg', 'mean'))}"
    if chart_type == "数值分布":
        return f"使用 {display_field(item.get('value_field'))}"
    if chart_type == "趋势变化":
        return f"使用 {display_field(item.get('time_field'))} + {display_field(item.get('value_field'))}，时间粒度：{freq_label(item.get('freq', 'M'))}"
    if chart_type == "关系分析":
        return f"使用 {display_field(item.get('x_field'))} + {display_field(item.get('y_field'))}"
    if chart_type == "文本词云":
        return f"使用 {display_field(item.get('text_field'))}"
    if chart_type == "智能分群":
        fields = item.get("numeric_fields", [])
        return "使用 " + display_field_list(fields, limit=4)
    return "推荐字段组合"


def apply_chart_recommendation_to_state(item, widget_keys):
    """Apply a chart field recommendation to Streamlit widget state."""
    for config_key, widget_key in widget_keys.items():
        if config_key in item:
            st.session_state[widget_key] = item[config_key]


def run_cluster_recommendation(df, item, sample_size=1000):
    """Apply and immediately execute a recommended clustering configuration."""
    fields = [field for field in item.get("numeric_fields", []) if field in df.columns]
    if len(fields) < 2:
        return
    n_clusters = int(item.get("n_clusters", 3))
    result = cluster_analysis(
        df,
        fields,
        n_clusters=n_clusters,
        sample_size=sample_size,
    )
    save_cluster_result_for_session(df, result, fields, n_clusters)
    st.session_state["cluster_result_just_generated"] = True


def cluster_label_column_name(df):
    """Return a non-conflicting user-facing column name for clustering labels."""
    if "智能分群" not in df.columns:
        return "智能分群"
    return "智能分群结果"


def build_cluster_labeled_df(df, result, label_column=None):
    """Attach cluster labels back to the analysis data without changing raw data."""
    label_column = label_column or cluster_label_column_name(df)
    labeled_df = df.copy()
    points = result.get("points", pd.DataFrame())
    if points.empty or "row_index" not in points.columns or "cluster" not in points.columns:
        labeled_df[label_column] = pd.NA
        return labeled_df, label_column

    labels = points.set_index("row_index")["cluster"]
    labeled_df[label_column] = df.index.to_series().map(labels)
    labeled_df[label_column] = labeled_df[label_column].map(
        lambda value: f"第 {int(value)} 组" if pd.notna(value) else pd.NA
    )
    return labeled_df, label_column


def analysis_df_with_cluster_label(df):
    """Add the latest cluster label to the selected analysis data when available."""
    result = st.session_state.get("cluster_result")
    if not isinstance(result, dict):
        return df, None
    preferred_label = st.session_state.get("cluster_label_column", "智能分群")
    label_column = preferred_label if preferred_label not in df.columns else cluster_label_column_name(df)
    labeled_df, label_column = build_cluster_labeled_df(df, result, label_column=label_column)
    return labeled_df, label_column


def save_cluster_result_for_session(df, result, fields, n_clusters):
    """Save clustering output and make it available for downstream analysis."""
    labeled_df, label_column = build_cluster_labeled_df(df, result)
    st.session_state["cluster_result"] = result
    st.session_state["cluster_fields"] = fields
    st.session_state["cluster_k"] = n_clusters
    st.session_state["cluster_labeled_df"] = labeled_df
    st.session_state["cluster_label_column"] = label_column


def ensure_widget_value(key, options, default=None):
    """Keep a widget-backed session value valid after dataset changes."""
    if not options:
        return
    if key not in st.session_state or st.session_state[key] not in options:
        st.session_state[key] = default if default in options else options[0]


def ensure_multiselect_widget_value(key, options, default=None):
    """Keep a multiselect-backed session value valid after dataset changes."""
    default = default or []
    current = st.session_state.get(key, default)
    if not isinstance(current, list):
        current = default
    valid = [item for item in current if item in options]
    if not valid:
        valid = [item for item in default if item in options]
    st.session_state[key] = valid


def user_chart_recommendations(df):
    """Generate prioritized chart starting points."""
    profile = profile_table(df)
    numeric_columns = analysis_numeric_columns(df, profile["numeric_columns"])
    category_columns = category_like_columns(df)
    datetime_columns = profile["datetime_columns"]
    text_columns = text_like_columns(df)
    recommendations = []
    if category_columns and numeric_columns:
        recommendations.append(
            {
                "title": "先比较不同类别的差异",
                "target": "分组对比",
                "question": f"看看不同 {category_columns[0]} 在 {numeric_columns[0]} 上是否差异明显。",
                "fields": f"{category_columns[0]} + {numeric_columns[0]}",
                "reason": "同时存在类别字段和数值字段，适合直接做对比，通常比单独看字段更容易得到发现。",
            }
        )
    if numeric_columns:
        recommendations.append(
            {
                "title": "先看关键数值集中在哪",
                "target": "数值分布",
                "question": f"了解 {numeric_columns[0]} 的常见范围、中位水平和极端值。",
                "fields": numeric_columns[0],
                "reason": "数值分布能帮助判断后续用平均值、总和或分组比较时是否容易被极端值影响。",
            }
        )
    if category_columns:
        recommendations.append(
            {
                "title": "先看主要类别构成",
                "target": "类别分布",
                "question": f"查看 {category_columns[0]} 中哪些类别最多，数据是否集中在少数类别。",
                "fields": category_columns[0],
                "reason": "类别构成能帮助用户快速理解这份表格主要覆盖哪些对象或群体。",
            }
        )
    if datetime_columns and numeric_columns:
        recommendations.append(
            {
                "title": "看看指标是否随时间变化",
                "target": "趋势变化",
                "question": f"观察 {numeric_columns[0]} 是否随着 {datetime_columns[0]} 上升、下降或波动。",
                "fields": f"{datetime_columns[0]} + {numeric_columns[0]}",
                "reason": "数据里存在时间字段，趋势图可以帮助发现阶段变化。",
            }
        )
    if len(numeric_columns) >= 2:
        recommendations.append(
            {
                "title": "看看两个数值是否有关联",
                "target": "关系分析",
                "question": f"观察 {numeric_columns[0]} 和 {numeric_columns[1]} 是否存在同升同降或反向变化。",
                "fields": f"{numeric_columns[0]} + {numeric_columns[1]}",
                "reason": "多个数值字段之间可能存在关系，但系统会提醒相关不等于因果。",
            }
        )
        recommendations.append(
            {
                "title": "尝试把相似记录分成几组",
                "target": "智能分群",
                "question": "探索当前数据里是否存在几类特征相似的对象。",
                "fields": "、".join(numeric_columns[:4]),
                "reason": "多个数值字段可以用于分群，适合发现相似房源、客户、商品或样本类型。",
            }
        )
    if text_columns:
        recommendations.append(
            {
                "title": "看看文本里最常出现什么词",
                "target": "文本词云",
                "question": f"从 {text_columns[0]} 中提取高频词，判断文本描述集中在什么主题上。",
                "fields": text_columns[0],
                "reason": "当前数据包含文本字段，词云适合快速查看描述、评论或名称中反复出现的关键词。",
            }
        )
    missing_count = sum(v > 0 for v in profile["missing_counts"].values())
    if missing_count:
        recommendations.append(
            {
                "title": "先确认哪些字段不完整",
                "target": "缺失情况",
                "question": "查看缺失最多的字段，判断哪些分析结论需要谨慎。",
                "fields": f"{missing_count} 个字段存在缺失",
                "reason": "缺失值会影响图表和统计结果，分析前先看数据完整性更稳妥。",
            }
        )
    return recommendations[:5]


def show_ai_chart_request_panel(df, category_columns, numeric_columns, datetime_columns):
    """Create charts from natural-language requests through AI plus local validation."""
    numeric_candidates = numeric_like_columns(df)
    section("AI 需求作图", SUBMODULE_NOTES.get("AI 需求作图"))
    show_ai_status_notice()

    with template_block("01", "输入需求", "用一句话描述你想看的图，AI 只负责理解需求，最终仍由本地规则校验和生成。", "blue"):
        request = st.text_area(
            "写下你想看的图",
            placeholder=chart_request_placeholder(category_columns, numeric_candidates, datetime_columns),
            height=120,
            key="ai_chart_request_text",
        )
        if st.button("理解需求", type="primary", use_container_width=True):
            st.session_state.pop("ai_chart_instruction", None)
            st.session_state.pop("ai_chart_status", None)
            instruction, status = parse_ai_chart_request(df, request)
            st.session_state["ai_chart_instruction"] = instruction
            st.session_state["ai_chart_status"] = status
            st.session_state.pop("ai_chart_result", None)

    instruction = st.session_state.get("ai_chart_instruction")
    status = st.session_state.get("ai_chart_status")

    with st.expander("当前可用字段", expanded=False):
        st.write(f"- 可用于分类/分组的字段：{display_field_list(category_columns, limit=12) if category_columns else '暂无'}")
        st.write(f"- 可用于数值分析的字段：{display_field_list(numeric_candidates, limit=12) if numeric_candidates else '暂无'}")
        st.write(f"- 可用于时间趋势的字段：{display_field_list(datetime_columns or likely_time_columns(df.columns), limit=12)}")

    if not instruction or not status:
        return

    with template_block("02", "理解结果", "查看系统是否成功识别图表类型和字段；无法生成时会给出具体原因。", "teal"):
        if not instruction.get("valid"):
            st.warning(instruction.get("message", "暂时无法把这句话转成可执行图表。"))
            show_evidence_box(**status)
            return

        st.write(ai_chart_instruction_summary(instruction))
        soft_notes = ai_chart_soft_warnings(df, instruction)
        if soft_notes:
            for note in soft_notes:
                st.caption(note)
        show_evidence_box(**status)

        if st.button("生成图表", type="primary", use_container_width=True):
            st.session_state["ai_chart_result"] = execute_ai_chart_instruction(df, instruction)
            st.session_state["ai_chart_result_just_generated"] = True
            add_history_event(
                "图表记录",
                "AI 需求作图",
                fields=ai_chart_instruction_fields(instruction),
                method=AI_CHART_INTENT_LABELS.get(instruction["intent"], instruction["intent"]),
                result=st.session_state["ai_chart_result"].get("insight", "已生成图表。"),
                dedupe_key=f"ai_chart|{json.dumps(instruction, ensure_ascii=False, sort_keys=True)}",
            )

    result = st.session_state.get("ai_chart_result")
    if result:
        should_show_result = bool(st.session_state.pop("ai_chart_result_just_generated", False))
        if not should_show_result:
            cols = st.columns(2)
            if cols[0].button("查看已有图表", use_container_width=True, key="view_existing_ai_chart_result"):
                should_show_result = True
            if cols[1].button("重新生成图表", type="primary", use_container_width=True, key="rerun_existing_ai_chart_result"):
                st.session_state["ai_chart_result"] = execute_ai_chart_instruction(df, instruction)
                result = st.session_state["ai_chart_result"]
                should_show_result = True
            if not should_show_result:
                st.caption("已有根据当前需求生成的图表，可以查看，也可以重新生成。")
                return
        render_ai_chart_result(result)


AI_CHART_INTENT_LABELS = {
    "category_distribution": "类别分布",
    "numeric_distribution": "数值分布",
    "group_comparison": "分组对比",
    "trend": "趋势变化",
    "relationship": "关系分析",
    "missing_values": "缺失情况",
}


def parse_ai_chart_request(df, request):
    """Parse a natural-language chart request into a validated instruction."""
    request = str(request or "").strip()
    base_status = {
        "source": "AI 解析 + 本地校验",
        "inputs": "用户输入的作图需求、当前候选字段、字段中文含义、可用角色、字段类型、非空数量、缺失率、唯一值数量和少量样例值。",
        "validation": "AI 先判断图表类型和用户概念词，并在多个候选字段中选择最贴合问题含义的字段；本地再校验图表类型、字段存在性、非空数据、字段可转换性和参数范围。",
        "fallback": "AI 不可用、解析失败或本地校验失败时，页面会返回具体原因，例如字段不存在、字段存在但全为空、字段不能作为数值/时间字段使用。",
        "note": "AI 只负责理解需求和选择候选字段，不生成也不执行代码；最终图表由本地白名单函数生成。",
    }
    if not request:
        return {"valid": False, "message": "请先输入想看的图表需求。"}, base_status

    status = ai_status()
    if not status["can_call"]:
        base_status["source"] = "未调用 AI"
        base_status["fallback"] = "AI 当前不可调用。可以进入具体图表页面，使用推荐方案或手动选择字段。"
        return {"valid": False, "message": "AI 当前不可调用，暂时无法自动理解作图需求。"}, base_status

    prompt = build_ai_chart_request_prompt(df, request)
    data, error = request_structured_json(prompt, ai_chart_request_schema())
    if error or not data:
        return {"valid": False, "message": error or "AI 没有返回可用图表指令。"}, base_status

    instruction = normalize_ai_chart_instruction(data.get("instruction", data), df)
    instruction = repair_ai_chart_instruction_from_request(instruction, df, request)
    valid, message = validate_ai_chart_instruction(df, instruction)
    if not valid:
        return {"valid": False, "message": message}, base_status

    instruction["valid"] = True
    return instruction, base_status


def build_ai_chart_request_prompt(df, request):
    """Build prompt for AI chart request parsing."""
    numeric_candidates = numeric_like_columns(df)
    payload = build_chart_recommendation_payload(
        df,
        "AI 需求作图",
        {
            "category_field": category_like_columns(df),
            "group_field": category_like_columns(df),
            "value_field": numeric_candidates,
            "time_field": profile_table(df)["datetime_columns"] or likely_time_columns(df.columns),
            "x_field": numeric_candidates,
            "y_field": numeric_candidates,
        },
        limit=1,
    )
    return (
        "你是 DataMind 的自然语言作图需求解析器。请把用户需求转成一个安全的图表指令。"
        "不要生成代码，不要编造字段，不要输出解释文字，只返回 JSON。\n\n"
        "支持的 intent 只有：category_distribution, numeric_distribution, group_comparison, trend, relationship, missing_values。\n"
        "字段名必须逐字使用数据摘要里的 column 原文，不能使用中文翻译或括号标签。"
        "请先理解用户问题中的业务概念，例如“价格”“评分”“房型”“评论数量”“地区”“时间”，再根据 column、display_label、examples、available_roles、non_empty_count 和 numeric_usable 在候选字段中选择最贴合用户原意的字段。\n"
        "如果同一个概念有多个候选字段，必须选择语义最贴近用户问题的字段：例如“评分”通常优先选择综合评分而不是单项评分；“评论数量”优先选择评论总数而不是评论文本；“房型”优先选择 room_type 或房源类型字段。\n"
        "不要为了让图表通过而把用户概念改成另一个含义相近但不相同的字段。例如用户问“价格”时，如果 price 存在但 non_empty_count 为 0，仍可选择 price，让本地校验返回具体不可用原因；不要擅自改成收入、编号、链接或图片字段。\n"
        "如果没有任何字段能表达用户概念，请把对应字段留空字符串，并在 reason 中用面向用户的中文说明缺少什么字段。\n"
        "允许参数：agg 只能是 sum/mean/median/max/min/count；freq 只能是 D/W/M/Q/Y；top_n 为 1 到 100。\n\n"
        "JSON 格式示例：\n"
        '{"instruction":{"intent":"category_distribution","concepts":["房型","房源数量"],"category_field":"room_type","top_n":10,"field_choices":[{"concept":"房型","field":"room_type","why":"最贴近房型概念"}],"reason":"统计不同房型的房源数量。"}}\n'
        '{"instruction":{"intent":"group_comparison","concepts":["房型","价格"],"group_field":"room_type","value_field":"price","agg":"mean","top_n":10,"field_choices":[{"concept":"房型","field":"room_type","why":"最贴近房型概念"},{"concept":"价格","field":"price","why":"字段含义直接对应价格"}],"reason":"..."}}\n\n'
        f"用户需求：{request}\n\n"
        f"数据摘要：{payload}"
    )


def ai_chart_request_schema():
    """Return JSON schema for AI chart request parsing."""
    return {
        "name": "datamind_ai_chart_request",
        "schema": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "instruction": {
                    "type": "object",
                    "additionalProperties": True,
                    "properties": {
                        "intent": {"type": "string"},
                        "category_field": {"type": "string"},
                        "group_field": {"type": "string"},
                        "value_field": {"type": "string"},
                        "time_field": {"type": "string"},
                        "x_field": {"type": "string"},
                        "y_field": {"type": "string"},
                        "concepts": {"type": "array", "items": {"type": "string"}},
                        "field_choices": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "additionalProperties": True,
                                "properties": {
                                    "concept": {"type": "string"},
                                    "field": {"type": "string"},
                                    "why": {"type": "string"},
                                },
                            },
                        },
                        "agg": {"type": "string"},
                        "freq": {"type": "string"},
                        "top_n": {"type": "integer"},
                        "reason": {"type": "string"},
                    },
                    "required": ["intent", "reason"],
                }
            },
            "required": ["instruction"],
        },
    }


def normalize_ai_chart_instruction(raw_instruction, df):
    """Normalize field names and parameters from AI output."""
    instruction = dict(raw_instruction or {})
    instruction["intent"] = str(instruction.get("intent", "")).strip()
    instruction["reason"] = str(instruction.get("reason", "根据你的需求生成图表。")).strip()
    if isinstance(instruction.get("concepts"), list):
        instruction["concepts"] = [str(item).strip() for item in instruction["concepts"] if str(item).strip()]
    if isinstance(instruction.get("field_choices"), list):
        instruction["field_choices"] = [
            {
                "concept": str(item.get("concept", "")).strip(),
                "field": resolve_field_reference(item.get("field", ""), df),
                "why": str(item.get("why", "")).strip(),
            }
            for item in instruction["field_choices"]
            if isinstance(item, dict)
        ]
    for key in ["category_field", "group_field", "value_field", "time_field", "x_field", "y_field"]:
        if key in instruction:
            instruction[key] = resolve_field_reference(instruction.get(key), df)
    instruction["agg"] = str(instruction.get("agg", "mean")).strip()
    if instruction["agg"] not in ["sum", "mean", "median", "max", "min", "count"]:
        instruction["agg"] = "mean"
    instruction["freq"] = str(instruction.get("freq", "M")).strip()
    if instruction["freq"] not in ["D", "W", "M", "Q", "Y"]:
        instruction["freq"] = "M"
    try:
        instruction["top_n"] = int(instruction.get("top_n", 10))
    except (TypeError, ValueError):
        instruction["top_n"] = 10
    instruction["top_n"] = min(max(instruction["top_n"], 1), 100)
    return instruction


def repair_ai_chart_instruction_from_request(instruction, df, request):
    """Fill missing AI chart fields from the user's original request when possible."""
    repaired = dict(instruction or {})
    request = str(request or "")
    concepts = repaired.get("concepts") if isinstance(repaired.get("concepts"), list) else []
    texts = [str(item) for item in concepts if str(item).strip()]
    texts.append(request)

    def first_field_for_texts(predicate=None):
        for text in texts:
            field = resolve_field_reference(text, df)
            if field in df.columns and (predicate is None or predicate(field)):
                return field
        return ""

    def category_field(field):
        return field in category_like_columns(df)

    def numeric_or_named_field(field):
        return field in numeric_like_columns(df) or int(df[field].notna().sum()) == 0

    def time_field(field):
        return field in (profile_table(df)["datetime_columns"] or likely_time_columns(df.columns))

    intent = repaired.get("intent")
    if intent == "category_distribution" and not repaired.get("category_field"):
        repaired["category_field"] = first_field_for_texts(category_field)
    elif intent == "group_comparison":
        if not repaired.get("group_field"):
            repaired["group_field"] = first_field_for_texts(category_field)
        if not repaired.get("value_field"):
            repaired["value_field"] = first_field_for_texts(numeric_or_named_field)
    elif intent == "numeric_distribution" and not repaired.get("value_field"):
        repaired["value_field"] = first_field_for_texts(numeric_or_named_field)
    elif intent == "trend":
        if not repaired.get("time_field"):
            repaired["time_field"] = first_field_for_texts(time_field)
        if not repaired.get("value_field"):
            repaired["value_field"] = first_field_for_texts(numeric_or_named_field)
    elif intent == "relationship":
        if not repaired.get("x_field") or not repaired.get("y_field"):
            fields = []
            for text in texts:
                field = resolve_field_reference(text, df)
                if field in df.columns and numeric_or_named_field(field):
                    fields.append(field)
            fields = list(dict.fromkeys(fields))
            if not repaired.get("x_field") and fields:
                repaired["x_field"] = fields[0]
            if not repaired.get("y_field") and len(fields) > 1:
                repaired["y_field"] = fields[1]
    return repaired


def resolve_field_reference(value, df):
    """Resolve original field name from raw, translated, or display labels."""
    text = str(value or "").strip()
    if text in df.columns:
        return text
    text_without_label = re.sub(r"（.*?）", "", text).strip()
    if text_without_label in df.columns:
        return text_without_label
    normalized_text = normalize_field_reference_text(text)
    for column in df.columns:
        if normalized_text and normalized_text == normalize_field_reference_text(column):
            return column
    lowered = text.lower()
    for column in df.columns:
        label = display_field(column)
        local_translation = local_translate_field_name(column)
        cached_translation = current_field_translations().get(str(column), "")
        candidates = {
            str(column).lower(),
            label.lower(),
            local_translation.lower(),
            cached_translation.lower(),
        }
        if lowered in candidates:
            return column
        if text and text in {local_translation, cached_translation}:
            return column
    for column in df.columns:
        label = display_field(column).lower()
        local_translation = local_translate_field_name(column).lower()
        cached_translation = current_field_translations().get(str(column), "").lower()
        normalized_column = normalize_field_reference_text(column)
        normalized_label = normalize_field_reference_text(display_field(column))
        normalized_local = normalize_field_reference_text(local_translate_field_name(column))
        normalized_cached = normalize_field_reference_text(current_field_translations().get(str(column), ""))
        if lowered and (
            lowered in label
            or lowered in str(column).lower()
            or lowered in local_translation
            or lowered in cached_translation
            or str(column).lower() in lowered
            or (normalized_text and normalized_text in normalized_column)
            or (normalized_text and normalized_text in normalized_label)
            or (normalized_text and normalized_text in normalized_local)
            or (normalized_text and normalized_text in normalized_cached)
        ):
            return column
    semantic_match = resolve_field_by_semantic_keywords(text, df)
    if semantic_match:
        return semantic_match
    return text


def normalize_field_reference_text(value):
    """Normalize a field reference for fuzzy matching."""
    return re.sub(r"[\W_]+", "", str(value or "").lower())


def resolve_field_by_semantic_keywords(text, df):
    """Resolve common Chinese analysis words to likely dataset fields."""
    lowered = str(text or "").lower()
    semantic_keywords = [
        (["价格", "价钱", "费用", "金额", "price", "cost", "fee"], ["price", "cost", "fee", "amount", "价格", "费用", "金额"]),
        (["评分", "得分", "评价分", "rating", "score"], ["review_scores_rating", "rating", "score", "评分", "得分"]),
        (["房型", "房源类型", "类型", "room type", "property type"], ["room_type", "property_type", "type", "房型", "类型"]),
        (["地区", "街区", "社区", "位置", "neighbourhood", "neighborhood", "city"], ["neighbourhood", "neighborhood", "city", "region", "地区", "街区", "社区", "位置"]),
        (["评论", "评价数量", "review"], ["number_of_reviews", "reviews_per_month", "review", "评论", "评价"]),
        (["时间", "日期", "月份", "date", "time"], ["date", "time", "last_review", "last_scraped", "时间", "日期", "月份"]),
    ]
    for query_words, field_tokens in semantic_keywords:
        if any(word in lowered for word in query_words):
            for token in field_tokens:
                for column in df.columns:
                    candidates = [
                        str(column).lower(),
                        display_field(column).lower(),
                        local_translate_field_name(column).lower(),
                        current_field_translations().get(str(column), "").lower(),
                    ]
                    normalized_candidates = [normalize_field_reference_text(candidate) for candidate in candidates]
                    normalized_token = normalize_field_reference_text(token)
                    if any(token.lower() in candidate for candidate in candidates) or any(
                        normalized_token and normalized_token in candidate for candidate in normalized_candidates
                    ):
                        return column
    return None


def suggest_related_fields(field, df, limit=5):
    """Suggest fields that may match a missing AI field reference."""
    text = str(field or "").strip()
    if not text:
        return []
    semantic_suggestions = semantic_related_fields(text, df, limit=limit)
    if semantic_suggestions:
        return semantic_suggestions
    normalized_text = normalize_field_reference_text(text)
    suggestions = []
    for column in df.columns:
        candidates = [
            str(column),
            display_field(column),
            local_translate_field_name(column),
            current_field_translations().get(str(column), ""),
        ]
        normalized_candidates = [normalize_field_reference_text(candidate) for candidate in candidates]
        if any(
            normalized_text
            and normalized_candidate
            and (
                normalized_text in normalized_candidate
                or normalized_candidate in normalized_text
            )
            for normalized_candidate in normalized_candidates
        ):
            suggestions.append(column)
    return list(dict.fromkeys(suggestions))[:limit]


def semantic_related_fields(text, df, limit=5):
    """Return same-meaning field suggestions for common user concepts."""
    lowered = str(text or "").lower()
    semantic_groups = [
        (["价格", "价钱", "费用", "金额", "price", "cost", "fee", "amount"], ["price", "cost", "fee", "amount", "revenue", "sales"]),
        (["评分", "得分", "评价分", "rating", "score"], ["review_scores", "rating", "score"]),
        (["房型", "房源类型", "类型", "room type", "property type"], ["room_type", "property_type"]),
        (["地区", "街区", "社区", "位置", "neighbourhood", "neighborhood", "city"], ["neighbourhood", "neighborhood", "city", "region"]),
        (["评论", "评价数量", "review"], ["number_of_reviews", "reviews_per_month", "review"]),
        (["时间", "日期", "月份", "date", "time"], ["date", "time", "last_review", "last_scraped"]),
    ]
    for query_words, field_tokens in semantic_groups:
        if any(word in lowered for word in query_words):
            matches = []
            for column in df.columns:
                candidates = [
                    str(column).lower(),
                    display_field(column).lower(),
                    local_translate_field_name(column).lower(),
                    current_field_translations().get(str(column), "").lower(),
                ]
                normalized_candidates = [normalize_field_reference_text(candidate) for candidate in candidates]
                for token in field_tokens:
                    normalized_token = normalize_field_reference_text(token)
                    if any(token.lower() in candidate for candidate in candidates) or any(
                        normalized_token and normalized_token in candidate for candidate in normalized_candidates
                    ):
                        matches.append(column)
                        break
            return list(dict.fromkeys(matches))[:limit]
    return []


def missing_field_message(field, label, df):
    """Build a user-facing message for a missing chart field."""
    suggestions = suggest_related_fields(field, df)
    if suggestions:
        return (
            f"字段“{field or label}”没有直接匹配到当前数据列。"
            f"你可以改用：{display_field_list(suggestions, limit=5)}。"
        )
    return f"字段“{field or label}”不存在于当前数据中。"


def validate_ai_chart_instruction(df, instruction):
    """Hard validation for natural-language chart instructions."""
    intent = instruction.get("intent")
    if intent not in AI_CHART_INTENT_LABELS:
        return False, "AI 推荐的图表类型当前不支持。"

    def exists(field, label):
        if not field:
            return False, f"没有找到可用于当前图表的{label}。请确认数据中是否有对应字段。"
        if field not in df.columns:
            return False, missing_field_message(field, label, df)
        return True, ""

    def numeric(field):
        ok, message = exists(field, "数值字段")
        if not ok:
            return False, message
        if int(df[field].notna().sum()) == 0:
            return False, f"字段“{display_field(field)}”存在，但当前没有可用于计算的非空数据。"
        if is_numeric_usable(df[field]):
            return True, ""
        return False, f"字段“{display_field(field)}”暂时不能作为数值字段使用。"

    def time(field):
        ok, message = exists(field, "时间字段")
        if not ok:
            return False, message
        if pd.to_datetime(df[field], errors="coerce").notna().sum() > 0:
            return True, ""
        return False, f"字段“{display_field(field)}”暂时不能转换为时间字段。"

    if intent == "category_distribution":
        return exists(instruction.get("category_field"), "类别字段")
    if intent == "numeric_distribution":
        return numeric(instruction.get("value_field"))
    if intent == "group_comparison":
        ok, message = exists(instruction.get("group_field"), "分组字段")
        if not ok:
            return False, message
        return numeric(instruction.get("value_field"))
    if intent == "trend":
        ok, message = time(instruction.get("time_field"))
        if not ok:
            return False, message
        return numeric(instruction.get("value_field"))
    if intent == "relationship":
        if instruction.get("x_field") == instruction.get("y_field"):
            return False, "关系分析需要两个不同的数值字段。"
        ok, message = numeric(instruction.get("x_field"))
        if not ok:
            return False, message
        return numeric(instruction.get("y_field"))
    if intent == "missing_values":
        return True, ""
    return False, "当前暂不支持该图表需求。"


def is_numeric_usable(series):
    """Return whether a series can be used as numeric after safe conversion."""
    if pd.api.types.is_numeric_dtype(series):
        return int(series.notna().sum()) > 0
    converted = pd.to_numeric(normalize_numeric_text_for_chart(series), errors="coerce")
    return int(converted.notna().sum()) > 0


def normalize_numeric_text_for_chart(series):
    """Normalize common numeric text forms for temporary chart execution."""
    text = series.astype("string").str.strip()
    text = text.str.replace(r"^\((.*)\)$", r"-\1", regex=True)
    text = text.str.replace(",", "", regex=False)
    text = text.str.replace(r"[$€£¥￥]", "", regex=True)
    text = text.str.replace("%", "", regex=False)
    return text


def prepare_ai_chart_df(df, instruction):
    """Return a chart-only copy with required numeric/time conversions."""
    chart_df = df.copy()
    for key in ["value_field", "x_field", "y_field"]:
        field = instruction.get(key)
        if field in chart_df.columns and not pd.api.types.is_numeric_dtype(chart_df[field]):
            chart_df[field] = pd.to_numeric(normalize_numeric_text_for_chart(chart_df[field]), errors="coerce")
    time_field = instruction.get("time_field")
    if time_field in chart_df.columns:
        chart_df[time_field] = pd.to_datetime(chart_df[time_field], errors="coerce")
    return chart_df


def ai_chart_soft_warnings(df, instruction):
    """Return non-blocking warnings for chart interpretation."""
    warnings = []
    for key in ["value_field", "x_field", "y_field"]:
        field = instruction.get(key)
        if field in df.columns:
            unique_count = int(df[field].nunique(dropna=True))
            if is_identifier_field(str(field).lower(), df[field], unique_count):
                warnings.append(f"“{display_field(field)}”看起来像编号字段，图表可以生成，但结论需要谨慎解释。")
            if float(df[field].isna().mean()) >= 0.4:
                warnings.append(f"“{display_field(field)}”缺失较多，图表结果可能不稳定。")
    group_field = instruction.get("group_field") or instruction.get("category_field")
    if group_field in df.columns and int(df[group_field].nunique(dropna=True)) > 80:
        warnings.append(f"“{display_field(group_field)}”类别较多，图表可能较拥挤。")
    if instruction.get("intent") == "relationship":
        warnings.append("关系图只能说明同步变化趋势，不能直接证明因果关系。")
    return list(dict.fromkeys(warnings))


def ai_chart_instruction_summary(instruction):
    """Return a user-facing summary of parsed chart instruction."""
    label = AI_CHART_INTENT_LABELS.get(instruction["intent"], instruction["intent"])
    fields = ai_chart_instruction_fields(instruction)
    concepts = "、".join(instruction.get("concepts", []))
    concept_text = f"你提到的重点是：{concepts}。" if concepts else ""
    return f"我理解你想生成：{label}。{concept_text}使用字段：{fields or '无需选择字段'}。"


def ai_chart_instruction_fields(instruction):
    """Return display fields used by an AI chart instruction."""
    fields = []
    for key in ["category_field", "group_field", "value_field", "time_field", "x_field", "y_field"]:
        field = instruction.get(key)
        if field:
            fields.append(display_field(field))
    return " + ".join(fields)


def execute_ai_chart_instruction(df, instruction):
    """Execute a validated AI chart instruction with local whitelisted functions."""
    chart_df = prepare_ai_chart_df(df, instruction)
    intent = instruction["intent"]
    n = instruction.get("top_n", 10)
    if intent == "category_distribution":
        column = instruction["category_field"]
        result = top_n(chart_df, column, n=n)
        return {
            "figure": bar_chart(display_chart_dataframe(result, x=column), x=column, y="count", title=f"{display_field(column)} 类别分布 Top {n}"),
            "insight": category_distribution_insight(result, column),
            "detail": result,
        }
    if intent == "numeric_distribution":
        column = instruction["value_field"]
        return {
            "figures": [
                histogram(chart_df, column, title=f"{display_field(column)} 分布"),
                box_chart(chart_df, column, title=f"{display_field(column)} 极端值查看"),
            ],
            "insight": numeric_distribution_insight(chart_df, column),
            "detail": chart_df[column].describe().reset_index().rename(columns={"index": "指标", column: "数值"}),
        }
    if intent == "group_comparison":
        group_column = instruction["group_field"]
        value_column = instruction["value_field"]
        agg = instruction.get("agg", "mean")
        result = groupby_agg(chart_df, group_column, value_column, agg=agg, n=n)
        y_column = f"{value_column}_{agg}"
        return {
            "figure": bar_chart(display_chart_dataframe(result, x=group_column), x=group_column, y=y_column, title=f"{display_field(group_column)} 的 {display_field(value_column)} {aggregation_label(agg)}对比"),
            "insight": group_comparison_insight(result, group_column, y_column, value_column, agg),
            "detail": result,
        }
    if intent == "trend":
        time_column = instruction["time_field"]
        value_column = instruction["value_field"]
        freq = instruction.get("freq", "M")
        agg = instruction.get("agg", "mean")
        result = trend_analysis(chart_df, time_column, value_column, freq=freq, agg=agg)
        y_column = f"{value_column}_{agg}"
        return {
            "figure": line_chart(result, x=time_column, y=y_column, title=f"{display_field(value_column)} 趋势变化"),
            "insight": trend_insight(result, time_column, y_column, value_column, agg),
            "detail": result,
        }
    if intent == "relationship":
        x_column = instruction["x_field"]
        y_column = instruction["y_field"]
        return {
            "figure": scatter_chart(chart_df, x=x_column, y=y_column, title=f"{display_field(x_column)} 与 {display_field(y_column)} 的关系"),
            "insight": relationship_insight(chart_df, x_column, y_column),
            "detail": chart_df[[x_column, y_column]].dropna().head(100),
        }
    if intent == "missing_values":
        result = missing_values(chart_df).sort_values("missing_count", ascending=False).head(n)
        return {
            "figure": bar_chart(display_chart_dataframe(result, x="column"), x="column", y="missing_count", title=f"缺失值最多的 {n} 个字段"),
            "insight": missing_values_insight(result),
            "detail": result,
        }
    raise AnalysisError("当前暂不支持该图表需求。")


def render_ai_chart_result(result):
    """Render AI-generated chart result with folded details."""
    with template_block("03", "图表结果", "查看根据自然语言需求生成的图表、结论和数据明细。", "green"):
        for fig in result.get("figures", []):
            show_plotly_chart(fig)
        if result.get("figure") is not None:
            show_plotly_chart(result["figure"])
        chart_note("图表结论", result.get("insight", "图表已生成。"))
        detail = result.get("detail")
        if isinstance(detail, pd.DataFrame):
            with st.expander("数据明细", expanded=False):
                st.dataframe(display_analysis_table(detail), use_container_width=True)


def chart_result_cache_key(chart_type, df, params):
    """Build a cache key for rendered chart results in the current session."""
    params_text = json.dumps(params, ensure_ascii=False, sort_keys=True, default=str)
    return (str(chart_type), dataframe_signature(df), params_text)


def get_chart_result(chart_type, df, params):
    """Read a cached chart result without recomputing."""
    cache = st.session_state.setdefault("chart_result_cache", {})
    return cache.get(chart_result_cache_key(chart_type, df, params))


def set_chart_result(chart_type, df, params, result):
    """Store a chart result for faster page switching."""
    cache = st.session_state.setdefault("chart_result_cache", {})
    cache[chart_result_cache_key(chart_type, df, params)] = result
    st.session_state["chart_result_cache"] = cache


def show_generate_chart_button(chart_type, df, params, build_result, button_label="生成图表", trigger_key=None):
    """Generate a chart result only when the user asks for it."""
    cache_key = chart_result_cache_key(chart_type, df, params)
    button_key = hashlib.sha256(json.dumps(cache_key, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")).hexdigest()
    pending_key = st.session_state.get("pending_generate_chart_type")
    should_generate = pending_key == (trigger_key or chart_type)
    if should_generate:
        st.session_state.pop("pending_generate_chart_type", None)
    cached = get_chart_result(chart_type, df, params)

    if cached is not None and not should_generate:
        cols = st.columns(2)
        if cols[0].button("查看已有图表", use_container_width=True, key=f"view_chart_{chart_type}_{button_key}"):
            return cached
        if cols[1].button("重新生成图表", type="primary", use_container_width=True, key=f"regenerate_chart_{chart_type}_{button_key}"):
            result = build_result()
            set_chart_result(chart_type, df, params, result)
            return result
        st.caption("当前设置已有图表结果，可以直接查看，也可以重新生成。")
        return None

    if should_generate or st.button(button_label, type="primary", use_container_width=True, key=f"generate_chart_{chart_type}"):
        result = build_result()
        set_chart_result(chart_type, df, params, result)
        return result
    return None


def show_category_distribution(df, category_columns):
    """Show a category frequency bar chart."""
    section("类别分布", SUBMODULE_NOTES.get("类别分布"))
    if not category_columns:
        st.warning("当前数据没有明显适合做类别分布的字段。")
        return
    show_chart_field_recommendations(
        df,
        "类别分布",
        {"category_field": category_columns},
        {"category_field": "chart_category_field"},
    )
    with template_block("02", "自定义设置", "自己选择要分析的字段、展示数量和图表形式；字段选择框支持搜索字段名或中文翻译。", "blue"):
        ensure_widget_value("chart_category_field", category_columns)
        ensure_widget_value("chart_category_display", ["柱状图", "饼图", "环形图"], "柱状图")
        column = st.selectbox("选择类别字段", category_columns, format_func=display_field, key="chart_category_field")
        display_mode = st.selectbox("展示方式", ["柱状图", "饼图", "环形图"], key="chart_category_display")
        n = st.number_input("展示前 N 项", min_value=1, max_value=100, value=10)
        if display_mode in {"饼图", "环形图"} and int(n) > 12:
            st.caption("饼图和环形图更适合类别较少的情况；类别较多时建议缩小 Top N 或使用柱状图。")
    params = {"column": column, "n": int(n), "display_mode": display_mode}

    def build_result():
        result = top_n(df, column, n)
        insight = category_distribution_insight(result, column, display_mode=display_mode)
        add_history_event(
            "图表记录",
            "查看类别分布",
            fields=column,
            method=f"{display_mode} Top {n} 频次",
            result=insight,
            dedupe_key=f"chart|category|{column}|{n}|{display_mode}",
        )
        return {"result": result, "insight": insight}

    cached = show_generate_chart_button("category_distribution", df, params, build_result, trigger_key="类别分布")
    if not cached:
        st.caption("调整设置后点击“生成图表”查看结果。")
        return

    result = cached["result"]
    with template_block("03", "图表结果", "查看当前设置生成的图表、结论和数据明细。", "green"):
        chart_df = display_chart_dataframe(result, x=column)
        if display_mode == "柱状图":
            fig = bar_chart(chart_df, x=column, y="count", title=f"{display_field(column)} 类别分布 Top {n}")
        else:
            fig = pie_chart(
                chart_df,
                names=column,
                values="count",
                title=f"{display_field(column)} 占比结构 Top {n}",
                hole=0.45 if display_mode == "环形图" else 0,
            )
        show_plotly_chart(fig)
        chart_note("图表结论", cached["insight"])
        with st.expander("数据明细", expanded=False):
            st.dataframe(display_analysis_table(result), use_container_width=True)


def show_group_comparison(df, category_columns, numeric_columns):
    """Show grouped numeric comparison charts."""
    section("分组对比", SUBMODULE_NOTES.get("分组对比"))
    if not category_columns:
        st.warning("当前数据没有明显类别字段，暂时无法做分组对比。")
        return
    if not numeric_columns:
        st.warning("当前数据没有可计算的数值字段。建议先到清洗预处理尝试数值转换。")
        return
    show_chart_field_recommendations(
        df,
        "分组对比",
        {"group_field": category_columns, "value_field": numeric_columns},
        {"group_field": "chart_group_field", "value_field": "chart_group_value_field", "agg": "chart_group_agg"},
    )
    with template_block("02", "自定义设置", "自己选择分组字段、数值字段、统计方式和图表形式；字段选择框支持搜索字段名或中文翻译。", "blue"):
        ensure_widget_value("chart_group_field", category_columns)
        ensure_widget_value("chart_group_value_field", numeric_columns)
        ensure_widget_value("chart_group_agg", ["mean", "sum", "max", "min", "count"])
        ensure_widget_value("chart_group_display", ["柱状图", "饼图", "环形图"], "柱状图")
        group_column = st.selectbox("选择分组字段", category_columns, format_func=display_field, key="chart_group_field")
        value_column = st.selectbox("选择数值字段", numeric_columns, format_func=display_field, key="chart_group_value_field")
        agg = st.selectbox("统计方式", ["mean", "sum", "max", "min", "count"], format_func=aggregation_label, key="chart_group_agg")
        if agg in {"sum", "count"}:
            display_mode = st.selectbox("展示方式", ["柱状图", "饼图", "环形图"], key="chart_group_display")
        else:
            display_mode = "柱状图"
            st.caption("平均值、最大值、最小值不表示整体被分成几份，因此更适合用柱状图比较。")
        n = st.number_input("展示前 N 组", min_value=1, max_value=100, value=10)
        if display_mode in {"饼图", "环形图"} and int(n) > 12:
            st.caption("饼图和环形图更适合组别较少的情况；组别较多时建议缩小 Top N 或使用柱状图。")
    params = {"group_column": group_column, "value_column": value_column, "agg": agg, "n": int(n), "display_mode": display_mode}

    def build_result():
        result = groupby_agg(df, group_column, value_column, agg=agg, n=n)
        y_column = f"{value_column}_{agg}"
        insight = group_comparison_insight(result, group_column, y_column, value_column, agg, display_mode=display_mode)
        add_history_event(
            "图表记录",
            "查看分组对比",
            fields=f"{group_column} + {value_column}",
            method=f"{display_mode} {aggregation_label(agg)}",
            result=insight,
            dedupe_key=f"chart|group|{group_column}|{value_column}|{agg}|{n}|{display_mode}",
        )
        return {"result": result, "y_column": y_column, "insight": insight}

    cached = show_generate_chart_button("group_comparison", df, params, build_result, trigger_key="分组对比")
    if not cached:
        st.caption("调整设置后点击“生成图表”查看结果。")
        return

    result = cached["result"]
    y_column = cached["y_column"]
    with template_block("03", "图表结果", "查看当前设置生成的图表、结论和数据明细。", "green"):
        chart_df = display_chart_dataframe(result, x=group_column)
        if display_mode == "柱状图":
            fig = bar_chart(
                chart_df,
                x=group_column,
                y=y_column,
                title=f"{display_field(group_column)} 的 {display_field(value_column)} {aggregation_label(agg)}对比",
            )
        else:
            fig = pie_chart(
                chart_df,
                names=group_column,
                values=y_column,
                title=f"{display_field(group_column)} 的 {display_field(value_column)} {aggregation_label(agg)}占比",
                hole=0.45 if display_mode == "环形图" else 0,
            )
        show_plotly_chart(fig)
        chart_note("图表结论", cached["insight"])
        with st.expander("数据明细", expanded=False):
            st.dataframe(display_analysis_table(result), use_container_width=True)


def show_numeric_distribution(df, numeric_columns):
    """Show numeric histogram and box chart."""
    section("数值分布", SUBMODULE_NOTES.get("数值分布"))
    if not numeric_columns:
        st.warning("当前数据没有可计算的数值字段。建议先到清洗预处理尝试数值转换。")
        return
    show_chart_field_recommendations(
        df,
        "数值分布",
        {"value_field": numeric_columns},
        {"value_field": "chart_numeric_field"},
    )
    with template_block("02", "自定义设置", "自己选择要查看分布的数值字段；字段选择框支持搜索字段名或中文翻译。", "blue"):
        ensure_widget_value("chart_numeric_field", numeric_columns)
        column = st.selectbox("选择数值字段", numeric_columns, format_func=display_field, key="chart_numeric_field")
    params = {"column": column}

    def build_result():
        insight = numeric_distribution_insight(df, column)
        detail = df[column].describe().reset_index()
        detail.columns = ["指标", "数值"]
        add_history_event(
            "图表记录",
            "查看数值分布",
            fields=column,
            method="直方图 + 箱线图",
            result=insight,
            dedupe_key=f"chart|numeric|{column}",
        )
        return {"insight": insight, "detail": detail}

    cached = show_generate_chart_button("numeric_distribution", df, params, build_result, trigger_key="数值分布")
    if not cached:
        st.caption("调整设置后点击“生成图表”查看结果。")
        return

    with template_block("03", "图表结果", "查看直方图、箱线图、结论和数据明细。", "green"):
        show_plotly_chart(histogram(df, column, title=f"{display_field(column)} 分布"))
        show_plotly_chart(box_chart(df, column, title=f"{display_field(column)} 极端值查看"))
        chart_note("图表结论", cached["insight"])
        st.caption("箱线图可以帮助判断是否存在明显极端值；极端值不一定是错误，但可能影响平均值。")
        with st.expander("数据明细", expanded=False):
            st.dataframe(display_analysis_table(cached["detail"]), use_container_width=True)


def show_trend_visualization(df, columns, datetime_columns, numeric_columns):
    """Show time trend line chart."""
    section("趋势变化", SUBMODULE_NOTES.get("趋势变化"))
    if not numeric_columns:
        st.warning("当前数据没有数值字段，暂时无法画趋势图。")
        return
    time_options = datetime_columns or likely_time_columns(columns)
    if not time_options:
        st.warning("当前数据没有明显时间字段。建议先到清洗预处理尝试日期转换。")
        return
    show_chart_field_recommendations(
        df,
        "趋势变化",
        {"time_field": time_options, "value_field": numeric_columns},
        {"time_field": "chart_trend_time_field", "value_field": "chart_trend_value_field", "freq": "chart_trend_freq", "agg": "chart_trend_agg"},
    )
    with template_block("02", "自定义设置", "自己选择时间字段、数值字段、时间粒度和统计方式。", "blue"):
        ensure_widget_value("chart_trend_time_field", time_options)
        ensure_widget_value("chart_trend_value_field", numeric_columns)
        ensure_widget_value("chart_trend_freq", ["D", "W", "M", "Q", "Y"], "M")
        ensure_widget_value("chart_trend_agg", ["sum", "mean", "max", "min", "count"], "mean")
        time_column = st.selectbox("选择时间字段", time_options, format_func=display_field, key="chart_trend_time_field")
        value_column = st.selectbox("选择数值字段", numeric_columns, format_func=display_field, key="chart_trend_value_field")
        freq = st.selectbox("时间粒度", ["D", "W", "M", "Q", "Y"], format_func=freq_label, key="chart_trend_freq")
        agg = st.selectbox("统计方式", ["sum", "mean", "max", "min", "count"], format_func=aggregation_label, key="chart_trend_agg")
    params = {"time_column": time_column, "value_column": value_column, "freq": freq, "agg": agg}

    def build_result():
        result = trend_analysis(df, time_column, value_column, freq=freq, agg=agg)
        y_column = f"{value_column}_{agg}"
        insight = trend_insight(result, time_column, y_column, value_column, agg)
        add_history_event(
            "图表记录",
            "查看趋势变化",
            fields=f"{time_column} + {value_column}",
            method=f"{freq_label(freq)} {aggregation_label(agg)}",
            result=insight,
            dedupe_key=f"chart|trend|{time_column}|{value_column}|{freq}|{agg}",
        )
        return {"result": result, "y_column": y_column, "insight": insight}

    cached = show_generate_chart_button("trend_visualization", df, params, build_result, trigger_key="趋势变化")
    if not cached:
        st.caption("调整设置后点击“生成图表”查看结果。")
        return

    result = cached["result"]
    y_column = cached["y_column"]
    with template_block("03", "图表结果", "查看趋势图、变化结论和数据明细。", "green"):
        show_plotly_chart(line_chart(result, x=time_column, y=y_column, title=f"{display_field(value_column)} 趋势变化"))
        chart_note("图表结论", cached["insight"])
        with st.expander("数据明细", expanded=False):
            st.dataframe(display_analysis_table(result), use_container_width=True)


def show_relationship_visualization(df, numeric_columns):
    """Show scatter chart and correlation heatmap."""
    section("关系分析", SUBMODULE_NOTES.get("关系分析"))
    if len(numeric_columns) < 2:
        st.warning("关系分析至少需要两个数值字段。")
        return
    show_chart_field_recommendations(
        df,
        "关系分析",
        {"x_field": numeric_columns, "y_field": numeric_columns},
        {"x_field": "chart_relation_x_field", "y_field": "chart_relation_y_field"},
    )
    with template_block("02", "自定义设置", "自己选择两个数值字段查看它们是否一起变化。", "blue"):
        ensure_widget_value("chart_relation_x_field", numeric_columns)
        x_column = st.selectbox("选择 X 轴字段", numeric_columns, format_func=display_field, key="chart_relation_x_field")
        y_options = [column for column in numeric_columns if column != x_column] or numeric_columns
        ensure_widget_value("chart_relation_y_field", y_options)
        y_column = st.selectbox("选择 Y 轴字段", y_options, format_func=display_field, key="chart_relation_y_field")
    params = {"x_column": x_column, "y_column": y_column}

    def build_result():
        insight = relationship_insight(df, x_column, y_column)
        detail = df[[x_column, y_column]].dropna().head(100)
        add_history_event(
            "图表记录",
            "查看关系分析",
            fields=f"{x_column} + {y_column}",
            method="散点图 / 相关性",
            result=insight,
            dedupe_key=f"chart|relationship|{x_column}|{y_column}",
        )
        return {"insight": insight, "detail": detail}

    cached = show_generate_chart_button("relationship_visualization", df, params, build_result, trigger_key="关系分析")
    if not cached:
        st.caption("调整设置后点击“生成图表”查看结果。")
        return

    with template_block("03", "图表结果", "查看散点图、关系结论和数据明细。", "green"):
        show_plotly_chart(scatter_chart(df, x=x_column, y=y_column, title=f"{display_field(x_column)} 与 {display_field(y_column)} 的关系"))
        chart_note("图表结论", cached["insight"])
        st.caption("散点图只能帮助观察关系，不能直接说明因果。")
        if st.checkbox("查看相关性热力图", value=False):
            result = correlation(df)
            show_plotly_chart(heatmap(display_correlation_matrix(result), title="数值字段相关性热力图"))
        with st.expander("数据明细", expanded=False):
            st.dataframe(display_analysis_table(cached["detail"]), use_container_width=True)


def show_missing_visualization(df):
    """Show missing value bar chart."""
    section("缺失情况", SUBMODULE_NOTES.get("缺失情况"))
    with template_block("01", "自定义设置", "选择要展示缺失情况最多的前几个字段。", "blue"):
        n = st.number_input("展示前 N 个字段", min_value=1, max_value=100, value=20)
    params = {"n": int(n)}

    def build_result():
        result = missing_values(df).sort_values("missing_count", ascending=False).head(n)
        insight = missing_values_insight(result)
        add_history_event(
            "图表记录",
            "查看缺失情况",
            method=f"前 {n} 个字段缺失统计",
            result=insight,
            dedupe_key=f"chart|missing|{n}",
        )
        return {"result": result, "insight": insight}

    cached = show_generate_chart_button("missing_visualization", df, params, build_result)
    if not cached:
        st.caption("调整设置后点击“生成图表”查看结果。")
        return

    result = cached["result"]
    with template_block("02", "图表结果", "查看缺失值柱状图、结论和数据明细。", "green"):
        show_plotly_chart(bar_chart(display_chart_dataframe(result, x="column"), x="column", y="missing_count", title=f"缺失值最多的 {n} 个字段"))
        chart_note("图表结论", cached["insight"])
        with st.expander("数据明细", expanded=False):
            st.dataframe(display_analysis_table(result), use_container_width=True)


def show_cluster_analysis_panel(df, numeric_columns):
    """Show KMeans clustering as an advanced analysis task."""
    section("智能分群", SUBMODULE_NOTES.get("智能分群"))
    if len(numeric_columns) < 2:
        st.warning("智能分群至少需要两个可计算的数值字段。可以先到清洗预处理尝试数值转换。")
        return

    show_chart_field_recommendations(
        df,
        "智能分群",
        {"numeric_fields": numeric_columns},
        {"numeric_fields": "chart_cluster_fields", "n_clusters": "chart_cluster_k"},
        on_use=lambda item: run_cluster_recommendation(df, item),
    )

    with template_block("02", "自定义设置", "选择参与分群的字段、分组数量和最多参与计算的记录数。", "blue"):
        default_fields = numeric_columns[: min(4, len(numeric_columns))]
        ensure_multiselect_widget_value("chart_cluster_fields", numeric_columns, default_fields)
        ensure_widget_value("chart_cluster_k", list(range(2, 7)), 3)
        selected_fields = st.multiselect(
            "选择参与分群的数值字段",
            numeric_columns,
            format_func=display_field,
            key="chart_cluster_fields",
            help="建议选择真正描述对象特征的字段，尽量不要选择纯 ID 字段。",
        )
        n_clusters = st.slider("分成几组", min_value=2, max_value=6, key="chart_cluster_k")
        sample_size = st.slider("最多参与计算的记录数", min_value=200, max_value=3000, value=1000, step=100)

        if len(selected_fields) < 2:
            st.info("请选择至少两个数值字段后再执行分群。")
            return

        if st.button("执行智能分群", type="primary", use_container_width=True):
            result = cluster_analysis(
                df,
                selected_fields,
                n_clusters=n_clusters,
                sample_size=sample_size,
            )
            save_cluster_result_for_session(df, result, selected_fields, n_clusters)
            st.session_state["cluster_result_just_generated"] = True

    result = st.session_state.get("cluster_result")
    if not result:
        return
    should_show_result = bool(st.session_state.pop("cluster_result_just_generated", False))
    if not should_show_result:
        cols = st.columns(2)
        if cols[0].button("查看已有分群结果", use_container_width=True, key="view_existing_cluster_result"):
            should_show_result = True
        if cols[1].button("重新执行分群", type="primary", use_container_width=True, key="rerun_existing_cluster_result"):
            result = cluster_analysis(
                df,
                selected_fields,
                n_clusters=n_clusters,
                sample_size=sample_size,
            )
            save_cluster_result_for_session(df, result, selected_fields, n_clusters)
            should_show_result = True
        if not should_show_result:
            st.caption("已有上次分群结果，可以查看，也可以按当前设置重新执行。")
            return

    fields = result["columns"]
    add_history_event(
        "图表记录",
        "执行智能分群",
        fields=" + ".join(fields),
        method=f"KMeans 分为 {result['n_clusters']} 组，PCA 二维展示",
        result=f"已对 {result['sampled_rows']} 条记录生成分群结果。",
        dedupe_key=f"cluster|{'|'.join(fields)}|{result['n_clusters']}|{result['sampled_rows']}",
    )

    with template_block("03", "图表结果", "先看每组特征概括，再通过图表判断分群是否清楚。", "green"):
        st.markdown("**本次分群结果速读**")
        ai_cluster_texts, ai_cluster_status = get_cluster_ai_texts(result)
        for line in ai_cluster_texts["summary_lines"]:
            st.write(f"- {line}")
        with st.expander("查看速读依据", expanded=False):
            st.caption(ai_cluster_status)
            for line in cluster_detail_lines(result):
                st.write(f"- {line}")

        count_fig = px.bar(result["counts"], x="分群", y="记录数", text="占比_%", title="各分群记录数量")
        count_fig.update_layout(xaxis_title="分群", yaxis_title="记录数")
        show_plotly_chart(count_fig)

        point_df = result["points"].copy()
        point_df["分群"] = point_df["cluster"].astype(str)
        hover_fields = ["row_index", *fields[:5]]
        scatter_fig = px.scatter(
            point_df,
            x="pca_x",
            y="pca_y",
            color="分群",
            hover_data=hover_fields,
            title="PCA 二维分布图",
        )
        scatter_fig.update_layout(
            xaxis_title=pca_axis_label(result, "综合特征 1"),
            yaxis_title=pca_axis_label(result, "综合特征 2"),
        )
        show_plotly_chart(scatter_fig)
        show_cluster_interpretation_cards(result, ai_cluster_texts)
        show_cluster_followup_area(df, result)

        with st.expander("查看分群计算明细", expanded=False):
            st.markdown("**分群概况**")
            st.dataframe(display_analysis_table(result["profiles"]), use_container_width=True)
            st.caption("均值对比")
            st.dataframe(display_analysis_table(result["means"]), use_container_width=True)
            st.caption("中位数对比")
            st.dataframe(display_analysis_table(result["medians"]), use_container_width=True)
            pca_components = result.get("pca_components")
            if isinstance(pca_components, pd.DataFrame):
                st.caption("二维图方向依据")
                st.dataframe(display_analysis_table(pca_components.reset_index().rename(columns={"index": "综合方向"})), use_container_width=True)

        st.info("注意事项：分群结果取决于你选择的字段和分组数量，只适合探索数据结构，不能直接证明某一类更好或更差。")


def cluster_overview_lines(result):
    """Build user-facing clustering speed-read lines."""
    profiles = result["profiles"].sort_values("记录数", ascending=False)
    fields = display_field_list(result.get("columns", []), limit=6)
    lines = [
        f"系统根据 {fields}，把记录分成 {result['n_clusters']} 组。每一组代表一类在这些字段上整体特征相近的记录。",
    ]
    for _, row in profiles.head(4).iterrows():
        lines.append(cluster_group_summary_sentence(result, int(row["分群"])))
    return lines


def cluster_overview_text(result):
    """Build a short user-facing clustering conclusion for history and downloads."""
    return "；".join(cluster_overview_lines(result)[:2])


def cluster_detail_lines(result):
    """Build detailed cluster evidence lines for the expander."""
    profiles = result["profiles"].sort_values("记录数", ascending=False)
    lines = [
        f"本次共有 {result['sampled_rows']} 条可计算记录得到分群标签；模型拟合使用 {result.get('fit_rows', result['sampled_rows'])} 条记录。",
    ]
    top = profiles.iloc[0]
    lines.append(f"数量最多的是第 {int(top['分群'])} 组，共 {int(top['记录数'])} 条，占 {top['占比_%']}%。")
    for _, row in profiles.iterrows():
        lines.append(cluster_group_sentence(result, int(row["分群"])))
    return lines


def cluster_group_differences(result, cluster_id, limit=3):
    """Return the clearest high/low feature differences for one cluster."""
    points = result.get("points", pd.DataFrame())
    columns = result.get("columns", [])
    if points.empty or not columns:
        return [], []
    group_points = points[points["cluster"] == cluster_id]
    if group_points.empty:
        return [], []

    high = []
    low = []
    for column in columns:
        overall_mean = pd.to_numeric(points[column], errors="coerce").mean()
        group_mean = pd.to_numeric(group_points[column], errors="coerce").mean()
        overall_std = pd.to_numeric(points[column], errors="coerce").std()
        if pd.isna(overall_mean) or pd.isna(group_mean) or not overall_std:
            continue
        score = (group_mean - overall_mean) / overall_std
        item = {
            "field": column,
            "score": float(score),
            "group_mean": group_mean,
            "overall_mean": overall_mean,
        }
        if score >= 0.15:
            high.append(item)
        elif score <= -0.15:
            low.append(item)

    high = sorted(high, key=lambda item: abs(item["score"]), reverse=True)[:limit]
    low = sorted(low, key=lambda item: abs(item["score"]), reverse=True)[:limit]
    return high, low


def cluster_difference_phrase(items, direction):
    """Describe a list of cluster field differences in plain language."""
    if not items:
        return ""
    names = "、".join(display_field(item["field"]) for item in items)
    examples = []
    for item in items[:2]:
        examples.append(
            f"{display_field(item['field'])}约 {format_number(item['group_mean'])}，整体约 {format_number(item['overall_mean'])}"
        )
    example_text = "；".join(examples)
    return f"{names} 相对{direction}（{example_text}）"


def cluster_summary_phrase(items, direction):
    """Describe cluster differences without numeric details."""
    if not items:
        return ""
    names = "、".join(display_field(item["field"]) for item in items[:3])
    return f"{names} 相对{direction}"


def cluster_group_summary_sentence(result, cluster_id):
    """Build a concise cluster description for the main speed-read area."""
    high, low = cluster_group_differences(result, cluster_id)
    parts = [cluster_summary_phrase(high, "更高"), cluster_summary_phrase(low, "更低")]
    parts = [part for part in parts if part]
    if not parts:
        feature_text = "整体特征接近平均水平，差异不明显"
    else:
        feature_text = "，".join(parts)
    return f"第 {cluster_id} 组：{feature_text}。"


def cluster_ai_cache_key(result):
    """Build a stable cache key for AI-written cluster explanations."""
    payload = {
        "cluster_ai_text_schema": 2,
        "columns": result.get("columns", []),
        "n_clusters": result.get("n_clusters"),
        "sampled_rows": result.get("sampled_rows"),
        "profiles": result.get("profiles", pd.DataFrame()).to_dict("records")
        if isinstance(result.get("profiles"), pd.DataFrame)
        else [],
        "means": result.get("means", pd.DataFrame()).round(4).to_dict("records")
        if isinstance(result.get("means"), pd.DataFrame)
        else [],
        "pca": result.get("pca_components", pd.DataFrame()).round(4).to_dict()
        if isinstance(result.get("pca_components"), pd.DataFrame)
        else {},
    }
    return hashlib.md5(json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str).encode("utf-8")).hexdigest()


def get_cluster_ai_texts(result):
    """Return AI-enhanced cluster speed-read and PCA explanation with local fallback."""
    local = {
        "summary_lines": cluster_overview_lines(result),
        "pca_axis_1": local_pca_axis_explanation(result, "综合特征 1"),
        "pca_axis_2": local_pca_axis_explanation(result, "综合特征 2"),
    }
    cache_key = cluster_ai_cache_key(result)
    cached = result.get("ai_cluster_texts")
    if isinstance(cached, dict) and cached.get("cache_key") == cache_key:
        return cached["texts"], cached["status"]

    status = ai_status()
    if not status["can_call"]:
        return local, "生成方式：本地规则。AI 当前不可调用，速读使用本地字段差异概括。"

    ai_texts, error = generate_ai_cluster_texts(result)
    if ai_texts:
        wrapped = {
            "cache_key": cache_key,
            "texts": ai_texts,
            "status": "生成方式：AI 总结 + 本地计算依据。AI 只改写本地分群结果，不新增字段、数值或结论。",
        }
        result["ai_cluster_texts"] = wrapped
        st.session_state["cluster_result"] = result
        return wrapped["texts"], wrapped["status"]
    return local, f"生成方式：本地规则。AI 速读不可用，原因：{error or '返回内容未通过校验。'}"


def generate_ai_cluster_texts(result):
    """Ask AI to rewrite local cluster evidence into user-facing summaries."""
    evidence = cluster_ai_evidence_payload(result)
    prompt = (
        "你是 DataMind 的受控数据解释助手。请只根据输入中的本地计算结果，生成中文分群速读和 PCA 方向解释。"
        "不能新增字段、数值、因果关系、业务结论或输入中没有的信息。"
        "速读只总结每一组更像什么类型，不写下一步建议，不写记录数和占比等详细数字。"
        "每组必须一句话，必须包含一个用户能理解的类型标签，格式类似：第 1 组：更像“高评分、评论活跃的一类记录”。"
        "不要只复述“某字段较高、某字段较低”；要把字段差异概括成类型名称。"
        "如果依据不足，只能写：第 X 组：更像“特征不明显的一类记录”。"
        "PCA 解释必须分别解释 pca_axis_1 和 pca_axis_2。"
        "每个方向都要说明它主要反映什么差异；如果某方向没有明显主导字段，要明确说这个方向没有明显单一主导字段。"
        "字段如果是英文，必须保留原字段名并在后面带中文含义，例如 room_type（房型）。"
        "必须只返回 JSON，格式为："
        '{"summary_lines":["第 1 组：更像“...”"],"pca_axis_1":"...","pca_axis_2":"..."}'
        "\n\n本地计算结果："
        f"{json.dumps(evidence, ensure_ascii=False)}"
    )
    data, error = request_structured_json(prompt, cluster_ai_texts_schema(), timeout=35)
    if error or not data:
        return None, error
    normalized = normalize_ai_cluster_texts(data, result)
    if not normalized:
        return None, "AI 返回内容不完整或包含不安全内容。"
    return normalized, None


def cluster_ai_evidence_payload(result):
    """Build a compact local-evidence payload for AI cluster explanation."""
    groups = []
    profiles = result.get("profiles", pd.DataFrame())
    if isinstance(profiles, pd.DataFrame):
        for _, row in profiles.sort_values("分群").iterrows():
            cluster_id = int(row["分群"])
            high, low = cluster_group_differences(result, cluster_id)
            groups.append(
                {
                    "cluster": cluster_id,
                    "count": int(row["记录数"]),
                    "share_percent": float(row["占比_%"]),
                    "higher_fields": cluster_difference_items_for_ai(high),
                    "lower_fields": cluster_difference_items_for_ai(low),
                    "local_summary": cluster_group_summary_sentence(result, cluster_id),
                }
            )
    return {
        "selected_fields": [{"field": field, "display": display_field(field)} for field in result.get("columns", [])],
        "n_clusters": result.get("n_clusters"),
        "sampled_rows": result.get("sampled_rows"),
        "groups": groups,
        "pca_axes": {
            "综合特征 1": [{"field": field, "display": display_field(field)} for field in pca_axis_key_fields(result, "综合特征 1")],
            "综合特征 2": [{"field": field, "display": display_field(field)} for field in pca_axis_key_fields(result, "综合特征 2")],
        },
        "local_pca_explanation": {
            "综合特征 1": local_pca_axis_explanation(result, "综合特征 1"),
            "综合特征 2": local_pca_axis_explanation(result, "综合特征 2"),
        },
    }


def cluster_difference_items_for_ai(items):
    """Serialize cluster difference items for AI rewriting."""
    return [
        {
            "field": item["field"],
            "display": display_field(item["field"]),
            "group_mean": round(float(item["group_mean"]), 4),
            "overall_mean": round(float(item["overall_mean"]), 4),
        }
        for item in items
    ]


def cluster_ai_texts_schema():
    """Return expected schema for AI cluster summaries."""
    return {
        "name": "datamind_cluster_texts",
        "schema": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "summary_lines": {"type": "array", "items": {"type": "string"}},
                "pca_axis_1": {"type": "string"},
                "pca_axis_2": {"type": "string"},
            },
            "required": ["summary_lines", "pca_axis_1", "pca_axis_2"],
        },
    }


def normalize_ai_cluster_texts(data, result):
    """Validate AI cluster text output."""
    lines = data.get("summary_lines")
    pca_axis_1 = str(data.get("pca_axis_1", "")).strip()
    pca_axis_2 = str(data.get("pca_axis_2", "")).strip()
    n_clusters = int(result.get("n_clusters", 0) or 0)
    if not isinstance(lines, list) or not pca_axis_1 or not pca_axis_2:
        return None
    clean_lines = [str(line).strip() for line in lines if str(line).strip()]
    if len(clean_lines) < min(n_clusters, 2):
        return None
    allowed_fields = set(result.get("columns", []))
    combined = "\n".join(clean_lines + [pca_axis_1, pca_axis_2])
    mentioned = referenced_display_fields(pd.DataFrame(columns=list(allowed_fields)), combined)
    if any(field not in allowed_fields for field in mentioned):
        return None
    for index, line in enumerate(clean_lines[:n_clusters], start=1):
        if f"第 {index} 组" not in line and f"第{index}组" not in line:
            return None
        if "更像" not in line and "特征不明显" not in line:
            return None
    return {
        "summary_lines": clean_lines[:n_clusters],
        "pca_axis_1": pca_axis_1,
        "pca_axis_2": pca_axis_2,
    }


def cluster_group_sentence(result, cluster_id):
    """Build a natural-language description for one cluster."""
    profiles = result.get("profiles", pd.DataFrame())
    row = profiles.loc[profiles["分群"] == cluster_id]
    if row.empty:
        return f"第 {cluster_id} 组：这一组的特征暂时不明显。"
    row = row.iloc[0]
    high, low = cluster_group_differences(result, cluster_id)
    parts = [cluster_difference_phrase(high, "更高"), cluster_difference_phrase(low, "更低")]
    parts = [part for part in parts if part]
    if not parts:
        feature_text = "这一组在所选字段上接近整体平均水平，暂时没有特别突出的高低差异"
    else:
        feature_text = "；".join(parts)
    return f"第 {cluster_id} 组：共 {int(row['记录数'])} 条，占 {row['占比_%']}%。主要特征是 {feature_text}。"


def pca_axis_key_fields(result, axis_name, limit=2, min_weight=0.05):
    """Return fields that contribute most to one PCA axis."""
    components = result.get("pca_components")
    if not isinstance(components, pd.DataFrame) or axis_name not in components.index:
        return []
    row = components.loc[axis_name].abs().sort_values(ascending=False)
    fields = [
        field
        for field, weight in row.items()
        if field in result.get("columns", []) and float(weight) >= min_weight
    ]
    if not fields:
        fields = [field for field in row.head(1).index if field in result.get("columns", [])]
    return fields[:limit]


def pca_axis_label(result, axis_name):
    """Build a more readable PCA axis label."""
    fields = pca_axis_key_fields(result, axis_name, limit=2)
    if not fields:
        return axis_name
    return f"{axis_name}（主要受{display_field_list(fields)}影响）"


def local_pca_axis_explanation(result, axis_name=None):
    """Explain PCA axes with deterministic local rules."""
    if axis_name:
        fields = display_field_list(pca_axis_key_fields(result, axis_name), limit=2)
        if not fields:
            return f"{axis_name} 没有明显单一主导字段，更多反映多个所选字段的综合差异。"
        return f"{axis_name} 主要受 {fields} 影响，表示这些字段共同形成的一种综合差异。"
    axis_1 = local_pca_axis_explanation(result, "综合特征 1")
    axis_2 = local_pca_axis_explanation(result, "综合特征 2")
    return f"{axis_1} {axis_2}"


def show_cluster_interpretation_cards(result, ai_cluster_texts=None):
    """Show compact guidance for reading cluster charts."""
    pca_axis_1 = (ai_cluster_texts or {}).get("pca_axis_1") or local_pca_axis_explanation(result, "综合特征 1")
    pca_axis_2 = (ai_cluster_texts or {}).get("pca_axis_2") or local_pca_axis_explanation(result, "综合特征 2")
    cols = st.columns(3)
    with cols[0]:
        st.info("**怎么看点的位置**\n\n每个点是一条记录。点越近，说明这些记录在所选字段上的整体特征越相似。")
    with cols[1]:
        st.info("**怎么看颜色分组**\n\n同一种颜色是一组。颜色分得越开，说明不同组之间的差异越明显。")
    with cols[2]:
        st.info(f"**怎么看横轴和纵轴**\n\n{pca_axis_1}\n\n{pca_axis_2}")


def show_cluster_followup_area(df, result):
    """Explain how the generated cluster labels can be reused."""
    label_column = st.session_state.get("cluster_label_column")
    labeled_df, label_column = analysis_df_with_cluster_label(df)
    if not label_column or not isinstance(labeled_df, pd.DataFrame):
        return
    numeric_candidates = [
        column for column in analysis_numeric_columns(labeled_df, profile_table(labeled_df)["numeric_columns"])
        if column not in result.get("columns", [])
    ]
    suggested = display_field(numeric_candidates[0]) if numeric_candidates else "其他数值字段"
    chart_note(
        "下一步怎么继续分析",
        f"可以进入“分组对比”，把分组字段选为“{label_column}”，再选择 {suggested} 等指标，比较不同组之间的差异。"
        "也可以在自然语言问答中直接询问“不同智能分群在某个指标上有什么差异”。",
    )
    st.caption("分群字段会自动加入当前分析数据，不需要额外切换到新的数据版本。")


def show_text_wordcloud_panel(df, text_columns):
    """Show word frequencies and a word cloud for a text column."""
    section("文本词云", SUBMODULE_NOTES.get("文本词云"))
    if not text_columns:
        st.warning("当前数据没有明显适合做词云的文本字段。")
        return

    show_chart_field_recommendations(
        df,
        "文本词云",
        {"text_field": text_columns},
        {"text_field": "chart_text_field"},
    )
    with template_block("02", "自定义设置", "选择文本字段、展示词数、最短词长和需要额外过滤的词。", "blue"):
        ensure_widget_value("chart_text_field", text_columns)
        column = st.selectbox("选择文本字段", text_columns, format_func=display_field, key="chart_text_field")
        top_n_words = st.slider("展示高频词数量", min_value=10, max_value=100, value=50, step=5)
        min_word_length = st.slider("最短词长", min_value=2, max_value=8, value=3)
        extra_stopwords_text = st.text_input("额外过滤词", placeholder="例如：airbnb, listing, guest，用英文逗号分隔")
        extra_stopwords = [word.strip() for word in extra_stopwords_text.split(",") if word.strip()]
    params = {
        "column": column,
        "top_n_words": int(top_n_words),
        "min_word_length": int(min_word_length),
        "extra_stopwords": extra_stopwords,
    }

    def build_result():
        result = text_word_frequency(
            df,
            column,
            top_n_words=top_n_words,
            min_word_length=min_word_length,
            extra_stopwords=extra_stopwords,
        )
        frequencies = result["frequencies"]
        image = None
        if not frequencies.empty:
            wordcloud = WordCloud(
                width=1000,
                height=520,
                background_color="white",
                colormap="viridis",
                max_words=top_n_words,
            ).generate_from_frequencies(dict(zip(frequencies["word"], frequencies["count"])))
            image = wordcloud.to_array()
        insight = text_wordcloud_insight(result)
        ai_summary, ai_summary_status = generate_wordcloud_ai_summary(result)
        add_history_event(
            "图表记录",
            "查看文本词云",
            fields=column,
            method=f"词频统计 Top {top_n_words}",
            result=insight,
            dedupe_key=f"text_cloud|{column}|{top_n_words}|{min_word_length}|{','.join(extra_stopwords)}",
        )
        st.session_state["word_frequency_result"] = result
        st.session_state["word_frequency_column"] = column
        return {
            "result": result,
            "frequencies": frequencies,
            "image": image,
            "insight": insight,
            "ai_summary": ai_summary,
            "ai_summary_status": ai_summary_status,
        }

    cached = show_generate_chart_button("text_wordcloud", df, params, build_result, trigger_key="文本词云")
    if not cached:
        st.caption("调整设置后点击“生成图表”查看结果。")
        return

    result = cached["result"]
    frequencies = cached["frequencies"]
    st.session_state["word_frequency_result"] = result
    st.session_state["word_frequency_column"] = column
    if frequencies.empty:
        st.info("当前字段没有提取到足够的英文关键词。可以换一个文本字段，或降低最短词长。")
        return

    with template_block("03", "图表结果", "查看高频词柱状图、词云、结论和数据明细。", "green"):
        st.success(cached["insight"])
        chart_df = frequencies.head(20)
        show_plotly_chart(bar_chart(display_chart_dataframe(chart_df, x="word"), x="word", y="count", title=f"{display_field(column)} 高频词 Top 20"))
        if cached.get("image") is not None:
            st.image(cached["image"], use_container_width=True)
        chart_note("词云总结", cached.get("ai_summary") or cached["insight"])
        with st.expander("查看总结依据", expanded=False):
            st.write(cached.get("ai_summary_status", "本地规则总结。"))
            st.dataframe(display_analysis_table(frequencies.head(20)), use_container_width=True)

        with st.expander("数据明细", expanded=False):
            st.dataframe(display_analysis_table(frequencies), use_container_width=True)
        st.info("注意事项：当前词云主要面向英文文本。词频只能说明某些词出现得多，不能直接判断评价正负或因果关系。")


def text_wordcloud_insight(result):
    """Build a user-facing insight for text word frequency results."""
    frequencies = result["frequencies"]
    if frequencies.empty:
        return "当前文本字段没有提取到稳定高频词。"
    top_word_values = frequencies["word"].head(3).astype(str).tolist()
    prepare_value_translations("word", top_word_values)
    top_words = "、".join(display_value_label("word", word, current_value_translations()) for word in top_word_values)
    top = frequencies.iloc[0]
    top_word = display_value_label("word", top["word"], current_value_translations())
    return (
        f"{display_field(result['column'])} 中最常出现的是 “{top_word}”，出现 {int(top['count'])} 次。"
        f" 这些高频词集中在 {top_words} 等表达上，说明这列文本主要围绕这些内容展开。"
    )


def generate_wordcloud_ai_summary(result):
    """Use AI to summarize word cloud themes with local fallback."""
    local_summary = text_wordcloud_insight(result)
    frequencies = result.get("frequencies", pd.DataFrame())
    if frequencies.empty:
        return local_summary, "生成方式：本地规则。当前没有足够高频词可供 AI 总结。"
    if not ai_status()["can_call"]:
        return local_summary, "生成方式：本地规则。AI 当前不可调用。"

    word_values = frequencies["word"].head(25).astype(str).tolist()
    prepare_value_translations("word", word_values)
    top_words = [
        {
            "word": str(row["word"]),
            "word_display": display_value_label("word", row["word"], current_value_translations()),
            "count": int(row["count"]),
            "share_%": float(row.get("share_%", 0)),
        }
        for _, row in frequencies.head(25).iterrows()
    ]
    payload = {
        "field": result.get("column"),
        "field_display": display_field(result.get("column")),
        "non_empty_rows": result.get("non_empty_rows"),
        "unique_words": result.get("unique_words"),
        "top_words": top_words,
    }
    prompt = (
        "你是 DataMind 的文本词云解释助手。请只根据输入中的高频词和次数，写一段中文总结。"
        "不要编造情感正负、因果关系、用户评价或字段中没有的信息。"
        "总结要面向普通用户，说明这些高频词大致反映了哪些主题或描述重点。"
        "不要罗列很多词或字段名，最多点到 2-3 个代表性词语。"
        "如果总结中提到英文高频词，必须使用输入里的 word_display 形式，也就是“英文词（中文）”；不要只写英文词，也不要只翻译其中一部分。"
        "最后一句要直接说明这列文本主要在讲什么，不要使用“文本主题速览”“可作为起点”“高频词统计”等内部化表述。"
        "如果高频词较分散，请用自然语言说“这些文字内容比较分散，暂时没有特别集中的主题”。"
        "只返回 JSON，格式为：{\"summary\":\"...\"}。\n\n"
        f"词云结果：{json.dumps(payload, ensure_ascii=False)}"
    )
    data, error = request_structured_json(prompt, wordcloud_ai_summary_schema(), timeout=25)
    summary = str((data or {}).get("summary", "")).strip() if isinstance(data, dict) else ""
    if error or not summary:
        return local_summary, f"生成方式：本地规则。AI 总结不可用，原因：{error or 'AI 未返回有效总结。'}"
    summary = display_text_with_values(summary, "word", word_values)
    return summary, "生成方式：AI 总结 + 本地词频统计。AI 只改写高频词主题，不新增数据事实。"


def wordcloud_ai_summary_schema():
    """Return expected schema for AI word cloud summary."""
    return {
        "name": "datamind_wordcloud_summary",
        "schema": {
            "type": "object",
            "additionalProperties": False,
            "properties": {"summary": {"type": "string"}},
            "required": ["summary"],
        },
    }


def chart_note(title, text):
    """Render a short user-facing chart explanation."""
    st.info(f"**{title}：** {text}")


def format_number(value):
    """Format a number for short user-facing insights."""
    if pd.isna(value):
        return "未知"
    if abs(float(value)) >= 100:
        return f"{float(value):,.0f}"
    return f"{float(value):,.2f}".rstrip("0").rstrip(".")


def category_distribution_insight(result, column, display_mode="柱状图"):
    """Summarize the leading category in a frequency chart."""
    if result.empty:
        return "当前字段没有可用于统计的类别。"
    total = float(result["count"].sum())
    top_row = result.iloc[0]
    share = float(top_row["count"]) / total * 100 if total else 0
    top_value = display_value(column, top_row[column])
    if display_mode in {"饼图", "环形图"}:
        return f"{display_field(column)} 的占比结构中，“{top_value}”占比最高，约为 {share:.1f}%。如果这个比例明显高于其他类别，说明当前数据更集中在这一类。"
    return f"{display_field(column)} 中出现最多的是“{top_value}”，占当前展示结果的 {share:.1f}%。如果占比很高，说明数据主要集中在这个类别。"


def group_comparison_insight(result, group_column, y_column, value_column, agg, display_mode="柱状图"):
    """Summarize highest and lowest groups."""
    if result.empty or y_column not in result:
        return "当前组合没有生成可比较的分组结果。"
    ranked = result.dropna(subset=[y_column]).sort_values(y_column, ascending=False)
    if ranked.empty:
        return "当前分组结果为空，建议更换字段或统计方式。"
    top_row = ranked.iloc[0]
    bottom_row = ranked.iloc[-1]
    label = aggregation_label(agg)
    top_value = display_value(group_column, top_row[group_column])
    bottom_value = display_value(group_column, bottom_row[group_column])
    if display_mode in {"饼图", "环形图"} and agg in {"sum", "count"}:
        total = float(ranked[y_column].sum())
        share = float(top_row[y_column]) / total * 100 if total else 0
        return (
            f"在当前展示的分组中，“{top_value}”的 {display_field(value_column)}{label}占比最高，约为 {share:.1f}%。"
            f"这说明它是当前结果里贡献最大的组。"
        )
    return (
        f"{display_field(group_column)} 中“{top_value}”的 {display_field(value_column)}{label}最高，"
        f"为 {format_number(top_row[y_column])}；“{bottom_value}”最低，为 {format_number(bottom_row[y_column])}。"
    )


def numeric_distribution_insight(df, column):
    """Summarize numeric center and spread."""
    series = pd.to_numeric(df[column], errors="coerce").dropna()
    if series.empty:
        return "当前字段没有可用于计算的数值。"
    q1 = series.quantile(0.25)
    median = series.median()
    q3 = series.quantile(0.75)
    return (
        f"{display_field(column)} 的中位数约为 {format_number(median)}，中间一半的数据大致落在 "
        f"{format_number(q1)} 到 {format_number(q3)} 之间。若箱线图两端点很多，后续分析平均值时要更谨慎。"
    )


def trend_insight(result, time_column, y_column, value_column, agg):
    """Summarize the first-to-last movement in a trend chart."""
    if result.empty or y_column not in result:
        return "当前趋势结果为空，建议更换时间字段、数值字段或时间粒度。"
    clean = result.dropna(subset=[y_column]).sort_values(time_column)
    if len(clean) < 2:
        return "当前时间点不足，暂时无法判断变化方向。"
    first = clean.iloc[0][y_column]
    last = clean.iloc[-1][y_column]
    direction = "上升" if last > first else "下降" if last < first else "基本持平"
    return (
        f"从首个时间点到最后一个时间点，{display_field(value_column)} 的{aggregation_label(agg)}整体呈{direction}趋势，"
        f"从 {format_number(first)} 变化到 {format_number(last)}。"
    )


def relationship_insight(df, x_column, y_column):
    """Summarize correlation strength between two numeric columns."""
    pair = df[[x_column, y_column]].apply(pd.to_numeric, errors="coerce").dropna()
    if len(pair) < 2:
        return "可用于比较的记录太少，暂时无法判断关系强弱。"
    corr_value = pair[x_column].corr(pair[y_column])
    if pd.isna(corr_value):
        return "这两个字段暂时没有稳定的相关性结果。"
    strength = "较强" if abs(corr_value) >= 0.6 else "中等" if abs(corr_value) >= 0.3 else "较弱"
    direction = "正向" if corr_value > 0 else "反向" if corr_value < 0 else "不明显"
    return f"{display_field(x_column)} 与 {display_field(y_column)} 的相关性约为 {corr_value:.2f}，属于{strength}{direction}关系。注意相关不等于因果。"


def missing_values_insight(result):
    """Summarize the most missing field."""
    nonzero = result[result["missing_count"] > 0]
    if nonzero.empty:
        return "当前展示的字段没有缺失值，数据完整性较好。"
    top_row = nonzero.iloc[0]
    return (
        f"缺失最多的字段是“{display_field(top_row['column'])}”，缺失 {int(top_row['missing_count'])} 条，"
        f"缺失率 {top_row['missing_rate_%']}%。后续使用这个字段前，建议先确认缺失是否会影响结论。"
    )


def aggregation_label(agg):
    """Translate aggregation names for users."""
    return {"sum": "总和", "mean": "平均值", "max": "最大值", "min": "最小值", "count": "数量"}.get(agg, agg)


def freq_label(freq):
    """Translate time frequency labels."""
    return {"D": "按天", "W": "按周", "M": "按月", "Q": "按季度", "Y": "按年"}.get(freq, freq)


def likely_time_columns(columns):
    """Find columns that look like time fields by name."""
    keywords = ["date", "time", "year", "month", "day", "日期", "时间", "年份", "月份"]
    return [column for column in columns if any(keyword in str(column).lower() for keyword in keywords)]


def show_qa_panel(df, submodule="提问向导"):
    """Render controlled natural-language QA."""
    if submodule not in QA_SUBMODULES:
        submodule = "提问向导"

    section(submodule, SUBMODULE_NOTES.get(submodule))

    pending_question = st.session_state.get("pending_qa_question")
    pending_instruction = st.session_state.get("pending_qa_instruction")
    if pending_question:
        st.session_state["qa_question_input"] = pending_question

    if submodule == "提问向导":
        with template_block("01", "推荐问题", "根据当前数据字段、缺失情况和可执行 Skill 推荐更适合先问的问题。", "teal"):
            recommended, recommend_status = get_cached_question_recommendations_if_ready(df)
            if recommended is None:
                st.caption("点击后为当前数据生成一组推荐问题。")
                if st.button("生成推荐问题", key="generate_qa_recommendations", use_container_width=True):
                    get_cached_question_recommendations(df)
                    st.rerun()
                return
            if debug_mode_enabled():
                st.caption("调试日志：outputs/debug_qa.log")
            if recommended.empty:
                st.info("当前数据暂时没有可推荐的问题，可以去“自由提问”输入基础问题。")
            else:
                for index, row in recommended.iterrows():
                    with st.container(border=True):
                        debug_qa_log(
                            "render_recommendation",
                            index=int(index),
                            question=str(row.get("question", "")),
                            instruction_type=type(row.get("instruction")).__name__,
                            instruction=coerce_instruction(row.get("instruction")),
                        )
                        st.markdown(f"**{row['question']}**")
                        st.write(row["reason"])
                        show_debug_instruction("调试：推荐问题携带的 Skill 指令", row.get("instruction"))
                        if st.button("开始分析", key=f"qa_recommend_{index}", use_container_width=True):
                            st.session_state["pending_qa_question"] = row["question"]
                            instruction = coerce_instruction(row.get("instruction"))
                            debug_qa_log(
                                "click_recommendation_before_save",
                                index=int(index),
                                question=str(row.get("question", "")),
                                raw_instruction_type=type(row.get("instruction")).__name__,
                                coerced_instruction=instruction,
                            )
                            if instruction:
                                st.session_state["pending_qa_instruction"] = json.dumps(instruction, ensure_ascii=False)
                            debug_qa_log(
                                "click_recommendation_after_save",
                                has_pending_question=bool(st.session_state.get("pending_qa_question")),
                                has_pending_instruction=bool(st.session_state.get("pending_qa_instruction")),
                                pending_instruction=st.session_state.get("pending_qa_instruction"),
                            )
                            st.session_state["pending_qa_submodule"] = "自由提问"
                            st.rerun()
        show_qa_recommendation_basis(recommend_status, recommended)
        return

    if submodule == "自由提问":
        debug_qa_log(
            "enter_free_question",
            pending_question=pending_question,
            raw_pending_instruction_type=type(pending_instruction).__name__,
            raw_pending_instruction=pending_instruction,
            session_has_pending_instruction=bool(st.session_state.get("pending_qa_instruction")),
        )
        with template_block("01", "输入问题", "用普通语言描述你想知道什么，系统会先解析再执行安全的本地分析。", "blue"):
            question = st.text_input("输入你的数据问题", key="qa_question_input", placeholder=qa_question_placeholder(df))
            pending_instruction = coerce_instruction(pending_instruction)
            if pending_instruction:
                show_debug_instruction("调试：待执行的推荐 Skill 指令", pending_instruction)
            elif st.session_state.get("pending_qa_question"):
                if debug_mode_enabled():
                    st.warning("调试：已接收到推荐问题文本，但没有接收到对应的 Skill 指令。")
            if pending_instruction and question.strip():
                debug_qa_log("execute_pending_instruction", question=question, instruction=pending_instruction)
                response = run_controlled_query(df, pending_instruction)
                st.session_state["last_qa_question"] = question
                st.session_state["last_qa_response"] = response
                st.session_state["last_qa_execution_source"] = "推荐问题携带的 Skill 指令"
                st.session_state.pop("pending_qa_question", None)
                st.session_state.pop("pending_qa_instruction", None)
                debug_qa_log(
                    "execute_pending_instruction_result",
                    ok=response.get("ok"),
                    intent=response.get("intent"),
                    validation=response.get("validation"),
                    instruction=response.get("instruction"),
                    error=response.get("error"),
                )
                add_history_event(
                    "问答记录",
                    question,
                    fields=qa_instruction_fields(response.get("instruction", {})),
                    method=response.get("intent", "unsupported"),
                    result=qa_history_result(response),
                    dedupe_key=f"qa|recommended|{question}|{response.get('intent')}",
                )
            if st.button("提交问题", use_container_width=True) and question.strip():
                response = answer_question(df, question)
                st.session_state["last_qa_question"] = question
                st.session_state["last_qa_response"] = response
                st.session_state["last_qa_execution_source"] = "自由输入后本地解析"
                add_history_event(
                    "问答记录",
                    question,
                    fields=qa_instruction_fields(response.get("instruction", {})),
                    method=response.get("intent", "unsupported"),
                    result=qa_history_result(response),
                    dedupe_key=f"qa|{question}|{response.get('intent')}",
                )

        with st.expander("查看可问范围", expanded=False):
            st.write("可以询问行数、缺失情况、字段概况、数值摘要、Top N、分组统计、相关性、趋势、异常值、重复记录等问题。")
            st.write("系统会先理解问题，再用本地白名单函数执行分析；暂不直接执行 AI 生成的代码。")
            st.dataframe(supported_qa_types(), use_container_width=True)

        response = st.session_state.get("last_qa_response")
        if response:
            show_debug_instruction("调试：实际执行的 Skill 指令", response.get("instruction"))
            with template_block("03", "回答结果", "先看结论，再看图表或表格；计算依据默认折叠。", "green"):
                render_qa_response(response)
        return


def show_qa_recommendation_basis(recommend_status, recommended):
    """Show QA recommendation source details without crowding cards."""
    with st.expander("查看推荐依据", expanded=False):
        if recommend_status.get("used_ai"):
            st.write("生成方式：AI 推荐 + 本地校验")
        elif recommend_status.get("fallback"):
            st.write("生成方式：本地规则兜底")
            st.write(f"兜底原因：{recommend_status.get('message', 'AI 推荐暂不可用。')}")
        else:
            st.write("生成方式：本地规则")
        st.write("输入依据：当前数据字段、字段类型、缺失比例、字段含义和可执行的问答 Skill。")
        st.write("本地校验：检查字段是否存在、是否高缺失、问题是否能由白名单 Skill 执行。")
        st.write("推荐目标：问题应尽量多样、有意义，覆盖不同字段和不同分析方法。")
        if recommended is not None and not recommended.empty:
            compact = recommended[["question", "method", "priority", "source"]].copy()
            compact.columns = ["推荐问题", "问题类型", "推荐等级", "来源"]
            st.dataframe(compact, use_container_width=True, hide_index=True)


def render_qa_response(response):
    """Render a QA response in user-facing language."""
    if not response["ok"]:
        st.warning(display_text_with_fields(response["error"]))
        with st.expander("查看无法回答的原因和支持范围", expanded=False):
            if response.get("parse_source"):
                st.write(f"本次解析：{response['parse_source']}")
            if response.get("validation"):
                st.write(f"校验结果：{display_text_with_fields(response['validation'])}")
            st.dataframe(supported_qa_types(), use_container_width=True)
        return

    summary = response.get("summary")
    if summary:
        render_qa_summary(summary)
    else:
        render_qa_summary(
            {
                "结论": response["answer"],
                "主要结果": qa_result_insight(response),
                "解释": "系统已根据当前问题调用可执行的本地分析函数。",
                "提醒": "结果用于探索和辅助判断，正式写结论前建议结合数据质量和样本情况一起说明。",
            }
        )

    result = response["result"]
    intent = response["intent"]
    instruction = response["instruction"]

    if intent == "count_rows":
        st.metric("总行数", result["row_count"])
    elif intent == "missing_values":
        show_result_table_and_chart(result, "bar", "column", "missing_count", "各字段缺失值数量")
    elif intent == "column_profile":
        cols = st.columns(4)
        cols[0].metric("有效记录", result["non_null_count"])
        cols[1].metric("缺失率", f"{result['missing_rate_%']}%")
        cols[2].metric("不同取值", result["unique_count"])
        cols[3].metric("字段类型", result["dtype"])
        if not result["top_values"].empty:
            show_result_table_and_chart(result["top_values"], "bar", instruction["column"], "count", "常见取值")
    elif intent == "numeric_summary":
        summary_df = pd.DataFrame([result]).drop(columns=["column"], errors="ignore")
        show_detail_table(summary_df)
    elif intent == "groupby_count":
        show_result_table_and_chart(
            result,
            "bar",
            instruction["group_column"],
            "count",
            f"{display_field(instruction['group_column'])} 数量分布",
        )
    elif intent == "top_n":
        show_result_table_and_chart(
            result,
            "bar",
            instruction["column"],
            "count",
            f"{display_field(instruction['column'])} Top {instruction.get('n', 10)} 频次",
        )
    elif intent == "groupby_sum":
        y_column = f"{instruction['value_column']}_sum"
        show_result_table_and_chart(
            result,
            "bar",
            instruction["group_column"],
            y_column,
            f"不同 {display_field(instruction['group_column'])} 的 {display_field(instruction['value_column'])} 总和对比",
        )
    elif intent == "groupby_agg":
        y_column = f"{instruction['value_column']}_{instruction.get('agg', 'mean')}"
        show_result_table_and_chart(
            result,
            "bar",
            instruction["group_column"],
            y_column,
            f"不同 {display_field(instruction['group_column'])} 的 {display_field(instruction['value_column'])} {aggregation_label(instruction.get('agg', 'mean'))}对比",
        )
    elif intent == "correlation":
        show_result_table_and_chart(result, "heatmap", title="相关性热力图")
    elif intent == "trend_analysis":
        y_column = f"{instruction['value_column']}_{instruction.get('agg', 'sum')}"
        show_result_table_and_chart(
            result,
            "line",
            instruction["time_column"],
            y_column,
            f"{display_field(instruction['value_column'])} 随 {display_field(instruction['time_column'])} 的变化",
        )
    elif intent == "outlier_detection":
        cols = st.columns(3)
        cols[0].metric("异常记录", result["outlier_count"])
        cols[1].metric("异常占比", f"{result['outlier_rate_%']}%")
        cols[2].metric("合理范围", f"{result['lower_bound']} - {result['upper_bound']}")
        if not result["outliers"].empty:
            show_detail_table(result["outliers"], "查看异常记录")
    elif intent == "duplicate_rows":
        cols = st.columns(2)
        cols[0].metric("重复记录", result["duplicate_count"])
        cols[1].metric("重复占比", f"{result['duplicate_rate_%']}%")
        if not result["examples"].empty:
            show_detail_table(result["examples"], "查看重复记录示例")
    elif intent == "top_records":
        show_detail_table(result)
    elif intent == "multi_skill":
        show_multi_skill_results(result)
    elif intent == "analysis_route":
        for step in result:
            st.write(f"- {qa_display_text(step)}")

    with st.expander("查看计算依据", expanded=False):
        st.write("系统会先把问题转成结构化 Skill 指令，校验字段和参数后，只调用白名单本地分析函数。")
        st.write(f"执行来源：{st.session_state.get('last_qa_execution_source', '未知')}")
        st.caption(f"Skill：{response.get('skill_name', skill_display_name(response['intent']))}")
        st.caption(f"使用字段：{qa_instruction_fields(response.get('instruction', {}))}")
        st.caption(f"校验结果：{qa_display_text(response.get('validation', '已通过'))}")
        if response.get("parse_source"):
            st.caption(f"本次解析：{response['parse_source']}")
        if response.get("instruction"):
            st.caption("本次结构化指令")
            st.json(response["instruction"])


def render_qa_summary(summary):
    """Render the main QA answer with one consistent visual grammar."""
    st.success(qa_display_text(summary["结论"]))
    st.markdown(f"**主要结果：** {qa_display_text(summary['主要结果'])}")
    st.markdown(f"**怎么理解：** {qa_display_text(summary['解释'])}")
    st.markdown(f"**注意事项：** {qa_display_text(summary['提醒'])}")


def qa_display_text(text):
    """Apply field translations to QA user-facing text."""
    return display_text_with_fields(str(text))


def conclusion_display_text(text):
    """Apply field translations to conclusion-checker user-facing text."""
    return display_text_with_fields(str(text))


def qa_instruction_fields(instruction):
    """Return a compact field description from a QA instruction."""
    if not instruction:
        return "-"
    fields = []
    for key in ["column", "group_column", "value_column", "time_column"]:
        if instruction.get(key):
            fields.append(display_field(instruction[key]))
    return " + ".join(fields) if fields else "-"


def show_multi_skill_results(results):
    """Render successful parts of a multi-skill response."""
    for index, item in enumerate(results, start=1):
        with st.expander(f"步骤 {index}：{item.get('skill_name', item.get('intent', '分析步骤'))}", expanded=index == 1):
            if not item.get("ok"):
                st.warning(qa_display_text(item.get("validation") or item.get("error") or "该步骤未能执行。"))
                continue
            st.write(qa_display_text(item.get("summary", {}).get("结论", item.get("answer", "已完成。"))))
            result = item.get("result")
            if isinstance(result, pd.DataFrame):
                st.dataframe(display_analysis_table(result), use_container_width=True)


def qa_history_result(response):
    """Return a short QA history result."""
    if not response.get("ok"):
        return response.get("error", "未能识别该问题。")
    return qa_result_insight(response)


def qa_result_insight(response):
    """Build a concise insight for a controlled QA result."""
    intent = response["intent"]
    result = response["result"]
    instruction = response["instruction"]
    if intent == "count_rows":
        return f"这份数据当前包含 {result['row_count']} 条记录，可以作为后续分析的样本规模参考。"
    if intent == "missing_values":
        return missing_values_insight(result.sort_values("missing_count", ascending=False))
    if intent == "column_profile":
        return f"{display_field(instruction['column'])} 有 {result['unique_count']} 个不同取值，缺失率为 {result['missing_rate_%']}%。"
    if intent == "numeric_summary":
        return f"{display_field(instruction['column'])} 的中位数约为 {result['median']}，平均值约为 {result['mean']}。"
    if intent == "top_n":
        return category_distribution_insight(result, instruction["column"])
    if intent == "groupby_count":
        return category_distribution_insight(result, instruction["group_column"])
    if intent == "groupby_sum":
        y_column = f"{instruction['value_column']}_sum"
        return group_comparison_insight(result, instruction["group_column"], y_column, instruction["value_column"], "sum")
    if intent == "groupby_agg":
        agg = instruction.get("agg", "mean")
        y_column = f"{instruction['value_column']}_{agg}"
        return group_comparison_insight(result, instruction["group_column"], y_column, instruction["value_column"], agg)
    if intent == "trend_analysis":
        agg = instruction.get("agg", "sum")
        y_column = f"{instruction['value_column']}_{agg}"
        return trend_insight(result, instruction["time_column"], y_column, instruction["value_column"], agg)
    if intent == "correlation":
        return "热力图中颜色越深通常代表相关性越强，但相关关系不能直接解释为因果关系。"
    if intent == "outlier_detection":
        return f"{result['column']} 中发现 {result['outlier_count']} 条可能的异常记录。"
    if intent == "duplicate_rows":
        return f"当前发现 {result['duplicate_count']} 条重复记录。"
    if intent == "top_records":
        return f"已按 {instruction['sort_column']} 返回前 {len(result)} 条记录。"
    return "已完成该问题对应的受控分析。"


def supported_qa_types():
    """Return user-facing supported QA capabilities."""
    return list_skills()


def show_report_panel(raw_df, submodule="生成报告"):
    """Render report output and writing support."""
    if submodule not in REPORT_SUBMODULES:
        submodule = "生成报告"

    analysis_df, source_name = get_analysis_df(raw_df)
    if submodule == "生成报告":
        show_report_generator(analysis_df, source_name)
    elif submodule == "结论检查":
        show_conclusion_checker_panel(analysis_df, source_name)


def show_report_generator(analysis_df, source_name):
    """Render a local-rule Markdown report generator."""
    section("生成报告", SUBMODULE_NOTES.get("生成报告"))
    status = ai_status()
    with template_block("01", "报告设置", "先选择报告详细程度，再决定是否让 AI 只负责整理和润色文字。", "blue"):
        report_type = st.radio(
            "选择报告类型",
            ["简洁报告", "完整报告", "答辩/附录版"],
            horizontal=True,
            help="报告类型只影响详细程度和是否包含附录，不替你选择主要结论。",
        )
        use_ai_report = st.checkbox(
            "使用 AI 整理和润色报告",
            value=status["can_call"],
            disabled=not status["can_call"],
            help="AI 只基于已选素材生成报告语言；不可用时自动使用本地模板。",
        )
        show_report_ai_notice(status)

    with template_block("02", "选择写入报告的内容", "默认信息自动写入；主要分析结果由你从历史图表和问答中选择。", "teal"):
        selected_materials = show_report_material_selector(analysis_df, source_name, report_type)

    report_params = {
        "source_name": source_name,
        "report_type": report_type,
        "use_ai": bool(use_ai_report),
        "materials": selected_materials,
    }
    report_cache_key = ("report", dataframe_signature(analysis_df), json.dumps(report_params, ensure_ascii=False, sort_keys=True, default=str))
    report_cache = st.session_state.setdefault("report_result_cache", {})

    with template_block("03", "生成与下载", "生成报告后，可以在下方预览或下载。", "slate"):
        if st.button("生成报告", type="primary", use_container_width=True):
            add_history_event(
                "导出记录",
                "生成 Markdown 分析报告",
                data_source=source_name,
                method="AI 受控写作 + 本地兜底" if use_ai_report else "本地规则报告生成",
                result=f"已生成{report_type}，可预览或下载。",
                dedupe_key=f"report|{source_name}|{report_type}",
            )
            report_text, report_status = build_markdown_report(
                analysis_df,
                source_name,
                report_type=report_type,
                selected_materials=selected_materials,
                use_ai=use_ai_report,
                return_status=True,
            )
            report_cache[report_cache_key] = {"text": report_text, "status": report_status, "materials": selected_materials}
            st.session_state["report_result_cache"] = report_cache
            st.rerun()

        cached_report = report_cache.get(report_cache_key)
        if not cached_report:
            st.caption("设置完成后点击“生成报告”。")
            return

        report_text = cached_report["text"]
        report_status = cached_report["status"]
        download_cols = st.columns(3)
        download_cols[0].download_button(
            "下载 Markdown 报告",
            report_text.encode("utf-8-sig"),
            file_name="datamind_analysis_report.md",
            mime="text/markdown",
            use_container_width=True,
        )
        html_report = markdown_report_to_html(report_text, title="DataMind 数据分析报告")
        download_cols[1].download_button(
            "下载 HTML 报告",
            html_report.encode("utf-8-sig"),
            file_name="datamind_analysis_report.html",
            mime="text/html",
            use_container_width=True,
        )
        pdf_report = markdown_report_to_pdf(report_text, title="DataMind 数据分析报告")
        download_cols[2].download_button(
            "下载 PDF 报告",
            pdf_report,
            file_name="datamind_analysis_report.pdf",
            mime="application/pdf",
            use_container_width=True,
        )

    show_report_generation_basis(report_status, selected_materials)

    with template_block("04", "报告预览", "查看当前生成的完整报告内容。", "green"):
        with st.expander("报告预览", expanded=True):
            st.markdown(report_text)


def show_report_ai_notice(status):
    """Show report AI capability in one collapsed user-facing block."""
    with st.expander("AI 使用说明", expanded=False):
        st.write(f"当前状态：{status['state']}")
        if status["can_call"]:
            st.write("AI 可用于整理和润色你已选择的报告素材。")
        else:
            st.write("AI 当前不可调用，本次会使用本地规则报告模板。")
        st.write("AI 不替你选择结论，不新增数据事实，也不会执行 AI 生成代码。")
        st.write("报告结构、素材选择和安全校验仍由本地程序控制。")


def show_report_generation_basis(report_status, selected_materials):
    """Show how the report text was generated."""
    with st.expander("查看生成依据", expanded=False):
        st.write(f"生成方式：{report_status.get('source', '本地规则报告生成')}")
        if report_status.get("fallback"):
            st.write(f"兜底原因：{report_status.get('message', 'AI 未返回可用内容。')}")
        st.write("输入依据：数据说明、数据质量规则、用户选择的图表素材、用户选择的问答素材，以及是否包含附录。")
        st.write("本地校验：AI 只能基于已选素材改写报告文字，不允许新增字段、数值或结论；报告结构仍由本地代码控制。")
        st.write(f"已选图表素材：{len(selected_materials.get('charts', []))} 条")
        st.write(f"已选问答素材：{len(selected_materials.get('qa', []))} 条")


def show_report_material_selector(df, source_name, report_type):
    """Let users choose which evidence enters the generated report."""
    materials = build_report_candidate_materials(df, source_name)

    default_cols = st.columns(2)
    include_background = default_cols[0].checkbox(
        "数据说明",
        value=True,
        help="包含数据来源、样本规模、数据对象和主要信息维度。",
    )
    include_quality = default_cols[1].checkbox(
        "数据处理与质量",
        value=True,
        help="包含清洗状态、缺失、重复和极端值对分析的影响。",
    )

    st.markdown("**主要分析结果**")
    st.caption("这里的素材来自你之前做过的图表分析和自然语言问答记录，会进入报告的“主要分析结果”。只选择你认为真正重要、值得写进报告的内容。")
    selected_charts = material_multiselect(
        "图表分析素材",
        materials["charts"],
        default_count=0,
        key="report_selected_charts",
    )
    selected_qa = material_multiselect(
        "问答分析素材",
        materials["qa"],
        default_count=0,
        key="report_selected_qa",
    )

    st.markdown("**附录**")
    include_appendix = st.checkbox(
        "包含清洗日志、问答记录和分析记录",
        value=report_type == "答辩/附录版",
        help="简洁报告通常不需要附录；答辩或需要说明分析过程时建议包含。",
    )

    with st.expander("查看已选素材摘要", expanded=False):
        st.write(f"数据说明：{'包含' if include_background else '不包含'}")
        st.write(f"数据处理与质量：{'包含' if include_quality else '不包含'}")
        st.write(f"图表分析：{len(selected_charts)} 条")
        st.write(f"问答分析：{len(selected_qa)} 条")
        st.write(f"附录：{'包含' if include_appendix else '不包含'}")

    return {
        "include_background": include_background,
        "include_quality": include_quality,
        "include_appendix": include_appendix,
        "findings": [],
        "charts": selected_charts,
        "qa": selected_qa,
    }


def material_multiselect(title, items, default_count=0, key=None):
    """Render a stable material selector and return selected material dicts."""
    with st.container(border=True):
        st.markdown(f"**{title}**")
        if not items:
            st.caption("当前还没有可选择的素材。")
            return []
        item_map = {item["id"]: item for item in items}
        default_ids = [item["id"] for item in items[:default_count]]
        selected_ids = st.multiselect(
            "选择要写入报告的内容",
            options=list(item_map),
            default=default_ids,
            format_func=lambda item_id: item_map[item_id]["label"],
            key=key,
            label_visibility="collapsed",
        )
        if selected_ids:
            st.caption(f"已选择 {len(selected_ids)} 条。")
        return [item_map[item_id] for item_id in selected_ids]


def build_report_candidate_materials(df, source_name):
    """Collect report materials from verified local outputs and history."""
    charts = history_materials("图表记录", "chart")
    qa_items = history_materials("问答记录", "qa")
    return {
        "source_name": source_name,
        "charts": charts,
        "qa": qa_items,
    }


def history_materials(event_type, prefix, limit=8):
    """Convert analysis history rows into report candidate materials."""
    history = history_dataframe(event_type)
    if history.empty:
        return []
    rows = history.tail(limit).to_dict("records")
    materials = []
    for index, row in enumerate(rows, start=1):
        action = str(row.get("操作内容", "")).strip() or event_type
        result = str(row.get("结果摘要", "")).strip() or "已完成相关分析。"
        fields = str(row.get("字段/对象", "")).strip()
        method = str(row.get("方法", "")).strip()
        label = f"{action}：{result}"
        detail_bits = []
        if fields and fields != "-":
            detail_bits.append(f"使用字段：{fields}")
        if method and method != "-":
            detail_bits.append(f"方法：{method}")
        detail = "；".join(detail_bits) if detail_bits else "来源于分析历史记录。"
        materials.append(
            {
                "id": f"{prefix}_{index}_{row.get('时间', '')}",
                "label": label,
                "preview": detail,
                "text": result,
                "detail": detail,
            }
        )
    return materials

def show_conclusion_checker_panel(df, source_name):
    """Check whether a report conclusion is supported by current data."""
    section("结论检查", SUBMODULE_NOTES.get("结论检查"))
    status = ai_status()
    with template_block("01", "输入结论", "输入准备写进报告的一句话，系统会检查它能否被当前数据支持。", "blue"):
        example = conclusion_placeholder(df)
        conclusion = st.text_area(
            "输入你的结论",
            placeholder=example,
            height=100,
        )
    if not conclusion:
        st.caption("可以输入你准备写进报告的一句判断，系统会根据当前数据检查它是否有依据。")
        return

    conclusion_cache_key = ("conclusion", dataframe_signature(df), source_name, conclusion)
    conclusion_cache = st.session_state.setdefault("conclusion_check_cache", {})
    if st.button("检查结论", type="primary", use_container_width=True):
        conclusion_cache.pop(conclusion_cache_key, None)
        st.session_state["conclusion_check_cache"] = conclusion_cache
    elif conclusion_cache_key not in conclusion_cache:
        st.caption("输入结论后点击“检查结论”。")
        return

    if conclusion_cache_key not in conclusion_cache:
        ai_parse, parse_status = parse_conclusion_with_ai(df, conclusion)
        candidate_fields, field_validation = conclusion_candidate_fields(df, conclusion, ai_parse)
        result = check_conclusion_support(df, conclusion, candidate_fields=candidate_fields)
        ai_review, review_status = polish_conclusion_review_with_ai(conclusion, result, field_validation, parse_status)
        if ai_review.get("suggestion"):
            result["suggestion"] = ai_review["suggestion"]
        if ai_review.get("explanation"):
            result["ai_explanation"] = ai_review["explanation"]
        add_history_event(
            "导出记录",
            "检查报告结论",
            data_source=source_name,
            fields=" + ".join(map(str, result["fields"])) if result["fields"] else "-",
            method="AI 解析 + 本地规则结论检查" if parse_status["used_ai"] else "本地规则结论支持性检查",
            result=f"支持程度：{result['support']}",
            dedupe_key=f"conclusion|{source_name}|{conclusion}",
        )
        conclusion_cache[conclusion_cache_key] = {
            "result": result,
            "parse_status": parse_status,
            "review_status": review_status,
            "field_validation": field_validation,
        }
        st.session_state["conclusion_check_cache"] = conclusion_cache

    cached_conclusion = conclusion_cache[conclusion_cache_key]
    result = cached_conclusion["result"]
    parse_status = cached_conclusion["parse_status"]
    review_status = cached_conclusion["review_status"]
    field_validation = cached_conclusion["field_validation"]

    with template_block("02", "检查结果", "先看支持程度，再看系统识别到的字段和数据依据。", "green"):
        support = result["support"]
        if support == "较支持":
            st.success(f"支持程度：{support}")
        elif support == "部分支持":
            st.warning(f"支持程度：{support}")
        elif support == "表述过强":
            st.error(f"支持程度：{support}")
        else:
            st.info(f"支持程度：{support}")

        st.markdown("**识别到的字段**")
        st.write(display_field_list(result["fields"]) if result["fields"] else "暂未识别到明确字段")

        st.markdown("**数据依据**")
        if result["evidence"]:
            for item in result["evidence"]:
                st.write(f"- {conclusion_display_text(item)}")
        else:
            st.write("- 当前没有形成足够的数据依据。")

        if result.get("ai_explanation"):
            st.markdown("**怎么理解**")
            st.write(conclusion_display_text(result["ai_explanation"]))

    if result["warnings"]:
        with template_block("03", "风险提醒", "这些信息会影响结论是否能写得足够严谨。", "amber"):
            for item in result["warnings"]:
                st.warning(conclusion_display_text(item))

    with template_block("04", "建议改写", "把过强或证据不足的表达改成更适合报告的说法。", "teal"):
        st.info(conclusion_display_text(result["suggestion"]))

    with st.expander("AI 使用说明", expanded=False):
        st.write(f"当前状态：{status['state']}")
        if status["can_call"]:
            st.write("AI 用于理解你输入的结论，并尝试解析结论类型和涉及字段。")
        else:
            st.write("AI 当前不可调用，本次会使用本地规则识别字段和检查结论。")
        st.write("字段存在性、缺失率、计算证据和支持程度仍由本地程序校验；系统不会执行 AI 生成代码。")
    show_conclusion_check_basis(parse_status, review_status, field_validation, result)


def parse_conclusion_with_ai(df, conclusion):
    """Use AI to parse a conclusion into controlled field candidates."""
    status = {"used_ai": False, "source": "本地规则", "message": "AI 未启用或不可调用。", "parsed": {}}
    if not ai_status()["can_call"]:
        return {}, status
    payload = build_conclusion_parse_payload(df, conclusion)
    prompt = (
        "你是 DataMind 的受控结论解析助手。请只根据用户结论和 fields 中列出的当前数据字段，"
        "解析这句话想检查什么。不要判断结论真假，不要编造字段，不要生成代码。"
        "如果结论提到中文概念，请从 fields 的 column 或 display_label 中选择最贴近的原始字段名。"
        "fields 必须完整列出该结论实际需要用到的原始字段名；如果找不到字段，写入 missing_concepts。"
        "claim_type 只能从 correlation、group_difference、trend、ranking、single_field、unknown 中选择。"
        "只返回 JSON。\n\n"
        f"输入：{json.dumps(payload, ensure_ascii=False)}"
    )
    data, error = request_structured_json(prompt, conclusion_parse_schema(), timeout=25)
    if error or not data:
        status["message"] = f"AI 解析失败：{error or '未返回可用内容'}"
        return {}, status
    status = {"used_ai": True, "source": "AI 解析 + 本地字段校验", "message": "AI 已解析结论结构，本地将继续校验字段和计算证据。", "parsed": data}
    return data, status


def build_conclusion_parse_payload(df, conclusion):
    """Build compact field context for AI conclusion parsing."""
    fields = []
    excluded = []
    for column in list(df.columns)[:120]:
        series = df[column]
        item = {
            "column": str(column),
            "display_label": display_field(column),
            "dtype": str(series.dtype),
            "missing_rate_%": round(float(series.isna().mean() * 100), 2),
            "non_empty_count": int(series.notna().sum()),
            "unique_count": int(series.nunique(dropna=True)),
            "numeric_usable": bool(is_numeric_usable(series)),
            "examples": [str(value)[:40] for value in series.dropna().head(3).tolist() if str(value).strip()],
        }
        if recommendation_fields_unusable(df, [column]):
            excluded.append(item)
        else:
            fields.append(item)
    return {"conclusion": str(conclusion), "fields": fields, "excluded_fields": excluded[:30]}


def conclusion_parse_schema():
    """Return schema for AI conclusion parsing."""
    return {
        "name": "datamind_conclusion_parse",
        "schema": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "claim_type": {"type": "string"},
                "fields": {"type": "array", "items": {"type": "string"}},
                "group_field": {"type": "string"},
                "value_field": {"type": "string"},
                "x_field": {"type": "string"},
                "y_field": {"type": "string"},
                "time_field": {"type": "string"},
                "missing_concepts": {"type": "array", "items": {"type": "string"}},
                "reason": {"type": "string"},
            },
            "required": ["claim_type", "fields", "group_field", "value_field", "x_field", "y_field", "time_field", "missing_concepts", "reason"],
        },
    }


def conclusion_candidate_fields(df, conclusion, ai_parse):
    """Resolve AI and text field references, then validate them locally."""
    raw_fields = []
    if isinstance(ai_parse, dict):
        for key in ["fields", "group_field", "value_field", "x_field", "y_field", "time_field"]:
            value = ai_parse.get(key)
            if isinstance(value, list):
                raw_fields.extend(value)
            elif value:
                raw_fields.append(value)
    raw_fields.extend(referenced_display_fields(df, conclusion))
    resolved = []
    rejected = []
    for raw in raw_fields:
        field = resolve_field_reference(raw, df)
        if field not in df.columns:
            rejected.append({"字段": str(raw), "原因": "字段不存在于当前数据中。"})
            continue
        missing_rate = float(df[field].isna().mean() * 100)
        if missing_rate >= 40:
            rejected.append({"字段": display_field(field), "原因": f"缺失率较高（{missing_rate:.1f}%），不适合作为结论依据。"})
            resolved.append(field)
            continue
        resolved.append(field)
    return list(dict.fromkeys(resolved)), {"resolved": list(dict.fromkeys(resolved)), "rejected": rejected}


def polish_conclusion_review_with_ai(conclusion, result, field_validation, parse_status):
    """Use AI only to explain local conclusion check result and rewrite wording."""
    status = {"used_ai": False, "source": "本地规则", "message": "AI 未启用或不可调用。"}
    if not ai_status()["can_call"]:
        return {}, status
    payload = {
        "user_conclusion": conclusion,
        "local_support": result.get("support"),
        "local_fields": [display_field(field) for field in result.get("fields", [])],
        "local_evidence": [conclusion_display_text(item) for item in result.get("evidence", [])],
        "local_warnings": [conclusion_display_text(item) for item in result.get("warnings", [])],
        "local_suggestion": conclusion_display_text(result.get("suggestion", "")),
        "field_validation": field_validation,
        "ai_parse_status": parse_status,
    }
    prompt = (
        "你是 DataMind 的受控报告结论改写助手。请只基于本地检查结果解释用户结论是否适合写进报告，"
        "不能改变 local_support，不能新增计算结果，不能使用未在 local_evidence 中出现的事实。"
        "输出中如果提到英文字段名，必须完整保留原字段并在后面括号写中文含义，或直接使用输入中的中文字段标签。"
        "请给出面向用户的 explanation 和 suggestion。suggestion 应是一句更稳妥、可写进报告的中文表达。"
        "如果证据不足，要明确说明不要把原句写成确定结论。只返回 JSON。\n\n"
        f"输入：{json.dumps(payload, ensure_ascii=False)}"
    )
    data, error = request_structured_json(prompt, conclusion_review_schema(), timeout=25)
    if error or not data:
        status["message"] = f"AI 改写失败：{error or '未返回可用内容'}"
        return {}, status
    return {
        "explanation": str(data.get("explanation", "")).strip(),
        "suggestion": str(data.get("suggestion", "")).strip(),
    }, {"used_ai": True, "source": "AI 解释改写 + 本地证据约束", "message": "AI 已基于本地证据生成解释和改写建议。"}


def conclusion_review_schema():
    """Return schema for AI conclusion explanation and rewrite."""
    return {
        "name": "datamind_conclusion_review",
        "schema": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "explanation": {"type": "string"},
                "suggestion": {"type": "string"},
            },
            "required": ["explanation", "suggestion"],
        },
    }


def show_conclusion_check_basis(parse_status, review_status, field_validation, result):
    """Show AI and local evidence for conclusion checking."""
    with st.expander("查看检查依据", expanded=False):
        st.write(f"解析方式：{parse_status.get('source', '本地规则')}")
        st.write(f"解析状态：{parse_status.get('message', '-')}")
        if parse_status.get("parsed"):
            st.json(parse_status["parsed"])
        st.write(f"解释方式：{review_status.get('source', '本地规则')}")
        st.write(f"解释状态：{review_status.get('message', '-')}")
        st.write("本地校验：字段必须存在于当前数据中；缺失率过高、无法计算或类型不适合时，不能作为强结论依据。")
        st.write("本地证据：相关性、分组均值、单字段摘要、强结论词和因果词检查。")
        st.write("通过字段：" + ("、".join(display_field(field) for field in field_validation.get("resolved", [])) or "暂无"))
        if field_validation.get("rejected"):
            st.write("未采用字段：")
            for item in field_validation["rejected"]:
                st.write(f"- {conclusion_display_text(item['字段'])}：{conclusion_display_text(item['原因'])}")
        st.write(f"最终支持程度：{result.get('support')}")


def show_report_completion_reminder(df, source_name):
    """Show actionable report completeness reminders."""
    items = report_completion_items(df, source_name)
    completed = [item for item in items if item["状态"] == "已包含"]
    missing = [item for item in items if item["状态"] != "已包含"]
    if len(missing) == 0:
        st.success("报告完整度：较好。已包含数据说明、关键发现、局限和后续建议。")
    elif len(missing) <= 2:
        st.warning("报告完整度：可用，但建议补充下面的证据后再下载。")
    else:
        st.error("报告完整度：证据还不够，建议先补充关键分析再生成正式报告。")

    st.caption("已包含：" + "、".join(item["补充项"] for item in completed) if completed else "已包含：暂无")
    if missing:
        st.write("建议补充：")
        for item in missing:
            with st.container(border=True):
                st.markdown(f"**{item['补充项']}**")
                st.write(item["为什么需要"])
                st.caption(f"去哪里补：{item['推荐入口']}")
                st.caption(f"补完后作用：{item['补完作用']}")


def report_completion_items(df, source_name):
    """Return actionable report completion items."""
    profile = profile_table(df)
    insights = mine_dataset_insights(df)
    has_cleaning = "cleaned_df" in st.session_state
    has_qa = bool(st.session_state.get("last_qa_response"))
    has_history = not history_dataframe().empty
    has_chart_history = not history_dataframe("图表记录").empty
    missing_columns = sum(v > 0 for v in profile["missing_counts"].values())
    has_quality_issue = bool(missing_columns or int(df.duplicated().sum()) or not extreme_value_impact_table(df).empty)
    return [
        {
            "补充项": "数据来源与样本规模",
            "状态": "已包含",
            "为什么需要": f"报告需要说明分析基于哪份数据，以及样本大小。当前数据为 {source_name}，共 {profile['rows']} 行、{profile['columns']} 列。",
            "推荐入口": "数据概览 → 数据集速读",
            "补完作用": "形成报告开头的数据说明。",
        },
        {
            "补充项": "数据质量说明",
            "状态": "已包含" if (has_cleaning or not has_quality_issue) else "建议补充",
            "为什么需要": "当前数据存在缺失、重复或极端值影响时，报告需要说明是否清洗以及这些问题会怎样影响结论。",
            "推荐入口": "清洗预处理 → 清洗设置 / 极端值影响",
            "补完作用": "报告可以写入清洗日志、极端值影响和数据局限。",
        },
        {
            "补充项": "图表证据",
            "状态": "已包含" if has_chart_history else "建议补充",
            "为什么需要": "关键发现最好有图表支撑，否则报告会像纯文字判断。",
            "推荐入口": "统计可视化 → 基础图表分析 → 数值分布 / 分组对比",
            "补完作用": "报告可以引用图表结论和分析历史。",
        },
        {
            "补充项": "关键发现",
            "状态": "已包含" if insights else "建议补充",
            "为什么需要": "报告正文需要少量真正重要的发现，而不是堆叠所有统计结果。",
            "推荐入口": "统计可视化 / 自然语言问答 / 分析报告 → 生成报告",
            "补完作用": "报告可以写入图表结论、问答结果、依据字段和局限提醒。",
        },
        {
            "补充项": "问答摘要",
            "状态": "已包含" if has_qa else "可选补充",
            "为什么需要": "如果想展示交互式分析能力，可以补充一个关键问题和系统回答。",
            "推荐入口": "自然语言问答 → 自由提问",
            "补完作用": "报告或附录可以加入问答摘要和计算依据。",
        },
        {
            "补充项": "分析记录",
            "状态": "已包含" if has_history else "建议补充",
            "为什么需要": "答辩时需要说明结论是如何一步步产生的。",
            "推荐入口": "分析历史 → 分析记录",
            "补完作用": "生成报告的附录部分可以加入分析记录。",
        },
        {
            "补充项": "局限与下一步建议",
            "状态": "已包含",
            "为什么需要": "报告需要避免过度结论，并说明下一步可以如何继续分析。",
            "推荐入口": "分析报告 → 生成报告",
            "补完作用": "形成更严谨的结尾段落。",
        },
    ]


def build_markdown_report(
    df,
    source_name,
    report_type="简洁报告",
    include_cleaning=None,
    include_insights=None,
    include_qa=None,
    include_chart_guide=None,
    include_history=None,
    selected_materials=None,
    use_ai=False,
    return_status=False,
):
    """Build a Markdown report from local deterministic summaries."""
    status = {"source": "本地规则报告生成", "used_ai": False, "fallback": False, "message": ""}
    profile = profile_table(df)
    report = quality_report(df)
    themes = infer_dataset_themes(df)
    subject = infer_dataset_subject(df)
    selected_materials = selected_materials or default_report_materials(df, source_name, report_type)
    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M")

    local_sections = build_local_report_sections(df, source_name, report_type, selected_materials, profile, report, themes, subject)
    sections = local_sections
    if use_ai:
        ai_sections, ai_message = generate_ai_report_sections(local_sections, selected_materials, report_type)
        if ai_sections:
            sections = ai_sections
            status = {"source": "AI 整理润色 + 本地结构校验", "used_ai": True, "fallback": False, "message": "AI 已基于已选素材生成报告内容。"}
        else:
            status = {"source": "本地规则报告生成", "used_ai": False, "fallback": True, "message": ai_message or "AI 未返回可用报告内容。"}

    lines = [
        "# DataMind 数据分析报告",
        "",
        f"- 生成时间：{generated_at}",
        f"- 使用数据：{source_name}",
        f"- 报告类型：{report_type}",
        "",
        "## 1. 报告摘要",
        "",
        sections["summary"],
        "",
    ]
    section_no = 2

    if selected_materials.get("include_background", True):
        lines.extend(["", f"## {section_no}. 数据说明", ""])
        lines.extend(markdown_lines(sections["data_description"]))
        section_no += 1

    if selected_materials.get("include_quality", True):
        lines.extend(["", f"## {section_no}. 数据处理与质量", ""])
        lines.extend(markdown_lines(sections["processing_quality"]))
        section_no += 1

    lines.extend(["", f"## {section_no}. 主要分析结果", ""])
    lines.extend(markdown_lines(sections["main_results"]))
    section_no += 1

    lines.extend(["", f"## {section_no}. 局限说明", ""])
    lines.extend(markdown_lines(sections["limitations"]))
    section_no += 1

    if selected_materials.get("include_appendix"):
        lines.extend(["", f"## {section_no}. 附录", ""])
        lines.extend(report_appendix_lines(df))

    lines.extend(
        [
            "",
            "## 生成说明",
            "",
            report_generation_note(status),
        ]
    )
    report_text = "\n".join(lines)
    if return_status:
        return report_text, status
    return report_text


def build_local_report_sections(df, source_name, report_type, selected_materials, profile, report, themes, subject):
    """Build structured local report sections before optional AI polishing."""
    return {
        "summary": report_summary_text(df, source_name, profile, report, subject, selected_materials),
        "data_description": report_data_description_lines(df, source_name, profile, subject, themes),
        "processing_quality": report_processing_quality_lines(df, report),
        "main_results": report_selected_result_lines(selected_materials, report_type=report_type),
        "limitations": report_limitation_lines(df, report),
    }


def markdown_lines(value):
    """Normalize AI/local section content into Markdown lines."""
    if isinstance(value, list):
        return [str(item) for item in value]
    if not value:
        return []
    return str(value).splitlines()


def report_generation_note(status):
    """Return report generation note based on AI usage."""
    if status.get("used_ai"):
        return "本报告由 DataMind 根据用户选择的分析素材生成，AI 仅负责组织和润色报告文字；系统未执行 AI 生成代码，也未允许 AI 新增数据事实。"
    return "本报告由 DataMind 本地规则生成，未执行 AI 生成代码。AI 不可用或未启用时，系统会使用本地模板兜底。"


def generate_ai_report_sections(local_sections, selected_materials, report_type):
    """Use AI as a controlled writing assistant for selected report materials."""
    payload = {
        "report_type": report_type,
        "required_sections": ["summary", "data_description", "processing_quality", "main_results", "limitations"],
        "local_sections": local_sections,
        "selected_materials": {
            "charts": selected_materials.get("charts", []),
            "qa": selected_materials.get("qa", []),
            "include_background": selected_materials.get("include_background", True),
            "include_quality": selected_materials.get("include_quality", True),
        },
    }
    prompt = (
        "你是 DataMind 的受控报告写作助手。请只根据输入中的 local_sections 和 selected_materials 整理中文报告内容。"
        "你不能选择新的结论，不能新增字段、数值、图表、问答或数据事实，不能编造因果关系。"
        "你的任务是减少重复、统一语气、让语言更像正式报告。"
        "必须保留报告结构：summary、data_description、processing_quality、main_results、limitations。"
        "summary 是真正的报告摘要，只概括用户选择的图表/问答重点、最重要发现方向和总体限制，控制在 2-3 句。"
        "summary 不要写数据来源、文件名、行数、列数、数据对象、字段范围或信息维度；这些只能写在 data_description。"
        "summary 和 data_description 不能重复同一信息，也不要使用相同句子。"
        "如果用户没有选择图表或问答素材，summary 应说明当前报告缺少可写入的主要分析结果，而不是重复数据说明。"
        "data_description 只写数据是什么和包含哪些信息，不写清洗和质量。"
        "processing_quality 只写清洗状态和质量影响，不重复数据规模和数据对象。"
        "main_results 只写用户已选择的图表素材和问答素材；如果没有选择素材，要明确提示尚未选择主要分析结果。"
        "limitations 不重复质量明细，只写解释结论时的限制。"
        "每个字段值可以是一段话或 Markdown 列表字符串。必须只返回 JSON。\n\n"
        f"输入素材：{json.dumps(payload, ensure_ascii=False)}"
    )
    data, error = request_structured_json(prompt, ai_report_sections_schema(), timeout=45)
    if error or not data:
        return None, error or "AI 没有返回报告内容。"
    sections = normalize_ai_report_sections(data)
    if not sections:
        return None, "AI 返回的报告结构不完整。"
    if not ai_report_sections_safe(sections, selected_materials):
        return None, "AI 返回内容包含未选择素材之外的新增事实，已使用本地模板兜底。"
    return sections, None


def ai_report_sections_schema():
    """Return expected JSON schema for AI report sections."""
    return {
        "name": "datamind_report_sections",
        "schema": {
            "type": "object",
            "additionalProperties": False,
            "properties": {
                "summary": {"type": "string"},
                "data_description": {"type": "string"},
                "processing_quality": {"type": "string"},
                "main_results": {"type": "string"},
                "limitations": {"type": "string"},
            },
            "required": ["summary", "data_description", "processing_quality", "main_results", "limitations"],
        },
    }


def normalize_ai_report_sections(data):
    """Normalize AI report sections into strings."""
    required = ["summary", "data_description", "processing_quality", "main_results", "limitations"]
    if not isinstance(data, dict):
        return None
    sections = {}
    for key in required:
        value = str(data.get(key, "")).strip()
        if not value:
            return None
        sections[key] = value
    return sections


def ai_report_sections_safe(sections, selected_materials):
    """Conservative guard that rejects obvious unsupported additions."""
    text = "\n".join(str(value) for value in sections.values())
    forbidden = ["显著导致", "证明了", "必然", "一定是", "完全说明"]
    if any(word in text for word in forbidden):
        return False
    selected_text = " ".join(
        str(item.get("text", "")) + " " + str(item.get("detail", ""))
        for item in [*selected_materials.get("charts", []), *selected_materials.get("qa", [])]
    )
    if not selected_text and "尚未选择" not in text and "没有选择" not in text:
        return False
    return True


def default_report_materials(df, source_name, report_type="简洁报告"):
    """Return default report materials for non-UI callers and tests."""
    return {
        "include_background": True,
        "include_quality": True,
        "include_appendix": report_type == "答辩/附录版",
        "findings": [],
        "charts": [],
        "qa": [],
    }


def markdown_report_to_pdf(markdown_text, title="DataMind 报告"):
    """Convert the project Markdown report into PDF bytes."""
    register_pdf_fonts()
    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        rightMargin=18 * mm,
        leftMargin=18 * mm,
        topMargin=18 * mm,
        bottomMargin=18 * mm,
        title=title,
    )
    styles = pdf_report_styles()
    story = []
    bullet_items = []

    def flush_bullets():
        nonlocal bullet_items
        if bullet_items:
            story.append(
                ListFlowable(
                    [ListItem(Paragraph(item, styles["BulletText"]), leftIndent=6) for item in bullet_items],
                    bulletType="bullet",
                    start="circle",
                    leftIndent=16,
                    bulletFontName="STSong-Light",
                )
            )
            story.append(Spacer(1, 4 * mm))
            bullet_items = []

    for raw_line in str(markdown_text).splitlines():
        line = raw_line.strip()
        if not line:
            flush_bullets()
            continue
        if line.startswith("- "):
            bullet_items.append(inline_markdown_to_pdf(line[2:]))
            continue
        flush_bullets()
        if line.startswith("# "):
            story.append(Paragraph(inline_markdown_to_pdf(line[2:]), styles["Title"]))
            story.append(HRFlowable(width="100%", color=colors.HexColor("#2563eb"), thickness=1))
            story.append(Spacer(1, 6 * mm))
        elif line.startswith("## "):
            story.append(Spacer(1, 3 * mm))
            story.append(Paragraph(inline_markdown_to_pdf(line[3:]), styles["Heading2"]))
            story.append(Spacer(1, 2 * mm))
        elif line.startswith("### "):
            story.append(Paragraph(inline_markdown_to_pdf(line[4:]), styles["Heading3"]))
            story.append(Spacer(1, 1.5 * mm))
        elif line.startswith("> "):
            story.append(Paragraph(inline_markdown_to_pdf(line[2:]), styles["Quote"]))
            story.append(Spacer(1, 2 * mm))
        else:
            story.append(Paragraph(inline_markdown_to_pdf(line), styles["Body"]))
            story.append(Spacer(1, 1.5 * mm))
    flush_bullets()
    if not story:
        story.append(Paragraph("当前报告没有可导出的内容。", styles["Body"]))
    doc.build(story)
    return buffer.getvalue()


def register_pdf_fonts():
    """Register a built-in Chinese font for PDF export."""
    if "STSong-Light" not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))


def pdf_report_styles():
    """Return PDF paragraph styles using a CJK font."""
    base = getSampleStyleSheet()
    return {
        "Title": ParagraphStyle(
            "DMTitle",
            parent=base["Title"],
            fontName="STSong-Light",
            fontSize=20,
            leading=26,
            textColor=colors.HexColor("#0f172a"),
            spaceAfter=8,
        ),
        "Heading2": ParagraphStyle(
            "DMHeading2",
            parent=base["Heading2"],
            fontName="STSong-Light",
            fontSize=15,
            leading=20,
            textColor=colors.HexColor("#1d4ed8"),
            spaceBefore=8,
            spaceAfter=4,
        ),
        "Heading3": ParagraphStyle(
            "DMHeading3",
            parent=base["Heading3"],
            fontName="STSong-Light",
            fontSize=12,
            leading=17,
            textColor=colors.HexColor("#334155"),
            spaceBefore=6,
            spaceAfter=3,
        ),
        "Body": ParagraphStyle(
            "DMBody",
            parent=base["BodyText"],
            fontName="STSong-Light",
            fontSize=10.5,
            leading=16,
            textColor=colors.HexColor("#182230"),
        ),
        "BulletText": ParagraphStyle(
            "DMBulletText",
            parent=base["BodyText"],
            fontName="STSong-Light",
            fontSize=10,
            leading=15,
            textColor=colors.HexColor("#182230"),
        ),
        "Quote": ParagraphStyle(
            "DMQuote",
            parent=base["BodyText"],
            fontName="STSong-Light",
            fontSize=10,
            leading=15,
            leftIndent=8,
            rightIndent=8,
            borderColor=colors.HexColor("#bfdbfe"),
            borderWidth=0.6,
            borderPadding=6,
            backColor=colors.HexColor("#eff6ff"),
            textColor=colors.HexColor("#1e3a8a"),
        ),
    }


def inline_markdown_to_pdf(text):
    """Escape and lightly render inline Markdown for ReportLab paragraphs."""
    escaped = html.escape(str(text))
    escaped = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", escaped)
    escaped = re.sub(r"`(.+?)`", r"<font name='Courier'>\1</font>", escaped)
    return escaped


def markdown_report_to_html(markdown_text, title="DataMind 报告"):
    """Convert the project Markdown report into a standalone HTML file."""
    body = render_simple_markdown_html(markdown_text)
    escaped_title = html.escape(title)
    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{escaped_title}</title>
  <style>
    body {{
      margin: 0;
      background: #f6f8fb;
      color: #182230;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Microsoft YaHei", sans-serif;
      line-height: 1.72;
    }}
    main {{
      max-width: 920px;
      margin: 40px auto;
      padding: 44px 52px;
      background: #ffffff;
      border: 1px solid #e4e7ec;
      box-shadow: 0 18px 50px rgba(16, 24, 40, 0.08);
    }}
    h1 {{
      margin-top: 0;
      padding-bottom: 16px;
      border-bottom: 2px solid #2563eb;
      color: #0f172a;
      font-size: 30px;
    }}
    h2 {{
      margin-top: 34px;
      color: #1d4ed8;
      font-size: 22px;
    }}
    h3 {{
      margin-top: 24px;
      color: #334155;
      font-size: 18px;
    }}
    ul {{
      padding-left: 22px;
    }}
    li {{
      margin: 6px 0;
    }}
    blockquote {{
      margin: 18px 0;
      padding: 12px 16px;
      border-left: 4px solid #2563eb;
      background: #eff6ff;
      color: #1e3a8a;
    }}
    code {{
      padding: 2px 5px;
      border-radius: 4px;
      background: #f1f5f9;
      font-family: Consolas, "Courier New", monospace;
    }}
    .meta {{
      margin-top: 36px;
      padding-top: 14px;
      border-top: 1px solid #e4e7ec;
      color: #667085;
      font-size: 13px;
    }}
    @media (max-width: 720px) {{
      main {{
        margin: 0;
        padding: 28px 20px;
        border: 0;
        box-shadow: none;
      }}
    }}
  </style>
</head>
<body>
  <main>
{body}
    <div class="meta">由 DataMind 生成。系统未执行 AI 生成代码。</div>
  </main>
</body>
</html>
"""


def render_simple_markdown_html(markdown_text):
    """Render the subset of Markdown used by DataMind reports."""
    lines = markdown_text.splitlines()
    html_lines = []
    in_list = False
    for raw_line in lines:
        line = raw_line.rstrip()
        if not line:
            if in_list:
                html_lines.append("    </ul>")
                in_list = False
            continue

        if line.startswith("- "):
            if not in_list:
                html_lines.append("    <ul>")
                in_list = True
            html_lines.append(f"      <li>{inline_markdown_to_html(line[2:])}</li>")
            continue

        if in_list:
            html_lines.append("    </ul>")
            in_list = False

        if line.startswith("# "):
            html_lines.append(f"    <h1>{inline_markdown_to_html(line[2:])}</h1>")
        elif line.startswith("## "):
            html_lines.append(f"    <h2>{inline_markdown_to_html(line[3:])}</h2>")
        elif line.startswith("### "):
            html_lines.append(f"    <h3>{inline_markdown_to_html(line[4:])}</h3>")
        elif line.startswith("> "):
            html_lines.append(f"    <blockquote>{inline_markdown_to_html(line[2:])}</blockquote>")
        else:
            html_lines.append(f"    <p>{inline_markdown_to_html(line)}</p>")

    if in_list:
        html_lines.append("    </ul>")
    return "\n".join(html_lines)


def inline_markdown_to_html(text):
    """Escape text and render simple inline Markdown markers."""
    escaped = html.escape(str(text))
    escaped = re.sub(r"`([^`]+)`", r"<code>\1</code>", escaped)
    escaped = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", escaped)
    return escaped


def report_summary_text(df, source_name, profile, report, subject, selected_materials):
    """Return the opening report summary."""
    selected_results = selected_materials.get("charts", []) + selected_materials.get("qa", [])
    if not selected_results:
        return (
            "当前报告尚未选择图表分析或自然语言问答结果，因此暂时缺少可写入正文的主要分析发现。"
            "建议先完成至少一项分析并勾选进入报告，再生成更接近正式汇报的摘要。"
        )
    result_text = selected_results[0]["text"]
    extra_count = len(selected_results) - 1
    extra_hint = f"此外还包含 {extra_count} 项已选分析结果。" if extra_count > 0 else ""
    return (
        f"本报告围绕用户已选择的分析结果展开，重点关注：{result_text}"
        f"{extra_hint}"
        "这些结果适合作为正文讨论的核心线索，但解释时仍需结合数据质量、样本范围和字段含义谨慎判断。"
    )


def report_objective_text(df, subject):
    """Return user-facing analysis objectives."""
    profile = profile_table(df)
    numeric_columns = analysis_numeric_columns(df, profile["numeric_columns"])
    category_columns = category_like_columns(df)
    goals = [
        f"理解这份表格描述的对象和样本范围：{subject['description']}。",
        "判断数据是否足够可靠，尤其是缺失、重复和极端值是否会影响结论。",
    ]
    if numeric_columns:
        goals.append(f"识别关键数值字段的常见范围和异常波动，例如“{numeric_columns[0]}”。")
    if category_columns:
        goals.append(f"查看重要类别字段的分布差异，例如“{category_columns[0]}”。")
    goals.append("形成可以继续做图表分析、问答分析或正式写作的结论线索。")
    return "\n".join(f"- {item}" for item in goals)


def report_data_description_lines(df, source_name, profile, subject, themes):
    """Return data description lines without quality or cleaning details."""
    lines = [
        f"- 数据来源：{source_name}。",
        f"- 数据对象：{subject['description']}",
        f"- 样本规模：{profile['rows']} 行，{profile['columns']} 列。",
        f"- 数据内容：{dataset_description_text(subject, themes)}",
    ]
    return lines


def report_processing_quality_lines(df, report):
    """Return processing and quality lines without repeating data identity."""
    lines = []
    if "cleaned_df" in st.session_state:
        lines.append("- 清洗状态：当前报告使用的数据已完成清洗，可优先参考清洗后的分析结果。")
    else:
        lines.append("- 清洗状态：当前尚未执行清洗，涉及缺失、重复或极端值的结论需要保留解释空间。")
    lines.extend(report_quality_lines(df, report))
    return lines


def report_selected_result_lines(selected_materials, report_type="简洁报告"):
    """Return report lines from user-selected chart and QA materials."""
    lines = []
    groups = [
        ("图表分析结果", selected_materials.get("charts", [])),
        ("问答分析结果", selected_materials.get("qa", [])),
    ]
    for group_title, items in groups:
        if not items:
            continue
        lines.append(f"### {group_title}")
        for index, item in enumerate(items, start=1):
            lines.append(f"- {index}. {item['text']}")
            if report_type != "简洁报告" and item.get("detail"):
                lines.append(f"  - 依据：{item['detail']}")
        lines.append("")
    if not lines:
        return ["- 当前还没有选择主要分析结果。建议先完成至少一个图表分析或自然语言问答，再选择要写入报告的素材。"]
    return lines


def report_limitation_lines(df, report):
    """Return interpretation limitations without repeating detailed quality metrics."""
    lines = [
        "- 本报告中的发现来自当前数据和用户选择的分析素材，不能代表数据集之外的总体情况。",
        "- 相关性或同步变化只能说明字段之间可能存在关系，不能直接证明因果关系。",
        "- Top N、分组对比和排行结果容易受到样本量、类别分布和极端值影响，解释时需要结合具体字段含义。",
    ]
    if "cleaned_df" not in st.session_state:
        lines.append("- 当前若使用原始数据生成报告，未处理的缺失值、重复记录和极端值可能影响平均值、总量和排序结论。")
    return lines


def report_appendix_lines(df):
    """Return appendix lines for defense and traceability."""
    lines = ["### A. 清洗日志"]
    lines.extend(report_cleaning_lines())
    lines.extend(["", "### B. 最近一次问答"])
    lines.extend(report_qa_lines())
    lines.extend(["", "### C. 图表与分析建议"])
    for item in user_chart_recommendations(df):
        lines.append(f"- {item['title']}：{item['question']}（建议字段：{item['fields']}）")
    lines.extend(["", "### D. 分析记录"])
    lines.extend(history_report_lines())
    return lines


def report_quality_lines(df, report):
    """Return report lines for data quality."""
    lines = []
    duplicate_count = int(df.duplicated().sum())
    if duplicate_count:
        lines.append(f"- 发现 {duplicate_count} 行重复记录，可能影响计数、平均值和分组结果。")
    else:
        lines.append("- 没有发现重复记录。")

    missing = df.isna().mean().sort_values(ascending=False)
    missing = missing[missing > 0].head(5)
    if missing.empty:
        lines.append("- 没有发现明显缺失值。")
    else:
        lines.append("- 缺失较多的字段：" + "；".join(f"{column} {rate * 100:.2f}%" for column, rate in missing.items()))

    outliers = report["outlier_summary"]
    if outliers.empty:
        lines.append("- 当前未发现明显极端值风险字段。")
    else:
        items = [f"{row['column']} 约 {row['outlier_rate_%']}%" for _, row in outliers.head(5).iterrows()]
        lines.append("- 可能存在极端值风险的字段：" + "；".join(items))
        impact = extreme_value_impact_table(df)
        if not impact.empty:
            strongest = impact.sort_values("平均值变化数值", ascending=False).iloc[0]
            lines.append(
                f"- 极端值影响最大的是 {strongest['字段']}：全部数据平均值为 {strongest['全部数据平均值']}，"
                f"去极端值后平均值为 {strongest['去极端值后平均值']}，变化幅度约 {strongest['平均值变化幅度']}。"
            )
    return lines


def report_cleaning_lines():
    """Return report lines for cleaning state."""
    if "cleaned_df" not in st.session_state:
        return ["- 当前还没有执行清洗。建议先根据质量提醒决定是否进入清洗预处理。"]

    lines = ["- 已生成清洗后数据，后续分析默认可以优先使用清洗后数据。"]
    cleaning_log = st.session_state.get("cleaning_log", [])
    if cleaning_log:
        lines.append("- 清洗日志摘要：")
        for item in cleaning_log[:8]:
            lines.append(f"  - {item}")
    return lines


def report_qa_lines():
    """Return report lines for the latest QA result."""
    response = st.session_state.get("last_qa_response")
    question = st.session_state.get("last_qa_question")
    if not response or not question:
        return ["- 当前还没有自然语言问答记录。"]
    if not response.get("ok"):
        return [f"- 最近问题：{question}", f"- 系统反馈：{response.get('error', '未能识别该问题。')}"]
    if response.get("summary"):
        summary = response["summary"]
        return [
            f"- 最近问题：{question}",
            f"- 结论：{summary['结论']}",
            f"- 主要结果：{summary['主要结果']}",
            f"- 注意事项：{summary['提醒']}",
        ]
    return [
        f"- 最近问题：{question}",
        f"- 回答：{response['answer']}",
        f"- 结论提示：{qa_result_insight(response)}",
    ]


HISTORY_FILTER_LABELS = {
    "分析过程": "基础操作",
    "问答记录": "问答分析",
    "图表记录": "图表分析",
    "导出记录": "报告与导出",
}

HISTORY_FILTER_SUFFIXES = {
    "全部记录": "all_history",
    "基础操作": "basic_operations",
    "问答分析": "qa_analysis",
    "图表分析": "chart_analysis",
    "报告与导出": "report_exports",
}


def show_history_panel(submodule="分析记录"):
    """Render the analysis history module."""
    if submodule not in HISTORY_SUBMODULES:
        submodule = "分析记录"

    section(submodule, SUBMODULE_NOTES.get(submodule))
    with template_block("01", "筛选记录", "分析记录包含清洗、图表、问答、报告等操作，可以按类型筛选查看。", "blue"):
        history, title = filtered_analysis_history()

    with template_block("02", "记录列表", "查看当前筛选下的操作内容、使用字段、方法和结果摘要。", "green"):
        if history.empty:
            st.info(f"当前还没有{title}。")
        else:
            st.dataframe(display_analysis_table(history), use_container_width=True)

    if not history.empty:
        with template_block("03", "导出当前记录", "下载内容会和当前筛选类型保持一致。", "slate"):
            st.download_button(
                f"下载{title} CSV",
                history.to_csv(index=False).encode("utf-8-sig"),
                file_name=f"datamind_{history_file_suffix(title)}.csv",
                mime="text/csv",
                use_container_width=True,
            )


def filtered_analysis_history():
    """Return all history records with an optional user-facing filter."""
    all_history = history_dataframe()
    if all_history.empty:
        return all_history, "分析记录"
    event_types = [item for item in all_history["类型"].dropna().astype(str).unique().tolist() if item]
    label_to_type = {
        HISTORY_FILTER_LABELS.get(event_type, event_type): event_type
        for event_type in event_types
    }
    filter_options = ["全部记录", *label_to_type.keys()]
    selected = st.selectbox(
        "筛选记录类型",
        filter_options,
        help="分析记录已经包含问答、图表、导出、清洗和报告等全部操作；这里可以按类型筛选。",
    )
    if selected == "全部记录":
        return all_history, selected
    event_type = label_to_type[selected]
    return all_history[all_history["类型"] == event_type], selected


def history_file_suffix(submodule):
    """Return an ASCII suffix for history CSV files."""
    return {
        "分析记录": "analysis_records",
        "全部记录": "all_history",
        "基础操作": "basic_operations",
        "问答分析": "qa_analysis",
        "图表分析": "chart_analysis",
        "报告与导出": "report_exports",
        "分析过程": "process_history",
        "问答记录": "qa_history",
        "图表记录": "chart_history",
        "导出记录": "export_history",
    }.get(submodule, "history")


def show_results_download_center():
    """Render a centralized download page for reusable analysis outputs."""
    st.write("这里集中保存当前会话中已经生成的分析成果，方便放进 Excel、报告或附录继续使用。")

    downloads = build_available_downloads()
    if not downloads:
        st.info("当前还没有可下载的分析成果。可以先完成清洗、图表、问答、智能分群或文本词云。")
        return

    for item in downloads:
        with st.container(border=True):
            st.markdown(f"**{item['title']}**")
            st.write(item["description"])
            prepared_key = f"prepared_download_{item['file_name']}"
            if st.button("准备下载", use_container_width=True, key=f"prepare_download_center_{item['file_name']}"):
                data = item["build_data"]()
                if data:
                    st.session_state[prepared_key] = data
                else:
                    st.session_state.pop(prepared_key, None)
                    st.info("当前没有可导出的内容。")
            if prepared_key in st.session_state:
                st.download_button(
                    item["button"],
                    st.session_state[prepared_key],
                    file_name=item["file_name"],
                    mime=item["mime"],
                    use_container_width=True,
                    key=f"download_center_{item['file_name']}",
                )


def build_available_downloads():
    """Build downloadable artifacts from current session state."""
    downloads = []
    all_history = history_dataframe()
    if not all_history.empty:
        downloads.append(
            csv_download_item(
                "全部分析记录",
                "包含用户在当前会话中执行过的清洗、图表、问答、报告等操作记录。",
                all_history,
                "datamind_all_history.csv",
                "下载全部分析记录 CSV",
            )
        )
    for event_type, file_name, title in [
        ("问答记录", "datamind_qa_analysis.csv", "问答分析"),
        ("图表记录", "datamind_chart_analysis.csv", "图表分析"),
        ("导出记录", "datamind_report_exports.csv", "报告与导出"),
    ]:
        history = history_dataframe(event_type)
        if not history.empty:
            downloads.append(
                csv_download_item(
                    title,
                    f"当前会话中的{title}，可作为生成报告的附录内容或答辩说明材料。",
                    history,
                    file_name,
                    f"下载{title} CSV",
                )
            )

    cleaned_df = st.session_state.get("cleaned_df")
    if isinstance(cleaned_df, pd.DataFrame):
        downloads.append(
            csv_download_item(
                "清洗后数据",
                "清洗预处理后的数据表，适合继续在 Excel 或其他工具中分析。",
                cleaned_df,
                "datamind_cleaned_data.csv",
                "下载清洗后数据 CSV",
            )
        )
        downloads.append(
            csv_download_item(
                "极端值影响表",
                "展示极端值对均值等结论的影响，可放入报告的数据质量说明或附录。",
                lambda cleaned=cleaned_df: display_extreme_value_impact_table(extreme_value_impact_table(cleaned)),
                "datamind_outlier_impact.csv",
                "下载极端值影响表 CSV",
            )
        )

    cluster_result = st.session_state.get("cluster_result")
    if isinstance(cluster_result, dict) and isinstance(cluster_result.get("points"), pd.DataFrame):
        cluster_labeled_df = st.session_state.get("cluster_labeled_df")
        cluster_download_df = cluster_labeled_df if isinstance(cluster_labeled_df, pd.DataFrame) else cluster_result["points"]
        downloads.append(
            csv_download_item(
                "智能分群结果",
                "包含原数据和智能分群标签，可继续做分组分析或附录说明。",
                cluster_download_df,
                "datamind_clustered_data.csv",
                "下载智能分群结果 CSV",
            )
        )
        if isinstance(cluster_result.get("profiles"), pd.DataFrame):
            downloads.append(
                csv_download_item(
                    "分群特点概括",
                    "每个分群的记录数量、占比和主要字段特点。",
                    cluster_result["profiles"],
                    "datamind_cluster_profiles.csv",
                    "下载分群特点 CSV",
                )
            )

    word_result = st.session_state.get("word_frequency_result")
    if isinstance(word_result, dict) and isinstance(word_result.get("frequencies"), pd.DataFrame):
        downloads.append(
            csv_download_item(
                "文本词频表",
                f"{word_result.get('column', '文本字段')} 的高频词统计结果，可用于报告中的文本主题说明。",
                word_result["frequencies"],
                "datamind_word_frequency.csv",
                "下载文本词频 CSV",
            )
        )

    return downloads


def csv_download_item(title, description, df, file_name, button):
    """Create a CSV download descriptor."""
    def build_data():
        data = df() if callable(df) else df
        if not isinstance(data, pd.DataFrame) or data.empty:
            return b""
        return data.to_csv(index=False).encode("utf-8-sig")

    return {
        "title": title,
        "description": description,
        "build_data": build_data,
        "file_name": file_name,
        "mime": "text/csv",
        "button": button,
    }


def mine_dataset_insights(df, limit=5):
    """Mine deterministic report-friendly insights from a DataFrame."""
    insights = []
    profile = profile_table(df)
    category_columns = category_like_columns(df)
    numeric_columns = analysis_numeric_columns(df, profile["numeric_columns"])

    missing_result = missing_values(df).sort_values("missing_count", ascending=False)
    missing_nonzero = missing_result[missing_result["missing_count"] > 0]
    if not missing_nonzero.empty:
        top = missing_nonzero.iloc[0]
        insights.append(
            {
                "发现": f"字段“{display_field(top['column'])}”缺失最多，缺失率为 {top['missing_rate_%']}%。",
                "依据字段": top["column"],
                "计算方法": "统计各字段缺失数量和缺失比例",
                "局限提醒": "缺失值可能来自真实空白，也可能来自采集或录入问题，不能直接解释为业务现象。",
                "下一步建议": "进入清洗预处理或缺失情况图表，确认是否需要填充、删除或在报告中说明。",
            }
        )

    for column in category_columns[:2]:
        result = top_n(df, column, 10)
        if result.empty:
            continue
        top = result.iloc[0]
        total = result["count"].sum()
        share = float(top["count"]) / total * 100 if total else 0
        insights.append(
            {
                "发现": f"“{display_field(column)}”中出现最多的是“{display_value(column, top[column])}”，占当前 Top 10 展示结果的 {share:.1f}%。",
                "依据字段": column,
                "计算方法": "Top N 类别频次统计",
                "局限提醒": "Top N 只展示高频类别，不代表所有类别的完整分布。",
                "下一步建议": "进入统计可视化的“类别分布”，查看是否存在类别过度集中。",
            }
        )
        break

    for column in numeric_columns[:2]:
        series = pd.to_numeric(df[column], errors="coerce").dropna()
        if series.empty:
            continue
        q1 = series.quantile(0.25)
        median = series.median()
        q3 = series.quantile(0.75)
        insights.append(
            {
                "发现": f"“{display_field(column)}”的中位数约为 {format_number(median)}，中间一半数据大致在 {format_number(q1)} 到 {format_number(q3)} 之间。",
                "依据字段": column,
                "计算方法": "数值字段四分位数统计",
                "局限提醒": "如果字段存在极端值，平均值和总和可能被拉偏，建议同时查看箱线图。",
                "下一步建议": "进入统计可视化的“数值分布”，查看常见范围和极端值。",
            }
        )
        break

    impact = extreme_value_impact_table(df)
    if not impact.empty:
        strongest = impact.sort_values("平均值变化数值", ascending=False).iloc[0]
        if float(strongest["平均值变化数值"]) >= 5:
            insights.append(
                {
                    "发现": f"“{display_field(strongest['字段'])}”的平均值受极端值影响较明显，去除极端值前后平均值变化约 {strongest['平均值变化幅度']}。",
                    "依据字段": strongest["字段"],
                    "计算方法": "IQR 极端值识别 + 平均值影响对比",
                    "局限提醒": "极端值不一定是错误，可能是真实但少见的记录；系统不会自动删除。",
                    "下一步建议": "进入清洗预处理的“极端值影响”，查看具体记录并决定报告中如何说明。",
                }
            )

    if category_columns and numeric_columns:
        group_column = category_columns[0]
        value_column = numeric_columns[0]
        try:
            result = groupby_agg(df, group_column, value_column, agg="mean", n=10)
            y_column = f"{value_column}_mean"
            if not result.empty and y_column in result:
                ranked = result.dropna(subset=[y_column]).sort_values(y_column, ascending=False)
                if len(ranked) >= 2:
                    top = ranked.iloc[0]
                    bottom = ranked.iloc[-1]
                    insights.append(
                        {
                            "发现": f"按“{display_field(group_column)}”分组后，“{display_value(group_column, top[group_column])}”的 {display_field(value_column)} 平均值最高，“{display_value(group_column, bottom[group_column])}”最低。",
                            "依据字段": f"{group_column} + {value_column}",
                            "计算方法": "分组平均值对比",
                            "局限提醒": "分组样本量可能不同，平均值差异不一定代表稳定差异。",
                            "下一步建议": "进入统计可视化的“分组对比”，查看具体数值和分组差异。",
                        }
                    )
        except AnalysisError:
            pass

    if len(numeric_columns) >= 2:
        corr = correlation(df)
        pair = strongest_correlation_pair(corr)
        if pair:
            col_a, col_b, value = pair
            insights.append(
                {
                    "发现": f"“{display_field(col_a)}”与“{display_field(col_b)}”的相关性较明显，相关系数约为 {value:.2f}。",
                    "依据字段": f"{col_a} + {col_b}",
                    "计算方法": "Pearson 相关性分析",
                    "局限提醒": "相关不等于因果，只能说明两个数值字段存在同步变化倾向。",
                    "下一步建议": "进入统计可视化的“关系分析”，查看散点图和热力图。",
                }
            )

    return insights[:limit]


def strongest_correlation_pair(corr_df):
    """Return the strongest off-diagonal correlation pair."""
    if corr_df.empty:
        return None
    best = None
    columns = list(corr_df.columns)
    for i, col_a in enumerate(columns):
        for col_b in columns[i + 1 :]:
            value = corr_df.loc[col_a, col_b]
            if pd.isna(value):
                continue
            if best is None or abs(value) > abs(best[2]):
                best = (col_a, col_b, float(value))
    if best and abs(best[2]) >= 0.3:
        return best
    return None


def insight_writing_reminders(df, insights):
    """Return writing reminders for insight interpretation."""
    reminders = [
        "不要把相关性写成因果关系，可以写“二者存在相关趋势”，不要写“某字段导致某字段变化”。",
        "Top N 结果只代表展示出来的前几项，写报告时要说明是否只展示了部分数据。",
        "如果存在缺失值，结论中应说明缺失可能影响统计结果。",
        "如果分组样本量差异较大，平均值对比需要谨慎解释。",
    ]
    if not insights:
        reminders.append("当前可用发现较少，建议先清洗数据或换用更适合的字段进行图表分析。")
    if int(df.duplicated().sum()):
        reminders.append("数据存在重复记录，涉及计数、总和或平均值时建议先说明是否已处理重复。")
    return reminders


def report_insight_lines(df):
    """Return Markdown lines for key insights."""
    insights = mine_dataset_insights(df)
    if not insights:
        return ["- 当前没有挖掘出稳定的关键发现。"]
    lines = []
    for item in insights:
        lines.append(f"- {item['发现']}依据字段：{item['依据字段']}；方法：{item['计算方法']}；提醒：{item['局限提醒']}")
    return lines


MODULES = {
    "数据概览": {
        "hint": "快速看懂这份数据有什么、哪里值得看、哪里要小心，以及下一步可以做什么。",
    },
    "清洗预处理": {
        "hint": "整理重复、缺失、类型和异常值，并查看清洗前后的变化。",
    },
    "统计可视化": {
        "hint": "进行 Top N、分组聚合、相关性、趋势和数值分布分析，并生成图表。",
    },
    "自然语言问答": {
        "hint": "用自然语言提问，系统转成结构化指令后调用白名单分析函数。",
    },
    "分析报告": {
        "hint": "把数据概览、质量提醒、清洗情况、图表建议和问答结果整理成 Markdown 报告。",
    },
    "分析历史": {
        "hint": "记录用户问题、图表、清洗、导出等操作，展示字段、方法、结果和时间戳。",
    },
}


def get_analysis_df(raw_df):
    """Return the selected data source for analysis and QA."""
    source_options = []
    if "cleaned_df" in st.session_state:
        source_options.append("清洗后数据")
    source_options.append("原始数据")

    if len(source_options) == 1:
        st.session_state["analysis_source"] = "原始数据"
        df, label_column = analysis_df_with_cluster_label(raw_df)
        source_name = "原始数据"
        if label_column:
            source_name += f"（含{label_column}字段）"
        return df, source_name

    if st.session_state.get("analysis_source") not in source_options:
        st.session_state["analysis_source"] = source_options[0]

    st.markdown('<div class="dm-analysis-source">', unsafe_allow_html=True)
    analysis_source = st.radio(
        "分析使用的数据",
        source_options,
        index=0,
        horizontal=True,
        help="清洗完成后，可以选择清洗后数据或原始数据；如果已执行智能分群，系统会自动加入分群字段。",
        key="analysis_source",
    )
    st.markdown("</div>", unsafe_allow_html=True)
    if analysis_source == "清洗后数据":
        df = st.session_state["cleaned_df"]
    else:
        df = raw_df
    df, label_column = analysis_df_with_cluster_label(df)
    source_name = analysis_source
    if label_column:
        source_name += f"（含{label_column}字段）"
    return df, source_name


def cleaning_outlier_diagnostics(raw_df):
    """Diagnose outliers before cleaning without changing the original data."""
    diagnostic_df = raw_df.copy()
    diagnostic_df, _ = auto_convert_types(diagnostic_df)
    return sort_extreme_value_impact(extreme_value_impact_table(diagnostic_df))


def show_cleaning_outlier_decision_area(outlier_diagnostics):
    """Show outlier diagnosis where users choose cleaning strategy."""
    if outlier_diagnostics.empty:
        st.info("当前没有发现会明显影响数值分析的极端值字段。")
        return

    affected_fields = len(outlier_diagnostics)
    high_impact_count = int((outlier_diagnostics["平均值变化数值"] >= 10).sum())
    if high_impact_count:
        st.warning(
            f"发现 {affected_fields} 个字段存在极端值，其中 {high_impact_count} 个字段对平均值影响明显。建议先查看影响，再选择处理方式。"
        )
    else:
        st.info(
            f"发现 {affected_fields} 个字段存在极端值。默认可以先选择“只标记，保留原值”，后续分析时再决定是否排除。"
        )
    st.caption("系统按常见统计规则识别出可能影响分析的极端值；这些值不一定是错误数据，是否处理需要结合实际含义判断。")

    with st.expander("查看极端值影响", expanded=False):
        st.dataframe(
            display_analysis_table(display_extreme_value_impact_table(sort_extreme_value_impact(outlier_diagnostics))),
            use_container_width=True,
        )


def show_cleaning_panel(raw_df, submodule="清洗设置"):
    """Render cleaning controls and cleaned data results."""
    if submodule in ["清洗日志", "字段使用提醒", "字段处理建议"]:
        submodule = "清洗前后对比"
    if submodule not in CLEANING_SUBMODULES:
        submodule = "清洗设置"

    section(submodule, SUBMODULE_NOTES.get(submodule))

    if submodule == "清洗设置":
        with st.form("cleaning_options"):
            with template_block("01", "基础整理", "先处理重复记录、空白文本、空字符串和可计算字段类型。", "blue"):
                option_cols = st.columns(2)
                drop_duplicates = option_cols[0].checkbox("删除完全重复的记录", value=True)
                convert_types = option_cols[1].checkbox("把可计算的文本转成数值或日期", value=True)
                strip_text = option_cols[0].checkbox("去除文本前后的多余空格", value=True)
                empty_string_as_missing = option_cols[1].checkbox("把空白内容统一当作缺失值", value=True)

            with template_block("02", "类别值整理", "合并格式差异造成的重复类别，让分组统计更清楚。", "teal"):
                standardize_category_values = st.checkbox(
                    "合并大小写或空格不同但含义相同的类别",
                    value=False,
                    help="例如 Private room、private room、Private room  会合并为同一个类别。为避免误改专有名称，默认不自动开启。",
                )

            with template_block("03", "异常数值处理", "先识别可能影响结论的极端值，再选择保留、标记或处理方式。", "amber"):
                handle_nonpositive = st.checkbox(
                    "处理价格、金额、数量字段中明显不合理的 0 或负数",
                    value=True,
                    help="价格/金额/数量等字段中的 0 或负数会先标记为缺失，再按缺失值策略填充；不会删除整行原始记录。",
                )
                outlier_diagnostics = cleaning_outlier_diagnostics(raw_df)
                show_cleaning_outlier_decision_area(outlier_diagnostics)
                outlier_strategy = st.selectbox(
                    "默认极端值处理方式",
                    ["mark", "missing", "winsorize", "none"],
                    format_func={
                        "mark": "只标记，保留原值",
                        "missing": "替换为缺失值",
                        "winsorize": "截尾处理，限制在常见范围内",
                        "none": "暂不处理",
                    }.get,
                    help="没有单独设置的极端值字段会使用这个默认方式。建议先选择“只标记，保留原值”。",
                )
                outlier_strategies_by_column = {}
                if not outlier_diagnostics.empty:
                    with st.expander("按字段设置极端值处理方式", expanded=False):
                        st.caption("只显示当前数据中被诊断出存在极端值的字段。")
                        for _, row in sort_extreme_value_impact(outlier_diagnostics).iterrows():
                            column = row["字段"]
                            label = (
                                f"{display_field(column)}：{row['极端记录数']} 条极端记录，"
                                f"平均值变化 {row['平均值变化幅度']}"
                            )
                            choice = st.selectbox(
                                label,
                                ["default", "mark", "missing", "winsorize", "none"],
                                format_func={
                                    "default": "跟随默认处理方式",
                                    "mark": "只标记，保留原值",
                                    "missing": "替换为缺失值",
                                    "winsorize": "截尾处理，限制在常见范围内",
                                    "none": "暂不处理",
                                }.get,
                                key=f"outlier_strategy_{column}",
                            )
                            if choice != "default":
                                outlier_strategies_by_column[column] = choice

            with template_block("04", "缺失值处理", "决定空缺内容是否填补，以及用哪种方式填补。", "green"):
                numeric_fill = st.selectbox(
                    "数值字段缺失后怎么处理",
                    ["median", "mean", "none"],
                    format_func={"median": "用中位数填补", "mean": "用平均数填补", "none": "暂不填补"}.get,
                )
                category_fill = st.selectbox(
                    "文本或类别字段缺失后怎么处理",
                    ["Unknown", "mode", "none"],
                    format_func={"Unknown": "填为 Unknown", "mode": "用最常见的值填补", "none": "暂不填补"}.get,
                )

            with template_block("05", "字段保留", "决定是否移除缺失过多、很难继续分析的字段。", "slate"):
                drop_high_missing = st.checkbox("删除缺失太多、难以继续分析的字段", value=False)
                high_missing_threshold = st.slider("超过多少缺失比例时删除字段", 0.1, 0.9, 0.6, 0.1)

            submitted = st.form_submit_button("执行清洗")

        if submitted:
            cleaned_df, cleaning_log = clean_table(
                raw_df,
                drop_duplicates=drop_duplicates,
                convert_types=convert_types,
                strip_text=strip_text,
                empty_string_as_missing=empty_string_as_missing,
                standardize_category_values=standardize_category_values,
                handle_nonpositive=handle_nonpositive,
                outlier_strategy=outlier_strategy,
                outlier_strategies_by_column=outlier_strategies_by_column,
                numeric_fill=numeric_fill,
                category_fill=category_fill,
                drop_high_missing=drop_high_missing,
                high_missing_threshold=high_missing_threshold,
            )
            st.session_state["cleaned_df"] = cleaned_df
            st.session_state["cleaning_log"] = cleaning_log
            st.session_state["analysis_source"] = "清洗后数据"
            add_history_event(
                "分析过程",
                "执行清洗",
                data_source="原始数据",
                method="清洗预处理",
                result=f"生成清洗后数据；清洗日志 {len(cleaning_log)} 条。",
                dedupe_key=f"clean|{len(raw_df)}|{len(raw_df.columns)}|{len(cleaning_log)}",
            )
            st.session_state["pending_cleaning_submodule"] = "清洗前后对比"
            st.rerun()

        if "cleaned_df" not in st.session_state:
            st.info("尚未执行清洗。可以保留默认策略，点击“执行清洗”。")
        else:
            st.success("已有清洗结果。你可以在上方功能中查看清洗前后对比和下载预览。")
        return

    if "cleaned_df" not in st.session_state:
        st.info("尚未执行清洗。请先在上方功能中选择“清洗设置”并执行基础清洗。")
        return

    cleaned_df = st.session_state["cleaned_df"]
    cleaning_log = st.session_state["cleaning_log"]

    st.success("清洗完成。原始数据仍然保留，统计可视化和自然语言问答将默认优先使用清洗后数据。")
    if st.button("撤回清洗结果", use_container_width=True):
        st.session_state.pop("cleaned_df", None)
        st.session_state.pop("cleaning_log", None)
        add_history_event(
            "分析过程",
            "撤回清洗结果",
            data_source="清洗后数据",
            method="恢复原始数据",
            result="后续分析将重新使用原始数据。",
            dedupe_key=f"clean_revert|{datetime.now().strftime('%Y%m%d%H%M%S')}",
        )
        st.session_state["analysis_source"] = "原始数据"
        st.session_state["pending_cleaning_submodule"] = "清洗设置"
        st.rerun()

    if submodule == "清洗前后对比":
        show_cleaning_comparison_page(raw_df, cleaned_df, cleaning_log)
    elif submodule == "下载与预览":
        st.download_button(
            "下载清洗后 CSV",
            data=cleaned_df.to_csv(index=False).encode("utf-8-sig"),
            file_name="datamind_cleaned_data.csv",
            mime="text/csv",
            use_container_width=True,
        )
        st.subheader("清洗后数据预览")
        st.dataframe(display_analysis_table(safe_display_table(cleaned_df.head(100))), use_container_width=True)


def show_cleaning_comparison_page(raw_df, cleaned_df, cleaning_log):
    """Render a three-part user-facing cleaning result page."""
    with template_block("01", "清洗前后变化", "先看数据规模、缺失和字段变化，判断清洗是否真的改变了数据。", "blue"):
        st.dataframe(display_analysis_table(cleaning_comparison(raw_df, cleaned_df)), use_container_width=True)

    with template_block("02", "本次执行的清洗", "主体只展示本次清洗带来的效果，具体日志放在折叠框里。", "green"):
        improvements = cleaning_improvement_summary(cleaning_log)
        for item in improvements:
            st.write(f"- {item}")

        action_groups = cleaning_action_groups(cleaning_log)
        with st.expander("查看具体清洗记录", expanded=False):
            for group_name, items in action_groups.items():
                if not items:
                    continue
                st.markdown(f"**{group_name}**")
                for item in items:
                    st.write(f"- {item}")

    with template_block("03", "清洗后分析提醒", "这些提醒会影响后续图表、问答和报告结论的使用方式。", "amber"):
        reminders = cleaning_aftercare_notes(raw_df, cleaned_df)
        for note in reminders:
            st.write(f"- {note}")


def cleaning_improvement_summary(cleaning_log):
    """Summarize cleaning actions by user-facing benefits."""
    summary = []
    if any("重复行" in item for item in cleaning_log):
        summary.append("删除重复记录，避免同一条数据被重复计算。")
    if any("文本格式整理" in item or "空字符串" in item for item in cleaning_log):
        summary.append("整理空白文本和空缺内容，让表格更容易统计。")
    if any("自动转换" in item for item in cleaning_log):
        summary.append("将可计算字段转为数值或日期，方便后续画图和问答。")
    if any("填充" in item or "填补" in item for item in cleaning_log):
        summary.append("补齐部分缺失内容，减少分析时因为空值造成的干扰。")
    if any("极端值" in item or "小于" in item or "0 或负数" in item for item in cleaning_log):
        summary.append("标记或处理异常数值，减少不合理数值对结论的影响。")
    if any("删除缺失比例" in item for item in cleaning_log):
        summary.append("移除缺失过多的字段，让后续分析更集中。")
    if any("类别" in item or "合并" in item for item in cleaning_log):
        summary.append("合并格式差异造成的重复类别，减少分组统计时的混乱。")
    if not summary:
        summary.append("本次没有发现需要明显调整的内容，清洗后数据与原始数据基本一致。")
    return summary


def cleaning_action_groups(cleaning_log):
    """Group raw cleaning logs into user-facing action types."""
    groups = {
        "基础整理": [],
        "字段转换": [],
        "缺失处理": [],
        "异常处理": [],
        "字段保留": [],
    }
    for item in cleaning_log:
        if "文本格式整理" in item or "重复行" in item or "类别" in item or "合并" in item:
            groups["基础整理"].append(item)
        elif "自动转换" in item:
            groups["字段转换"].append(item)
        elif "缺失" in item and "极端值" not in item and "缺失比例" not in item:
            groups["缺失处理"].append(item)
        elif "极端值" in item or "小于" in item or "0 或负数" in item:
            groups["异常处理"].append(item)
        elif "删除缺失比例" in item:
            groups["字段保留"].append(item)
        else:
            groups["基础整理"].append(item)
    return groups


def cleaning_aftercare_notes(raw_df, cleaned_df):
    """Build concise reminders for using cleaned data in later analysis."""
    notes = []
    remaining_missing = cleaned_df.isna().mean()
    remaining_missing = remaining_missing[remaining_missing > 0].sort_values(ascending=False)
    if not remaining_missing.empty:
        fields = [display_field(col) for col in remaining_missing.head(3).index]
        notes.append("这些字段清洗后仍有缺失，做结论时建议谨慎使用：" + "、".join(fields) + "。")

    outlier_mark_columns = [col for col in cleaned_df.columns if str(col).endswith("_是否极端值")]
    if outlier_mark_columns:
        original_fields = [str(col).replace("_是否极端值", "") for col in outlier_mark_columns[:3]]
        notes.append("这些字段新增了极端值标记，后续分析时可以决定是否排除对应记录：" + "、".join(display_field(col) for col in original_fields) + "。")

    field_reminders = cleaning_field_usage_reminders(raw_df, cleaned_df)
    if not field_reminders.empty:
        identifier_rows = field_reminders[field_reminders["使用提醒"].str.contains("编号|链接|唯一标识", na=False)]
        if not identifier_rows.empty:
            fields = [display_field(col) for col in identifier_rows["字段"].head(3)]
            notes.append("这些字段更适合定位记录，不适合直接做均值、相关性等统计：" + "、".join(fields) + "。")

        converted_rows = field_reminders[field_reminders["使用提醒"].str.contains("作为数值使用|作为日期使用", na=False)]
        if not converted_rows.empty:
            fields = [display_field(col) for col in converted_rows["字段"].head(3)]
            notes.append("这些字段清洗后已经更适合继续分析：" + "、".join(fields) + "。")

    if not notes:
        notes.append("当前清洗结果没有发现需要额外提醒的明显问题，可以继续进入统计可视化或自然语言问答。")
    return notes


def extract_first_int(text):
    """Extract the first integer from a log line."""
    match = re.search(r"\d+", str(text))
    return int(match.group(0)) if match else 0


def cleaning_comparison(raw_df, cleaned_df):
    """Build a before/after summary for cleaning results."""
    raw_profile = profile_table(raw_df)
    cleaned_profile = profile_table(cleaned_df)
    raw_missing_columns = sum(v > 0 for v in raw_profile["missing_counts"].values())
    cleaned_missing_columns = sum(v > 0 for v in cleaned_profile["missing_counts"].values())
    raw_missing_rate = raw_df.isna().mean().mean() * 100
    cleaned_missing_rate = cleaned_df.isna().mean().mean() * 100
    rows = [
        (
            "行数",
            raw_profile["rows"],
            cleaned_profile["rows"],
            describe_number_change(cleaned_profile["rows"] - raw_profile["rows"], "行"),
        ),
        (
            "列数",
            raw_profile["columns"],
            cleaned_profile["columns"],
            describe_number_change(cleaned_profile["columns"] - raw_profile["columns"], "列"),
        ),
        (
            "重复行",
            raw_profile["duplicate_rows"],
            cleaned_profile["duplicate_rows"],
            describe_reduction(raw_profile["duplicate_rows"], cleaned_profile["duplicate_rows"], "行"),
        ),
        (
            "有缺失的字段数",
            raw_missing_columns,
            cleaned_missing_columns,
            describe_reduction(raw_missing_columns, cleaned_missing_columns, "个字段"),
        ),
        (
            "平均缺失比例",
            f"{raw_missing_rate:.2f}%",
            f"{cleaned_missing_rate:.2f}%",
            describe_rate_change(raw_missing_rate, cleaned_missing_rate),
        ),
    ]
    return pd.DataFrame(rows, columns=["内容", "清洗前", "清洗后", "变化说明"])


def describe_number_change(delta, unit):
    """Describe a raw count change in user-facing Chinese."""
    if delta > 0:
        return f"增加 {delta} {unit}"
    if delta < 0:
        return f"减少 {abs(delta)} {unit}"
    return "没有变化"


def describe_reduction(before, after, unit):
    """Describe whether a problem count decreased."""
    delta = before - after
    if delta > 0:
        return f"减少 {delta} {unit}"
    if delta < 0:
        return f"增加 {abs(delta)} {unit}"
    return "没有变化"


def describe_rate_change(before, after):
    """Describe percentage point change."""
    delta = after - before
    if delta > 0:
        return f"上升 {delta:.2f} 个百分点"
    if delta < 0:
        return f"下降 {abs(delta):.2f} 个百分点"
    return "没有变化"


def safe_display_table(df):
    """Return a Streamlit-friendly copy for display only."""
    display_df = df.copy()
    for column in display_df.columns:
        if display_df[column].dtype == "object":
            display_df[column] = display_df[column].map(format_display_value)
    return display_df


def format_display_value(value):
    """Format complex values safely for table display."""
    if isinstance(value, (list, dict, tuple, set)):
        return str(value)
    return value


def cleaning_field_usage_reminders(raw_df, cleaned_df):
    """Build user-facing field reminders after cleaning."""
    rows = []
    for column in raw_df.columns:
        if column not in cleaned_df.columns:
            rows.append(
                {
                    "字段": column,
                    "使用提醒": "这个字段已不在清洗后数据中。",
                    "为什么要注意": "它可能缺失比例过高，或被你选择删除。",
                    "后续怎么用": "后续分析中不要再使用它；必要时在说明中解释删除原因。",
                }
            )
            continue

        raw_series = raw_df[column]
        cleaned_series = cleaned_df[column]
        lower_name = str(column).lower()
        raw_missing_rate = float(raw_series.isna().mean() * 100)

        if raw_missing_rate >= 40:
            rows.append(
                {
                    "字段": column,
                    "使用提醒": f"这个字段原始缺失率较高（{raw_missing_rate:.2f}%）。",
                    "为什么要注意": "缺失太多会影响统计结果的代表性。",
                    "后续怎么用": "可以辅助参考，但不建议单独作为核心结论依据。",
                }
            )

        if raw_series.dtype == "object" and pd.api.types.is_numeric_dtype(cleaned_series):
            rows.append(
                {
                    "字段": column,
                    "使用提醒": "这个字段清洗后已经可以作为数值使用。",
                    "为什么要注意": "它原来像文本，清洗后才能参与计算。",
                    "后续怎么用": "可以用于数值分布、分组统计、相关性等分析。",
                }
            )

        if raw_series.dtype == "object" and pd.api.types.is_datetime64_any_dtype(cleaned_series):
            rows.append(
                {
                    "字段": column,
                    "使用提醒": "这个字段清洗后已经可以作为日期使用。",
                    "为什么要注意": "日期格式统一后，才能稳定做时间相关分析。",
                    "后续怎么用": "可以用于趋势分析、时间范围判断或按时间分组。",
                }
            )

        if is_identifier_field(lower_name, raw_series, int(raw_series.nunique(dropna=True))):
            rows.append(
                {
                    "字段": column,
                    "使用提醒": "这个字段更像编号、链接或唯一标识。",
                    "为什么要注意": "它通常用于定位某条记录，不代表可以比较的指标。",
                    "后续怎么用": "可以保留用于查找记录，但不建议作为主要统计分析字段。",
                }
            )

        if pd.api.types.is_numeric_dtype(cleaned_series):
            rule = nonpositive_cleaning_rule(lower_name)
            if rule:
                invalid_count = int((pd.to_numeric(raw_series, errors="coerce") <= 0).sum())
                if invalid_count:
                    rows.append(
                        {
                            "字段": column,
                            "使用提醒": f"这个字段中有 {invalid_count} 个 0 或负数已被处理。",
                            "为什么要注意": "价格或数量字段中的 0/负数可能会拉偏平均值或分组结果。",
                            "后续怎么用": "可以继续分析，但解释结果时要说明系统已按缺失值策略处理这些值。",
                        }
                    )

    return pd.DataFrame(rows).drop_duplicates() if rows else pd.DataFrame()


def nonpositive_cleaning_rule(name):
    """Return whether a field is treated as price/quantity for cleaning suggestions."""
    safe_zero_tokens = ["availability", "review", "rating", "score", "rate", "count_reviews"]
    if any(token in name for token in safe_zero_tokens):
        return False
    tokens = [
        "price",
        "cost",
        "fee",
        "amount",
        "revenue",
        "sales",
        "unitprice",
        "quantity",
        "qty",
        "number",
        "nights",
        "beds",
        "bedrooms",
        "bathrooms",
        "accommodates",
    ]
    return any(token in name for token in tokens)


def show_extreme_value_impact(cleaned_df, submodule="发现了什么"):
    """Show a three-step extreme value impact workflow."""
    if submodule not in CLEANING_OUTLIER_SUBMODULES:
        submodule = "发现了什么"
    section("极端值影响", "先识别极端值，再判断它们是否影响平均值和结论，最后给出处理和写作建议。")
    impact = extreme_value_impact_table(cleaned_df)
    result_summary = "未发现明显极端值影响。"
    if not impact.empty:
        strongest = impact.sort_values("平均值变化数值", ascending=False).iloc[0]
        result_summary = f"{strongest['字段']} 平均值变化约 {strongest['平均值变化幅度']}。"
    add_history_event(
        "分析过程",
        f"查看极端值影响 - {submodule}",
        data_source="清洗后数据",
        method="IQR 极端值识别 + 平均值影响对比",
        result=result_summary,
        dedupe_key=f"outlier_impact|{submodule}|{result_summary}",
    )
    if submodule == "发现了什么":
        show_extreme_value_reminders(cleaned_df)
    elif submodule == "影响了什么":
        show_extreme_value_mean_impact(cleaned_df)
    elif submodule == "怎么处理":
        show_extreme_value_actions(cleaned_df)


def show_extreme_value_reminders(cleaned_df):
    """Show user-facing extreme value reminders without deleting data."""
    outliers = quality_report(cleaned_df)["outlier_summary"]
    if outliers.empty:
        st.success("当前未发现明显极端值风险。系统不会自动删除任何记录。")
        return

    st.info("以下字段存在极端值风险。它们不一定是错误，但可能影响平均值、图表比例和分组比较。系统不会自动删除这些记录。")
    rows = []
    for _, row in outliers.iterrows():
        rows.append(
            {
                "字段": row["column"],
                "发现了什么": f"约 {row['outlier_count']} 条记录偏离常见范围，占 {row['outlier_rate_%']}%。",
                "可能影响": "平均值、分组对比和图表显示可能被极端值拉偏。",
                "建议怎么用": "建议后续查看箱线图，或同时参考中位数；写结论时说明存在极端值影响。",
                "是否已删除": "未删除，仅提醒",
            }
        )
    st.dataframe(display_analysis_table(pd.DataFrame(rows)), use_container_width=True)


def show_extreme_value_mean_impact(cleaned_df):
    """Show how outliers affect mean-based conclusions."""
    impact = extreme_value_impact_table(cleaned_df)
    if impact.empty:
        st.success("当前没有发现会明显影响平均值的极端值字段。")
        return
    st.info("这里比较“全部数据平均值”和“暂时排除极端值后的平均值”。系统不会自动删除这些记录，只帮助判断结论是否容易被拉偏。")
    st.dataframe(display_analysis_table(display_extreme_value_impact_table(impact)), use_container_width=True)


def show_extreme_value_actions(cleaned_df):
    """Show actionable outlier records and report wording."""
    impact = extreme_value_impact_table(cleaned_df)
    if impact.empty:
        st.success("当前没有需要单独处理的极端值记录。")
        return
    selected_column = st.selectbox("选择字段查看极端记录", impact["字段"].tolist(), format_func=display_field)
    records = extreme_value_records(cleaned_df, selected_column)
    st.write("这些记录偏离常见范围，建议人工检查；系统不会自动删除。")
    st.dataframe(display_analysis_table(records), use_container_width=True)
    st.download_button(
        "下载该字段极端记录",
        records.to_csv(index=False).encode("utf-8-sig"),
        file_name=f"datamind_outliers_{selected_column}.csv",
        mime="text/csv",
        use_container_width=True,
    )
    st.markdown("**可写进报告的说明**")
    st.write(extreme_value_report_text(impact, selected_column))


def extreme_value_impact_table(df):
    """Return a user-facing table describing outlier impact."""
    rows = []
    for column in analysis_numeric_columns(df, list(df.select_dtypes(include="number").columns)):
        series = pd.to_numeric(df[column], errors="coerce").dropna()
        if len(series) < 4:
            continue
        mask, lower, upper = iqr_outlier_mask(series)
        outlier_count = int(mask.sum())
        if outlier_count == 0:
            continue
        raw_mean = float(series.mean())
        trimmed = series[~mask]
        if trimmed.empty:
            continue
        trimmed_mean = float(trimmed.mean())
        change_rate = abs(raw_mean - trimmed_mean) / (abs(raw_mean) if raw_mean else 1) * 100
        if change_rate < 1:
            suggestion = "影响较小，报告中简单说明即可。"
        elif change_rate < 10:
            suggestion = "有一定影响，建议同时参考中位数。"
        else:
            suggestion = "影响明显，写结论时应说明极端值可能拉偏平均值。"
        rows.append(
            {
                "字段": column,
                "极端记录数": outlier_count,
                "极端记录比例": f"{outlier_count / len(series) * 100:.2f}%",
                "全部数据平均值": format_number(raw_mean),
                "去极端值后平均值": format_number(trimmed_mean),
                "平均值变化幅度": f"{change_rate:.2f}%",
                "平均值变化数值": change_rate,
                "常见范围": f"{format_number(lower)} - {format_number(upper)}",
                "建议": suggestion,
            }
        )
    return sort_extreme_value_impact(pd.DataFrame(rows))


def sort_extreme_value_impact(impact):
    """Sort outlier impact rows from the most decision-relevant field downward."""
    if impact.empty:
        return impact
    sort_columns = []
    ascending = []
    if "平均值变化数值" in impact.columns:
        sort_columns.append("平均值变化数值")
        ascending.append(False)
    if "极端记录数" in impact.columns:
        sort_columns.append("极端记录数")
        ascending.append(False)
    if not sort_columns:
        return impact
    return impact.sort_values(sort_columns, ascending=ascending).reset_index(drop=True)


def display_extreme_value_impact_table(impact):
    """Hide internal helper columns before displaying impact data."""
    if impact.empty:
        return impact
    return impact.drop(columns=["平均值变化数值"], errors="ignore")


def iqr_outlier_mask(series):
    """Return IQR outlier mask and bounds for a numeric series."""
    q1 = series.quantile(0.25)
    q3 = series.quantile(0.75)
    iqr = q3 - q1
    lower = q1 - 1.5 * iqr
    upper = q3 + 1.5 * iqr
    return (series < lower) | (series > upper), lower, upper


def extreme_value_records(df, column, limit=100):
    """Return rows with IQR outliers for one column."""
    series = pd.to_numeric(df[column], errors="coerce")
    clean_series = series.dropna()
    if clean_series.empty:
        return pd.DataFrame()
    mask, lower, upper = iqr_outlier_mask(clean_series)
    outlier_index = clean_series[mask].index
    records = df.loc[outlier_index].copy()
    records.insert(0, "极端字段", column)
    records.insert(1, "极端值", series.loc[outlier_index].values)
    records.insert(2, "常见范围", f"{format_number(lower)} - {format_number(upper)}")
    return safe_display_table(records.head(limit))


def extreme_value_report_text(impact, column):
    """Build report wording for one outlier field."""
    row = impact.loc[impact["字段"] == column].iloc[0]
    return (
        f"字段“{column}”存在 {row['极端记录数']} 条极端记录，占 {row['极端记录比例']}。"
        f"全部数据平均值为 {row['全部数据平均值']}，暂时排除极端值后的平均值为 {row['去极端值后平均值']}，"
        f"变化幅度约 {row['平均值变化幅度']}。因此在解释该字段时，建议同时参考中位数，并说明极端值可能影响平均值。"
    )


def render_sidebar(uploaded_file, raw_df=None):
    """Render sidebar title, intro, and file upload."""
    with st.sidebar:
        st.markdown(
            """
            <div class="dm-sidebar-brand">
            <p class="dm-sidebar-title">DataMind</p>
            <p class="dm-sidebar-intro">
                面向非技术学生的表格数据分析助手。按流程完成分析、解释、报告和记录回看。
            </p>
            </div>
            """,
            unsafe_allow_html=True,
        )
        st.divider()

        data_source = st.radio("数据来源", ["上传文件", "内置示例数据"], horizontal=True)
        if data_source == "上传文件":
            uploaded_file = st.file_uploader(
                "上传 CSV 或 Excel 文件",
                type=["csv", "xlsx", "xls"],
            )
            return uploaded_file, None

        st.caption("示例数据：Airbnb listings.csv")
        if not SAMPLE_DATASET_PATH.exists():
            st.error("示例数据文件不存在。")
            return None, None
        return SAMPLE_DATASET_PATH, None


def render_module_nav():
    """Render module navigation buttons after data is uploaded."""
    with st.sidebar:
        st.divider()
        if "selected_module" not in st.session_state:
            st.session_state["selected_module"] = None
        if "profile_submodule" not in st.session_state:
            st.session_state["profile_submodule"] = PROFILE_SUBMODULES[0]
        if "cleaning_submodule" not in st.session_state:
            st.session_state["cleaning_submodule"] = CLEANING_SUBMODULES[0]
        if "cleaning_outlier_submodule" not in st.session_state:
            st.session_state["cleaning_outlier_submodule"] = CLEANING_OUTLIER_SUBMODULES[0]
        if "visualization_section" not in st.session_state:
            st.session_state["visualization_section"] = VISUALIZATION_SECTIONS[0]
        if "visualization_submodule" not in st.session_state:
            st.session_state["visualization_submodule"] = VISUALIZATION_SUBMODULES[0]
        if "qa_submodule" not in st.session_state:
            st.session_state["qa_submodule"] = QA_SUBMODULES[0]
        if "history_submodule" not in st.session_state:
            st.session_state["history_submodule"] = HISTORY_SUBMODULES[0]
        if "report_submodule" not in st.session_state:
            st.session_state["report_submodule"] = REPORT_SUBMODULES[0]

        st.markdown('<p class="dm-sidebar-label">功能模块</p>', unsafe_allow_html=True)
        if st.session_state["selected_module"] is not None:
            st.caption(f"当前栏目：{st.session_state['selected_module']}")
        for module_name in MODULES:
            button_type = "primary" if st.session_state["selected_module"] == module_name else "secondary"
            if st.button(module_name, key=f"module_nav_{module_name}", type=button_type, use_container_width=True):
                st.session_state["selected_module"] = module_name
                if module_name == "数据概览":
                    st.session_state["profile_submodule"] = PROFILE_SUBMODULES[0]
                elif module_name == "清洗预处理":
                    st.session_state["cleaning_submodule"] = "清洗设置"
                elif module_name == "统计可视化":
                    st.session_state["visualization_section"] = VISUALIZATION_SECTIONS[0]
                    st.session_state["visualization_submodule"] = VISUALIZATION_SUBMODULES[0]
                elif module_name == "自然语言问答":
                    st.session_state["qa_submodule"] = QA_SUBMODULES[0]
                elif module_name == "分析历史":
                    st.session_state["history_submodule"] = HISTORY_SUBMODULES[0]
                elif module_name == "分析报告":
                    st.session_state["report_submodule"] = REPORT_SUBMODULES[0]
                st.rerun()

        render_sidebar_submodule_nav(st.session_state["selected_module"])
        return st.session_state["selected_module"]


def render_sidebar_submodule_nav(module):
    """Render second-level navigation in the sidebar."""
    if not module:
        st.session_state["profile_submodule"] = PROFILE_SUBMODULES[0]
        return

    title, note = submodule_nav_heading(module)
    st.markdown('<p class="dm-sidebar-label">当前模块功能</p>', unsafe_allow_html=True)
    st.markdown(f'<p class="dm-sidebar-tip">{html.escape(note)}</p>', unsafe_allow_html=True)

    if module == "数据概览":
        if st.session_state.get("profile_submodule") not in PROFILE_SUBMODULES:
            st.session_state["profile_submodule"] = PROFILE_SUBMODULES[0]
        st.radio(
            "概览功能",
            PROFILE_SUBMODULES,
            label_visibility="collapsed",
            key="profile_submodule",
        )

    elif module == "清洗预处理":
        cleaning_options = normalize_cleaning_submodule()
        st.radio(
            "清洗功能",
            cleaning_options,
            label_visibility="collapsed",
            key="cleaning_submodule",
        )
        if st.session_state["cleaning_submodule"] == "极端值影响":
            if st.session_state["cleaning_outlier_submodule"] not in CLEANING_OUTLIER_SUBMODULES:
                st.session_state["cleaning_outlier_submodule"] = CLEANING_OUTLIER_SUBMODULES[0]
            st.radio(
                "极端值影响分类",
                CLEANING_OUTLIER_SUBMODULES,
                key="cleaning_outlier_submodule",
            )

    elif module == "统计可视化":
        normalize_visualization_submodule()
        st.radio(
            "选择分析方式",
            VISUALIZATION_SECTIONS,
            key="visualization_section",
        )
        normalize_visualization_submodule()
        if st.session_state["visualization_section"] == "AI 需求作图":
            st.session_state["visualization_submodule"] = "AI 需求作图"
        elif st.session_state["visualization_section"] == "基础图表分析":
            st.radio(
                "选择具体图表",
                VISUALIZATION_CHART_SUBMODULES,
                format_func=lambda item: VISUALIZATION_DISPLAY_LABELS.get(item, item),
                key="visualization_submodule",
            )
        else:
            st.radio(
                "选择高级分析",
                VISUALIZATION_ADVANCED_SUBMODULES,
                format_func=lambda item: VISUALIZATION_DISPLAY_LABELS.get(item, item),
                key="visualization_submodule",
            )

    elif module == "自然语言问答":
        normalize_qa_submodule()
        st.radio(
            "问答功能",
            QA_SUBMODULES,
            label_visibility="collapsed",
            key="qa_submodule",
        )

    elif module == "分析报告":
        if st.session_state["report_submodule"] not in REPORT_SUBMODULES:
            st.session_state["report_submodule"] = REPORT_SUBMODULES[0]
        st.radio(
            "报告功能",
            REPORT_SUBMODULES,
            label_visibility="collapsed",
            key="report_submodule",
        )

    elif module == "分析历史":
        if st.session_state["history_submodule"] not in HISTORY_SUBMODULES:
            st.session_state["history_submodule"] = HISTORY_SUBMODULES[0]
        st.radio(
            "历史记录",
            HISTORY_SUBMODULES,
            label_visibility="collapsed",
            key="history_submodule",
        )


def show_module_landing(raw_df):
    """Show a neutral landing page before a module is selected."""
    profile = profile_table(raw_df)
    section("数据已读取", "从左侧选择模块开始分析，也可以先根据下面的工作流了解每个模块的作用。")

    metric_cols = st.columns(4)
    metric_cols[0].metric("行数", profile["rows"])
    metric_cols[1].metric("列数", profile["columns"])
    metric_cols[2].metric("重复行", profile["duplicate_rows"])
    metric_cols[3].metric("有缺失的列数", sum(v > 0 for v in profile["missing_counts"].values()))

    cards = []
    for module_name, config in MODULES.items():
        cards.append(
            f'<div class="dm-module-card">'
            f'<p class="dm-module-card-title">{html.escape(module_name)}</p>'
            f'<p class="dm-module-card-text">{html.escape(config["hint"])}</p>'
            f"</div>"
        )
    st.markdown(
        '<div class="dm-module-grid">' + "\n".join(cards) + "</div>",
        unsafe_allow_html=True,
    )


def get_dataset_identity(source):
    """Return a stable identity used to reset state when the dataset changes."""
    if isinstance(source, Path):
        return f"sample:{source.resolve()}"
    return f"upload:{getattr(source, 'name', 'unknown')}:{getattr(source, 'size', 'unknown')}"


def reset_dataset_state_if_needed(source):
    """Clear derived state when switching datasets."""
    identity = get_dataset_identity(source)
    if st.session_state.get("active_dataset_identity") == identity:
        return

    st.session_state["active_dataset_identity"] = identity
    st.session_state.pop("cleaned_df", None)
    st.session_state.pop("cleaning_log", None)
    st.session_state.pop("cluster_result", None)
    st.session_state.pop("cluster_fields", None)
    st.session_state.pop("cluster_k", None)
    st.session_state.pop("cluster_labeled_df", None)
    st.session_state.pop("cluster_label_column", None)
    st.session_state.pop("cluster_result_just_generated", None)
    st.session_state.pop("ai_chart_instruction", None)
    st.session_state.pop("ai_chart_status", None)
    st.session_state.pop("ai_chart_result", None)
    st.session_state.pop("ai_chart_result_just_generated", None)
    st.session_state["selected_module"] = None
    st.session_state["analysis_source"] = "原始数据"
    st.session_state["profile_submodule"] = PROFILE_SUBMODULES[0]
    st.session_state["cleaning_submodule"] = CLEANING_SUBMODULES[0]
    st.session_state["cleaning_outlier_submodule"] = CLEANING_OUTLIER_SUBMODULES[0]
    st.session_state["visualization_section"] = VISUALIZATION_SECTIONS[0]
    st.session_state["visualization_submodule"] = VISUALIZATION_SUBMODULES[0]
    st.session_state["qa_submodule"] = QA_SUBMODULES[0]
    st.session_state["history_submodule"] = HISTORY_SUBMODULES[0]
    st.session_state["report_submodule"] = REPORT_SUBMODULES[0]
    st.session_state["field_translation_cache"] = {}
    st.session_state["value_translation_cache"] = {}
    st.session_state["dataset_subject_cache"] = {}
    st.session_state["analysis_direction_cache"] = {}
    st.session_state["question_recommendation_cache"] = {}
    st.session_state["chart_field_recommendation_cache"] = {}
    st.session_state["chart_result_cache"] = {}
    st.session_state["report_result_cache"] = {}
    st.session_state["conclusion_check_cache"] = {}
    for key in list(st.session_state.keys()):
        if str(key).startswith("prepared_download_"):
            st.session_state.pop(key, None)
    st.session_state["analysis_history"] = []
    st.session_state["history_signatures"] = set()
    add_history_event(
        "分析过程",
        "加载数据集",
        data_source=identity,
        method="数据读取",
        result="已切换到新的数据源，历史记录已重新开始。",
        dedupe_key=f"dataset|{identity}",
    )


def main():
    """Run the DataMind app."""
    apply_theme()

    uploaded_file, _ = render_sidebar(None)

    if uploaded_file is None:
        hero()
        section("开始使用", "先在左侧上传 CSV/Excel，或选择内置示例数据体验完整分析流程。")
        st.markdown(
            '<div class="dm-module-grid">'
            '<div class="dm-module-card"><p class="dm-module-card-title">1. 读取数据</p>'
            '<p class="dm-module-card-text">上传表格或加载示例数据，系统会识别行列规模、字段类型和数据质量。</p></div>'
            '<div class="dm-module-card"><p class="dm-module-card-title">2. 探索分析</p>'
            '<p class="dm-module-card-text">按流程完成清洗、图表、自然语言问答、报告整理和高级分析。</p></div>'
            '<div class="dm-module-card"><p class="dm-module-card-title">3. 生成成果</p>'
            '<p class="dm-module-card-text">导出报告、清洗数据、分析历史和关键结果表。</p></div>'
            "</div>",
            unsafe_allow_html=True,
        )
        return

    reset_dataset_state_if_needed(uploaded_file)

    try:
        raw_df = read_table(uploaded_file)
    except DataLoadError as exc:
        st.error(str(exc))
        return
    add_history_event(
        "分析过程",
        "读取表格数据",
        data_source=get_dataset_identity(uploaded_file),
        method="CSV/Excel 读取",
        result=f"{len(raw_df)} 行，{len(raw_df.columns)} 列。",
        dedupe_key=f"read|{get_dataset_identity(uploaded_file)}|{len(raw_df)}|{len(raw_df.columns)}",
    )
    prepare_field_translations(raw_df.columns)

    module = render_module_nav()

    st.markdown('<div class="dm-module-body">', unsafe_allow_html=True)
    if module is None:
        show_module_landing(raw_df)
    elif module == "数据概览":
        show_profile(raw_df, st.session_state.get("profile_submodule", PROFILE_SUBMODULES[0]))
    elif module == "清洗预处理":
        show_cleaning_panel(raw_df, st.session_state.get("cleaning_submodule", CLEANING_SUBMODULES[0]))
    elif module == "统计可视化":
        analysis_df, source_name = get_analysis_df(raw_df)
        show_analysis_panel(analysis_df, st.session_state.get("visualization_submodule", VISUALIZATION_CHART_SUBMODULES[0]))
    elif module == "自然语言问答":
        analysis_df, source_name = get_analysis_df(raw_df)
        show_qa_panel(analysis_df, st.session_state.get("qa_submodule", QA_SUBMODULES[0]))
    elif module == "分析报告":
        show_report_panel(raw_df, st.session_state.get("report_submodule", REPORT_SUBMODULES[0]))
    elif module == "分析历史":
        show_history_panel(st.session_state.get("history_submodule", HISTORY_SUBMODULES[0]))
    st.markdown("</div>", unsafe_allow_html=True)


main()
