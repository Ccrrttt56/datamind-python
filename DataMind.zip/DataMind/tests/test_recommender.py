"""Tests for question and chart recommendations.

Source: Student + AI
"""

import pandas as pd

from modules import recommender
from modules.recommender import (
    add_missing_instructions,
    build_ai_question_payload,
    filter_ai_direction_rows,
    filter_ai_question_rows,
    recommend_analysis_directions,
    recommend_charts,
    recommend_questions,
    recommendation_status,
)


def make_recommendation_df():
    return pd.DataFrame(
        {
            "last_scraped": pd.to_datetime(["2026-01-01", "2026-02-01", "2026-03-01"]),
            "neighbourhood_cleansed": ["A", "B", "A"],
            "room_type": ["Entire", "Private", "Entire"],
            "price": [100, 120, 90],
            "review_scores_rating": [4.5, 4.8, 4.2],
            "description": ["Nice flat", "Central room", "Quiet apartment"],
        }
    )


def test_recommend_questions_returns_core_questions(monkeypatch):
    monkeypatch.setenv("DATAMIND_AI_ENABLED", "false")
    df = make_recommendation_df()

    questions = recommend_questions(df)

    assert not questions.empty
    assert "question" in questions.columns
    assert "source" in questions.columns
    assert "priority" in questions.columns
    assert set(questions["source"]) == {"本地规则"}
    assert recommendation_status()["used_ai"] is False
    assert any("room_type" in question and "price" in question for question in questions["question"])
    assert any("neighbourhood_cleansed" in question and "price" in question for question in questions["question"])
    assert any("相关性" in question for question in questions["question"])
    assert set(questions.head(2)["priority"]) == {"优先"}


def test_ai_question_provider_is_reserved_without_fake_results(monkeypatch):
    monkeypatch.setenv("DATAMIND_AI_ENABLED", "false")
    df = make_recommendation_df()

    questions = recommend_questions(df, provider="ai")

    assert questions.empty
    assert {"question", "reason", "method", "priority", "source", "instruction"}.issubset(questions.columns)
    assert recommendation_status()["provider"] == "ai"


def test_ai_question_payload_uses_safe_summary(monkeypatch):
    df = make_recommendation_df()

    payload = build_ai_question_payload(df)

    assert payload["row_count"] == len(df)
    assert payload["column_count"] == len(df.columns)
    assert "fields" in payload
    assert "allowed_skill_ids" in payload
    assert "sample_values" not in payload


def test_filter_ai_question_rows_rejects_unknown_fields_and_skills():
    df = make_recommendation_df()
    rows = [
        {
            "question": "不同 room_type 的 price 平均值有什么差异？",
            "reason": "适合比较房型价格。",
            "method": "分组聚合分析",
            "priority": "优先",
            "skill_id": "groupby_agg",
            "fields": ["room_type", "price"],
        },
        {
            "question": "不存在字段的问题",
            "reason": "无效。",
            "method": "分组聚合分析",
            "priority": "优先",
            "skill_id": "groupby_agg",
            "fields": ["fake_column"],
        },
        {
            "question": "运行代码",
            "reason": "无效。",
            "method": "执行代码",
            "priority": "优先",
            "skill_id": "run_python",
            "fields": [],
        },
    ]

    filtered = filter_ai_question_rows(rows, df)

    assert len(filtered) == 1
    assert filtered[0]["source"] == "AI 推荐 + 本地校验"
    assert filtered[0]["instruction"]["intent"] == "groupby_agg"
    assert filtered[0]["instruction"]["group_column"] == "room_type"
    assert filtered[0]["instruction"]["value_column"] == "price"


def test_filter_ai_question_rows_completes_missing_fields_from_question_text():
    df = make_recommendation_df()
    rows = [
        {
            "question": "涓嶅悓 room_type 鐨?price 骞冲潎鍊兼湁浠€涔堝樊寮傦紵",
            "reason": "AI 漏掉了数值字段。",
            "method": "鍒嗙粍鑱氬悎鍒嗘瀽",
            "priority": "浼樺厛",
            "skill_id": "groupby_agg",
            "fields": ["room_type"],
        }
    ]

    filtered = filter_ai_question_rows(rows, df)

    assert len(filtered) == 1
    assert filtered[0]["instruction"]["group_column"] == "room_type"
    assert filtered[0]["instruction"]["value_column"] == "price"


def test_filter_ai_question_rows_assigns_fields_by_skill_role_not_order():
    df = make_recommendation_df()
    rows = [
        {
            "question": "涓嶅悓 room_type 鐨?price 骞冲潎鍊兼湁浠€涔堝樊寮傦紵",
            "reason": "AI 返回字段顺序反了。",
            "method": "鍒嗙粍鑱氬悎鍒嗘瀽",
            "priority": "浼樺厛",
            "skill_id": "groupby_agg",
            "fields": ["price", "room_type"],
        }
    ]

    filtered = filter_ai_question_rows(rows, df)

    assert len(filtered) == 1
    assert filtered[0]["instruction"]["group_column"] == "room_type"
    assert filtered[0]["instruction"]["value_column"] == "price"


def test_filter_ai_question_rows_filters_high_missing_after_field_completion():
    df = make_recommendation_df()
    df["price"] = [None, None, None]
    rows = [
        {
            "question": "涓嶅悓 room_type 鐨?price 骞冲潎鍊兼湁浠€涔堝樊寮傦紵",
            "reason": "price 全空时不应推荐。",
            "method": "鍒嗙粍鑱氬悎鍒嗘瀽",
            "priority": "浼樺厛",
            "skill_id": "groupby_agg",
            "fields": ["room_type"],
        }
    ]

    filtered = filter_ai_question_rows(rows, df)

    assert filtered == []


def test_ai_question_provider_uses_ai_when_enabled(monkeypatch):
    df = make_recommendation_df()
    monkeypatch.setattr(recommender, "ai_status", lambda: {"can_call": True})
    captured = {}

    def fake_request(prompt, schema):
        captured["prompt"] = prompt
        return (
            {
                "questions": [
                    {
                        "question": "不同 room_type 的 price 平均值有什么差异？",
                        "reason": "适合比较房型价格。",
                        "method": "分组聚合分析",
                        "priority": "优先",
                        "skill_id": "groupby_agg",
                        "fields": ["room_type", "price"],
                    }
                ]
            },
            None,
        )

    monkeypatch.setattr(
        recommender,
        "request_structured_json",
        fake_request,
    )

    questions = recommend_questions(df, provider="ai")

    assert not questions.empty
    assert set(questions["source"]) == {"AI 推荐 + 本地校验"}
    assert questions.iloc[0]["instruction"]["intent"] == "groupby_agg"
    assert recommendation_status()["used_ai"] is True
    assert "不要都是 Top N" in captured["prompt"]
    assert "涉及字段也要尽量多样" in captured["prompt"]
    assert "值得用户进一步研究" in captured["prompt"]


def test_auto_provider_falls_back_when_ai_returns_invalid_rows(monkeypatch):
    df = make_recommendation_df()
    monkeypatch.setattr(recommender, "ai_status", lambda: {"can_call": True})
    monkeypatch.setattr(
        recommender,
        "request_structured_json",
        lambda prompt, schema: (
            {
                "questions": [
                    {
                        "question": "不存在字段的问题",
                        "reason": "无效。",
                        "method": "分组聚合分析",
                        "priority": "优先",
                        "skill_id": "groupby_agg",
                        "fields": ["fake_column"],
                    }
                ]
            },
            None,
        ),
    )

    questions = recommend_questions(df, provider="auto")

    assert not questions.empty
    assert set(questions["source"]) == {"本地规则"}
    assert recommendation_status()["fallback"] is True


def test_incomplete_ai_instruction_is_repaired_from_question_text():
    df = make_recommendation_df()
    questions = pd.DataFrame(
        [
            {
                "question": "不同房型（room_type）的房源数量分布如何？",
                "reason": "查看房型数量分布。",
                "method": "分组聚合分析",
                "priority": "优先",
                "source": "AI 推荐 + 本地校验",
                "instruction": {"intent": "groupby_agg"},
            }
        ]
    )

    repaired = add_missing_instructions(questions, df)

    assert repaired.iloc[0]["instruction"]["intent"] == "groupby_count"
    assert repaired.iloc[0]["instruction"]["group_column"] == "room_type"


def test_recommend_charts_returns_chart_types():
    df = make_recommendation_df()

    charts = recommend_charts(df)

    assert not charts.empty
    assert {"chart", "fields", "reason", "priority"}.issubset(charts.columns)
    assert "柱状图" in set(charts["chart"])
    assert "折线图" in set(charts["chart"])


def test_filter_ai_direction_rows_requires_known_fields_and_whitelisted_entry():
    df = make_recommendation_df()
    rows = [
        {
            "title": "比较不同房型的价格差异",
            "reason": "房型和价格字段同时存在，适合做分组对比。",
            "entry": "统计可视化 → 基础图表分析 → 分组对比",
            "fields": ["room_type", "price"],
            "output": "分组对比图和结论。",
        },
        {
            "title": "预测价格",
            "reason": "无效入口。",
            "entry": "高级预测建模 → 随机森林分析",
            "fields": ["price"],
            "output": "预测结果。",
        },
        {
            "title": "比较不存在字段",
            "reason": "无效字段。",
            "entry": "统计可视化 → 基础图表分析 → 分组对比",
            "fields": ["fake_column"],
            "output": "结果。",
        },
    ]

    filtered = filter_ai_direction_rows(rows, df)

    assert len(filtered) == 1
    assert filtered[0]["入口"] == "统计可视化 → 基础图表分析 → 分组对比"
    assert filtered[0]["字段"] == ["room_type", "price"]


def test_filter_ai_direction_rows_rejects_high_missing_fields():
    df = make_recommendation_df()
    df["price"] = [None, None, None]
    rows = [
        {
            "title": "比较不同房型的价格差异",
            "reason": "price 全空时不应作为推荐分析方向。",
            "entry": "统计可视化 → 基础图表分析 → 分组对比",
            "fields": ["room_type", "price"],
            "output": "分组对比图。",
        }
    ]

    filtered = filter_ai_direction_rows(rows, df)

    assert filtered == []


def test_filter_ai_direction_rows_rejects_high_missing_fields_mentioned_in_text():
    df = make_recommendation_df()
    df["mostly_empty_metric"] = [None, None, None]
    rows = [
        {
            "title": "分析房型和可容纳人数",
            "reason": "不要把 mostly_empty_metric 的缺失处理过程展示给用户，只应推荐可用字段。",
            "entry": "统计可视化 → 基础图表分析 → 分组对比",
            "fields": ["room_type", "accommodates"],
            "output": "分组对比图。",
        }
    ]

    filtered = filter_ai_direction_rows(rows, df)

    assert filtered == []


def test_filter_ai_direction_rows_dedupes_same_entry():
    df = make_recommendation_df()
    rows = [
        {
            "title": "比较不同房型的价格差异",
            "reason": "适合做分组对比。",
            "entry": "统计可视化 → 基础图表分析 → 分组对比",
            "fields": ["room_type", "price"],
            "output": "分组对比图。",
        },
        {
            "title": "比较不同区域的价格差异",
            "reason": "也是分组对比。",
            "entry": "统计可视化 → 基础图表分析 → 分组对比",
            "fields": ["neighbourhood_cleansed", "price"],
            "output": "分组对比图。",
        },
    ]

    filtered = filter_ai_direction_rows(rows, df)

    assert len(filtered) == 1
    assert filtered[0]["字段"] == ["room_type", "price"]


def test_recommend_analysis_directions_uses_ai_when_enabled(monkeypatch):
    df = make_recommendation_df()
    monkeypatch.setattr(recommender, "ai_status", lambda: {"can_call": True})
    captured = {}

    def fake_request(prompt, schema):
        captured["prompt"] = prompt
        return (
            {
                "directions": [
                    {
                        "title": "比较不同房型的价格差异",
                        "reason": "房型和价格字段同时存在，适合做分组对比。",
                        "entry": "统计可视化 → 基础图表分析 → 分组对比",
                        "fields": ["room_type", "price"],
                        "output": "分组对比图和结论。",
                    }
                ]
            },
            None,
        )

    monkeypatch.setattr(
        recommender,
        "request_structured_json",
        fake_request,
    )

    directions = recommend_analysis_directions(df, provider="ai")

    assert directions
    assert directions[0]["来源"] == "AI 推荐 + 本地校验"
    assert directions[0]["入口"] == "统计可视化 → 基础图表分析 → 分组对比"
    assert "面向用户" in captured["prompt"] or "普通用户" in captured["prompt"]
    assert "不要写内部实现" in captured["prompt"]
    assert "不要解释某个字段为什么没有使用" in captured["prompt"]
    assert "值得研究" in captured["prompt"]
    assert "不同侧重" in captured["prompt"]
    assert "不同分析方法" in captured["prompt"]


def test_recommend_analysis_directions_auto_falls_back_to_empty_for_local_route(monkeypatch):
    df = make_recommendation_df()
    monkeypatch.setattr(recommender, "ai_status", lambda: {"can_call": True})
    monkeypatch.setattr(
        recommender,
        "request_structured_json",
        lambda prompt, schema: ({"directions": [{"title": "无效", "reason": "无效", "entry": "不存在", "fields": [], "output": ""}]}, None),
    )

    directions = recommend_analysis_directions(df, provider="auto")

    assert directions == []
    assert recommender.analysis_direction_status()["fallback"] is True
