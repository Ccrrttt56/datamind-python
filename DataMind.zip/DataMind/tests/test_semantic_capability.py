"""Tests for semantic and capability detection.

Source: Student + AI
"""

import pandas as pd

from modules.capability_detector import detect_capabilities
from modules.semantic_detector import detect_field_semantics


def make_listing_like_df():
    return pd.DataFrame(
        {
            "last_scraped": pd.to_datetime(["2026-01-01", "2026-01-02", "2026-01-03"]),
            "neighbourhood_cleansed": ["Eixample", "Gracia", "Eixample"],
            "room_type": ["Entire home/apt", "Private room", "Entire home/apt"],
            "price": [120.0, 85.0, 150.0],
            "review_scores_rating": [4.8, 4.5, 4.9],
            "latitude": [41.4, 41.3, 41.5],
            "longitude": [2.1, 2.2, 2.0],
            "description": ["Nice flat", "Small room", "Central apartment"],
        }
    )


def test_detect_field_semantics_for_listing_columns():
    df = make_listing_like_df()

    semantics = detect_field_semantics(df).set_index("column")

    assert semantics.loc["last_scraped", "semantic_role"] == "时间字段"
    assert semantics.loc["neighbourhood_cleansed", "semantic_role"] == "地区字段"
    assert semantics.loc["room_type", "semantic_role"] == "类别字段"
    assert semantics.loc["price", "semantic_role"] == "金额/价格字段"
    assert semantics.loc["review_scores_rating", "semantic_role"] == "评分字段"
    assert semantics.loc["latitude", "semantic_role"] == "经纬度字段"


def test_detect_capabilities_for_listing_columns():
    df = make_listing_like_df()

    capabilities = detect_capabilities(df).set_index("capability")

    assert capabilities.loc["时间趋势分析", "supported"] == "支持"
    assert capabilities.loc["分组聚合分析", "supported"] == "支持"
    assert capabilities.loc["相关性分析", "supported"] == "支持"
    assert capabilities.loc["文本分析/词云", "supported"] == "支持"
