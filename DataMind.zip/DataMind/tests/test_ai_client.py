"""Tests for the optional AI client helpers.

Source: Student + AI
"""

from modules.ai_client import clear_ai_response_cache, extract_output_text, request_structured_json


def test_extract_output_text_from_chat_completions_payload():
    payload = {"choices": [{"message": {"content": '{"ok": true}'}}]}

    assert extract_output_text(payload) == '{"ok": true}'


def test_extract_output_text_from_shortcut_field():
    payload = {"output_text": '{"ok": true}'}

    assert extract_output_text(payload) == '{"ok": true}'


def test_extract_output_text_from_nested_output():
    payload = {
        "output": [
            {
                "content": [
                    {"type": "output_text", "text": '{"ok": '},
                    {"type": "output_text", "text": "true}"},
                ]
            }
        ]
    }

    assert extract_output_text(payload) == '{"ok": true}'


def test_request_structured_json_returns_local_error_when_ai_disabled(monkeypatch):
    monkeypatch.setattr(
        "modules.ai_client.ai_status",
        lambda: {"can_call": False, "message": "当前使用本地规则，不调用外部 AI。"},
    )

    data, error = request_structured_json("prompt", {"schema": {"type": "object"}})

    assert data is None
    assert "本地规则" in error


def test_request_structured_json_handles_read_timeout(monkeypatch):
    clear_ai_response_cache()
    monkeypatch.setattr(
        "modules.ai_client.ai_status",
        lambda: {"can_call": True, "message": "AI 可调用。"},
    )
    monkeypatch.setattr("modules.ai_client.ai_model", lambda: "deepseek-chat")
    monkeypatch.setattr("modules.ai_client.ai_base_url", lambda: "https://api.example.com")
    monkeypatch.setattr("modules.ai_client.ai_api_key", lambda: "test-key")
    monkeypatch.setattr("modules.ai_client.ai_use_system_proxy", lambda: False)

    class TimeoutResponse:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, traceback):
            return False

        def read(self):
            raise TimeoutError("read timed out")

    class TimeoutOpener:
        def open(self, request, timeout=30):
            return TimeoutResponse()

    monkeypatch.setattr(
        "modules.ai_client.urllib.request.build_opener",
        lambda *args, **kwargs: TimeoutOpener(),
    )

    data, error = request_structured_json("prompt", {"schema": {"type": "object"}})

    assert data is None
    assert "请求超时" in error


def test_request_structured_json_caches_successful_response(monkeypatch):
    clear_ai_response_cache()
    monkeypatch.setattr(
        "modules.ai_client.ai_status",
        lambda: {"can_call": True, "message": "AI 可调用。"},
    )
    monkeypatch.setattr("modules.ai_client.ai_model", lambda: "deepseek-chat")
    monkeypatch.setattr("modules.ai_client.ai_base_url", lambda: "https://api.example.com")
    monkeypatch.setattr("modules.ai_client.ai_api_key", lambda: "test-key")
    monkeypatch.setattr("modules.ai_client.ai_use_system_proxy", lambda: False)
    calls = {"count": 0}

    class SuccessResponse:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, traceback):
            return False

        def read(self):
            calls["count"] += 1
            return b'{"choices":[{"message":{"content":"{\\"answer\\": [1]}"}}]}'

    class SuccessOpener:
        def open(self, request, timeout=30):
            return SuccessResponse()

    monkeypatch.setattr(
        "modules.ai_client.urllib.request.build_opener",
        lambda *args, **kwargs: SuccessOpener(),
    )

    first, first_error = request_structured_json("same prompt", {"answer": "array"})
    first["answer"].append(2)
    second, second_error = request_structured_json("same prompt", {"answer": "array"})

    assert first_error is None
    assert second_error is None
    assert calls["count"] == 1
    assert second == {"answer": [1]}
