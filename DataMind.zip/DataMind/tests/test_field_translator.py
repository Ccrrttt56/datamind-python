"""Tests for display-only field translation."""

from modules import field_translator
from modules.field_translator import (
    display_value_label,
    display_field_label,
    display_text_with_field_labels,
    local_translate_field_name,
    should_translate_value,
    translate_display_values,
    translate_field_names,
)


def test_display_field_label_keeps_original_with_chinese_translation():
    label = display_field_label("room_type", {"room_type": "房型"})
    assert label == "room_type（房型）"


def test_display_text_with_field_labels_replaces_embedded_field_names():
    text = "比较不同 room_type 的 price 差异，查看 review_scores_rating 的关系。"
    result = display_text_with_field_labels(
        text,
        {
            "room_type": "房型",
            "price": "价格",
            "review_scores_rating": "评论综合评分",
        },
    )

    assert "room_type（房型）" in result
    assert "price（价格）" in result
    assert "review_scores_rating（评论综合评分）" in result


def test_local_translation_requires_complete_known_meaning():
    assert local_translate_field_name("review_scores_rating") == "评论综合评分"
    assert local_translate_field_name("host_since") == ""


def test_ai_translation_used_for_unknown_complete_field(monkeypatch):
    def fake_request(prompt, schema, timeout=30):
        return {"translations": {"host_since": "房东加入平台时间"}}, None

    monkeypatch.setattr(field_translator, "request_structured_json", fake_request)
    cache = {}
    translations = translate_field_names(["host_since"], cache=cache, use_ai=True)
    assert translations["host_since"] == "房东加入平台时间"
    assert cache["host_since"] == "房东加入平台时间"


def test_ai_failure_falls_back_to_conservative_literal(monkeypatch):
    def fake_request(prompt, schema, timeout=30):
        return None, "AI unavailable"

    monkeypatch.setattr(field_translator, "request_structured_json", fake_request)
    translations = translate_field_names(["host_since"], cache={}, use_ai=True)
    assert translations["host_since"] == "房东since"


def test_display_value_label_translates_common_category_value():
    label = display_value_label("room_type", "Entire home/apt", {"room_type::Entire home/apt": "整套房源或公寓"})
    assert label == "Entire home/apt（整套房源或公寓）"


def test_should_not_translate_url_or_likely_place_name():
    assert not should_translate_value("https://example.com/listing")
    assert not should_translate_value("Brooklyn")


def test_ai_value_translation_is_on_demand(monkeypatch):
    def fake_request(prompt, schema, timeout=30):
        return {"translations": {"within an hour": "一小时内"}}, None

    monkeypatch.setattr(field_translator, "request_structured_json", fake_request)
    cache = {}
    translations = translate_display_values("host_response_time", ["within an hour"], cache=cache, use_ai=True)
    assert translations["host_response_time::within an hour"] == "一小时内"
    assert cache["host_response_time::within an hour"] == "一小时内"
