"""Tests for visualization helpers.

Source: Student + AI
"""

import pandas as pd
from plotly.graph_objects import Figure

from modules.visualizer import bar_chart, heatmap, histogram, line_chart, pie_chart, recommend_chart, scatter_chart


def test_bar_chart_returns_figure():
    df = pd.DataFrame({"country": ["China", "US"], "sales_sum": [100, 80]})

    fig = bar_chart(df, x="country", y="sales_sum")

    assert isinstance(fig, Figure)


def test_pie_chart_returns_figure():
    df = pd.DataFrame({"country": ["China", "US"], "count": [100, 80]})

    fig = pie_chart(df, names="country", values="count", hole=0.45)

    assert isinstance(fig, Figure)


def test_line_chart_returns_figure():
    df = pd.DataFrame({"date": pd.to_datetime(["2026-01-01", "2026-02-01"]), "sales": [10, 20]})

    fig = line_chart(df, x="date", y="sales")

    assert isinstance(fig, Figure)


def test_heatmap_returns_figure():
    corr = pd.DataFrame({"a": [1.0, 0.5], "b": [0.5, 1.0]}, index=["a", "b"])

    fig = heatmap(corr)

    assert isinstance(fig, Figure)


def test_histogram_returns_figure():
    df = pd.DataFrame({"score": [80, 85, 90]})

    fig = histogram(df, "score")

    assert isinstance(fig, Figure)


def test_scatter_chart_returns_figure():
    df = pd.DataFrame({"price": [100, 120, 90], "rating": [4.5, 4.8, 4.2]})

    fig = scatter_chart(df, x="price", y="rating")

    assert isinstance(fig, Figure)


def test_recommend_chart_for_trend():
    recommendation = recommend_chart({"numeric_columns": ["sales"]}, "trend_analysis")

    assert recommendation["chart_type"] == "line"
