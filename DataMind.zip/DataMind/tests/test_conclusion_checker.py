"""Tests for report conclusion support checker.

Source: Student + AI
"""

import pandas as pd

from modules.conclusion_checker import check_conclusion_support, find_mentioned_fields


def make_conclusion_df():
    return pd.DataFrame(
        {
            "price": [80, 100, 120, 150, 180],
            "review_scores_rating": [4.0, 4.2, 4.4, 4.6, 4.8],
            "room_type": ["A", "A", "B", "B", "B"],
        }
    )


def test_find_mentioned_fields_uses_chinese_aliases():
    df = make_conclusion_df()

    fields = find_mentioned_fields(df, "价格越高评分越高")

    assert "price" in fields
    assert "review_scores_rating" in fields


def test_check_conclusion_support_for_correlation():
    df = make_conclusion_df()

    result = check_conclusion_support(df, "价格越高，评分越高")

    assert result["support"] == "较支持"
    assert any("相关系数" in item for item in result["evidence"])


def test_check_conclusion_warns_about_causal_wording():
    df = make_conclusion_df()

    result = check_conclusion_support(df, "价格导致评分提高")

    assert result["support"] in {"表述过强", "部分支持"}
    assert any("因果" in item for item in result["warnings"])
    assert "不直接说明因果" in result["suggestion"]


def test_check_conclusion_support_accepts_candidate_fields():
    df = make_conclusion_df().rename(columns={"price": "nightly_cost"})

    result = check_conclusion_support(
        df,
        "费用越高评分越高",
        candidate_fields=["nightly_cost", "review_scores_rating"],
    )

    assert result["fields"] == ["nightly_cost", "review_scores_rating"]
    assert any("相关系数" in item for item in result["evidence"])
