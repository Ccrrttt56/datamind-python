"""Tests for preprocessing utilities.

Source: Student + AI
"""

import pandas as pd

from modules.preprocessor import clean_table


def test_clean_table_drops_duplicates_and_fills_missing_values():
    df = pd.DataFrame(
        {
            "score": [90, None, None],
            "city": ["Shanghai", None, None],
        }
    )

    cleaned, log = clean_table(df, drop_duplicates=True, convert_types=False)

    assert len(cleaned) == 2
    assert cleaned["score"].isna().sum() == 0
    assert cleaned["city"].isna().sum() == 0
    assert any("删除重复行" in item for item in log)


def test_clean_table_converts_numeric_strings():
    df = pd.DataFrame({"amount": ["10", "20", "30"]})

    cleaned, log = clean_table(df, convert_types=True)

    assert pd.api.types.is_numeric_dtype(cleaned["amount"])
    assert any("转换为数值类型" in item for item in log)


def test_clean_table_converts_currency_strings():
    df = pd.DataFrame({"price": ["$1,200.50", "$800.00", "$600.00"]})

    cleaned, log = clean_table(df, convert_types=True)

    assert pd.api.types.is_numeric_dtype(cleaned["price"])
    assert cleaned["price"].iloc[0] == 1200.50
    assert any("转换为数值类型" in item for item in log)


def test_clean_table_handles_nonpositive_price_and_quantity_values():
    df = pd.DataFrame(
        {
            "price": [100, 0, -50],
            "quantity": [2, 0, -1],
            "availability_365": [0, 10, 20],
        }
    )

    cleaned, log = clean_table(df, handle_nonpositive=True, numeric_fill="median")

    assert (cleaned["price"] > 0).all()
    assert (cleaned["quantity"] > 0).all()
    assert cleaned["availability_365"].iloc[0] == 0
    assert any("小于等于 0" in item for item in log)


def test_clean_table_can_drop_high_missing_columns():
    df = pd.DataFrame(
        {
            "mostly_empty": [None, None, "x"],
            "kept": [1, 2, 3],
        }
    )

    cleaned, log = clean_table(
        df,
        drop_high_missing=True,
        high_missing_threshold=0.5,
    )

    assert "mostly_empty" not in cleaned.columns
    assert "kept" in cleaned.columns
    assert any("删除缺失比例超过" in item for item in log)


def test_clean_table_strips_text_and_turns_blank_strings_into_missing_values():
    df = pd.DataFrame({"city": [" Shanghai ", "   ", None]})

    cleaned, log = clean_table(
        df,
        drop_duplicates=False,
        convert_types=False,
        numeric_fill="none",
        category_fill="none",
    )

    assert cleaned["city"].iloc[0] == "Shanghai"
    assert cleaned["city"].isna().sum() == 2
    assert any("去除前后空格" in item for item in log)
    assert any("空字符串统一为缺失值" in item for item in log)


def test_clean_table_can_standardize_category_values():
    df = pd.DataFrame({"room_type": ["Private room", " private room ", "PRIVATE ROOM"]})

    cleaned, log = clean_table(
        df,
        convert_types=False,
        standardize_category_values=True,
        category_fill="none",
    )

    assert cleaned["room_type"].nunique() == 1
    assert any("已合并" in item for item in log)


def test_clean_table_can_keep_missing_values_unfilled():
    df = pd.DataFrame({"score": [1, None, 3], "city": ["A", None, "B"]})

    cleaned, log = clean_table(
        df,
        convert_types=False,
        numeric_fill="none",
        category_fill="none",
    )

    assert cleaned["score"].isna().sum() == 1
    assert cleaned["city"].isna().sum() == 1
    assert any("不填充缺失值" in item for item in log)


def test_clean_table_can_mark_outliers_without_changing_original_value():
    df = pd.DataFrame({"price": [10, 11, 12, 13, 14, 15, 16, 1000]})

    cleaned, log = clean_table(
        df,
        convert_types=False,
        handle_nonpositive=False,
        outlier_strategy="mark",
        numeric_fill="none",
    )

    assert "price_是否极端值" in cleaned.columns
    assert cleaned["price"].iloc[-1] == 1000
    assert bool(cleaned["price_是否极端值"].iloc[-1]) is True
    assert any("标记" in item and "极端值" in item for item in log)


def test_clean_table_can_winsorize_outliers():
    df = pd.DataFrame({"price": [10, 11, 12, 13, 14, 15, 16, 1000]})

    cleaned, log = clean_table(
        df,
        convert_types=False,
        handle_nonpositive=False,
        outlier_strategy="winsorize",
        numeric_fill="none",
    )

    assert cleaned["price"].iloc[-1] < 1000
    assert any("截尾处理" in item for item in log)


def test_clean_table_can_override_outlier_strategy_by_column():
    df = pd.DataFrame(
        {
            "price": [10, 11, 12, 13, 14, 15, 16, 1000],
            "score": [1, 2, 3, 4, 5, 6, 7, 100],
        }
    )

    cleaned, log = clean_table(
        df,
        convert_types=False,
        handle_nonpositive=False,
        outlier_strategy="none",
        outlier_strategies_by_column={"price": "winsorize", "score": "mark"},
        numeric_fill="none",
    )

    assert cleaned["price"].iloc[-1] < 1000
    assert "score_是否极端值" in cleaned.columns
    assert bool(cleaned["score_是否极端值"].iloc[-1]) is True
    assert any("price" in item and "截尾处理" in item for item in log)
    assert any("score" in item and "标记" in item for item in log)
