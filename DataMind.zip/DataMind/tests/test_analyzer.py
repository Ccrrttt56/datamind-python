"""Tests for deterministic analysis functions.

Source: Student + AI
"""

import pandas as pd
import pytest

from modules.analyzer import (
    AnalysisError,
    cluster_analysis,
    column_profile,
    correlation,
    count_rows,
    duplicate_rows,
    groupby_count,
    groupby_agg,
    groupby_sum,
    missing_values,
    numeric_summary,
    outlier_detection,
    text_word_frequency,
    top_records,
    top_n,
    trend_analysis,
)


def make_sales_df():
    return pd.DataFrame(
        {
            "country": ["China", "China", "US", "US", "UK"],
            "product": ["A", "B", "A", "A", "B"],
            "sales": [100, 150, 80, 120, 90],
            "quantity": [2, 3, 1, 4, 2],
            "date": pd.to_datetime(
                ["2026-01-01", "2026-01-15", "2026-02-01", "2026-02-15", "2026-03-01"]
            ),
        }
    )


def test_count_rows():
    df = make_sales_df()

    assert count_rows(df)["row_count"] == 5


def test_missing_values_returns_table():
    df = make_sales_df()
    df.loc[0, "product"] = None

    result = missing_values(df)

    assert result.loc[result["column"] == "product", "missing_count"].iloc[0] == 1


def test_top_n():
    df = make_sales_df()

    result = top_n(df, "product", n=1)

    assert result.iloc[0]["product"] == "A"
    assert result.iloc[0]["count"] == 3


def test_column_profile():
    df = make_sales_df()

    result = column_profile(df, "product")

    assert result["column"] == "product"
    assert result["unique_count"] == 2
    assert not result["top_values"].empty


def test_numeric_summary():
    df = make_sales_df()

    result = numeric_summary(df, "sales")

    assert result["median"] == 100
    assert result["max"] == 150


def test_groupby_count():
    df = make_sales_df()

    result = groupby_count(df, "product")

    assert result.iloc[0]["product"] == "A"
    assert result.iloc[0]["count"] == 3
    assert "share_%" in result.columns


def test_groupby_sum():
    df = make_sales_df()

    result = groupby_sum(df, "country", "sales", n=1)

    assert result.iloc[0]["country"] == "China"
    assert result.iloc[0]["sales_sum"] == 250


def test_groupby_agg_mean():
    df = make_sales_df()

    result = groupby_agg(df, "country", "sales", agg="mean", n=1)

    assert result.iloc[0]["country"] == "China"
    assert result.iloc[0]["sales_mean"] == 125


def test_groupby_agg_median():
    df = make_sales_df()

    result = groupby_agg(df, "country", "sales", agg="median", n=1)

    assert result.iloc[0]["country"] == "China"
    assert result.iloc[0]["sales_median"] == 125


def test_outlier_detection():
    df = pd.DataFrame({"price": [10, 11, 12, 13, 500]})

    result = outlier_detection(df, "price")

    assert result["outlier_count"] == 1
    assert result["outliers"].iloc[0]["price"] == 500


def test_duplicate_rows():
    df = pd.DataFrame({"name": ["a", "a", "b"], "score": [1, 1, 2]})

    result = duplicate_rows(df)

    assert result["duplicate_count"] == 2
    assert len(result["examples"]) == 2


def test_top_records():
    df = make_sales_df()

    result = top_records(df, "sales", n=2)

    assert result.iloc[0]["sales"] == 150
    assert result.iloc[1]["sales"] == 120


def test_cluster_analysis_returns_profiles_and_points():
    df = pd.DataFrame(
        {
            "price": [20, 22, 25, 200, 210, 220],
            "rating": [4.1, 4.0, 4.2, 4.8, 4.9, 4.7],
            "reviews": [80, 75, 90, 10, 12, 9],
        }
    )

    result = cluster_analysis(df, ["price", "rating", "reviews"], n_clusters=2)

    assert result["n_clusters"] == 2
    assert len(result["profiles"]) == 2
    assert {"pca_x", "pca_y", "cluster"}.issubset(result["points"].columns)
    assert {"综合特征 1", "综合特征 2"}.issubset(result["pca_components"].index)
    assert result["counts"]["记录数"].sum() == 6


def test_cluster_analysis_sample_size_fits_but_labels_all_valid_rows():
    df = pd.DataFrame(
        {
            "price": [20, 22, 25, 200, 210, 220],
            "rating": [4.1, 4.0, 4.2, 4.8, 4.9, 4.7],
            "reviews": [80, 75, 90, 10, 12, 9],
        }
    )

    result = cluster_analysis(df, ["price", "rating", "reviews"], n_clusters=2, sample_size=4)

    assert result["fit_rows"] == 4
    assert result["sampled_rows"] == 6
    assert len(result["points"]) == 6


def test_cluster_analysis_requires_two_numeric_columns():
    df = pd.DataFrame({"price": [10, 20, 30]})

    with pytest.raises(AnalysisError):
        cluster_analysis(df, ["price"], n_clusters=2)


def test_text_word_frequency_filters_common_words():
    df = pd.DataFrame(
        {
            "description": [
                "Bright sunny room near park and metro",
                "Sunny apartment with balcony near metro",
                "Quiet room near museum",
            ]
        }
    )

    result = text_word_frequency(df, "description", top_n_words=5)

    words = set(result["frequencies"]["word"])
    assert "near" in words
    assert "sunny" in words
    assert "room" not in words
    assert result["unique_words"] > 0


def test_correlation_requires_two_numeric_columns():
    df = pd.DataFrame({"name": ["a", "b"], "score": [1, 2]})

    with pytest.raises(AnalysisError):
        correlation(df)


def test_correlation_matrix():
    df = make_sales_df()

    result = correlation(df)

    assert "sales" in result.columns
    assert "quantity" in result.columns


def test_trend_analysis():
    df = make_sales_df()

    result = trend_analysis(df, "date", "sales", freq="M", agg="sum")

    assert len(result) == 3
    assert result.iloc[0]["sales_sum"] == 250
