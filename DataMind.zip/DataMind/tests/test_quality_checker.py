"""Tests for data quality checking utilities.

Source: Student + AI
"""

import pandas as pd

from modules.quality_checker import quality_report, quick_diagnosis


def test_quality_report_detects_issues():
    df = pd.DataFrame(
        {
            "room_type": ["Entire", "Entire", "Private", "Entire", "Entire"],
            "price": [100, 100, 120, 10000, 100],
            "mostly_missing": [None, None, None, None, "x"],
            "date": pd.to_datetime(["2026-01-01", "2026-01-01", "2026-02-01", "2026-03-01", "2026-04-01"]),
        }
    )

    report = quality_report(df)

    assert 0 <= report["score"] <= 100
    assert not report["summary"].empty
    assert not report["issues"].empty
    assert not report["recommendations"].empty


def test_quick_diagnosis_returns_summary():
    df = pd.DataFrame(
        {
            "neighbourhood": ["A", "B", "A"],
            "price": [100, 120, 90],
            "rating": [4.5, 4.8, 4.2],
            "date": pd.to_datetime(["2026-01-01", "2026-01-02", "2026-01-03"]),
        }
    )

    diagnosis = quick_diagnosis(df)

    assert diagnosis["dataset_shape"] == "3 行 x 4 列"
    assert isinstance(diagnosis["priority_analysis"], list)
    assert isinstance(diagnosis["main_issues"], list)
