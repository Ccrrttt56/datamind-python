"""Tests for HTML report export helpers.

Source: Student + AI
"""

from app import markdown_report_to_html, markdown_report_to_pdf


def test_markdown_report_to_html_renders_basic_report():
    markdown = "# DataMind 数据分析报告\n\n## 1. 摘要\n\n- 数据共有 10 行\n- **结论**：可以继续分析\n"

    html = markdown_report_to_html(markdown)

    assert "<!doctype html>" in html
    assert "<h1>DataMind 数据分析报告</h1>" in html
    assert "<h2>1. 摘要</h2>" in html
    assert "<li>数据共有 10 行</li>" in html
    assert "<strong>结论</strong>" in html


def test_markdown_report_to_pdf_renders_basic_report():
    markdown = "# DataMind 数据分析报告\n\n## 1. 摘要\n\n- 数据共有 10 行\n- **结论**：可以继续分析\n"

    pdf = markdown_report_to_pdf(markdown)

    assert pdf.startswith(b"%PDF")
    assert len(pdf) > 1000
