"""Tests for dataset subject inference.

Source: Student + AI
"""

import pandas as pd

from modules import dataset_subject
from modules.dataset_subject import build_ai_subject_payload, build_ai_subject_prompt, infer_dataset_subject


def test_infer_dataset_subject_detects_short_term_rental_data(monkeypatch):
    def fake_request(prompt, schema, timeout=30):
        return None, "AI unavailable"

    monkeypatch.setattr(dataset_subject, "request_structured_json", fake_request)
    df = pd.DataFrame(
        {
            "host_name": ["A", "B"],
            "room_type": ["Entire home", "Private room"],
            "neighbourhood_cleansed": ["Center", "Beach"],
            "availability_365": [120, 80],
            "minimum_nights": [2, 3],
            "reviews_per_month": [1.2, 0.4],
        }
    )

    result = infer_dataset_subject(df)

    assert result["source"] == "本地规则兜底"
    assert "短租" in result["subject"] or "住宿" in result["subject"]
    assert result["matched_keywords"]


def test_build_ai_subject_payload_is_compact_and_non_executable():
    df = pd.DataFrame(
        {
            "price": [100, 200, 300],
            "description": ["first\nline", "second line", "third line"],
        }
    )

    payload = build_ai_subject_payload(df, sample_rows=2)

    assert payload["row_count"] == 3
    assert payload["column_count"] == 2
    assert payload["columns"] == ["price", "description"]
    assert payload["sample_values"]["description"][0] == "first line"
    assert "dtypes" in payload
    assert "missing_rates" in payload
    assert "短租房源或住宿平台数据" not in str(payload)


def test_ai_subject_prompt_requires_direct_data_object_sentence():
    prompt = build_ai_subject_prompt({"columns": ["room_type", "price"]})

    assert "data_object" in prompt
    assert "直接、具体、明显" in prompt
    assert "介绍或记录了什么" in prompt


def test_infer_dataset_subject_uses_ai_overview_without_local_topic(monkeypatch):
    def fake_request(prompt, schema, timeout=30):
        assert "本地规则" in prompt
        assert "短租房源或住宿平台数据" not in prompt
        return {
            "overview": {
                "subject": "住宿平台房源数据",
                "confidence": "较高",
                "data_object": "这份数据主要记录住宿平台上的房源信息。",
                "information_structure": "数据中包含房源类型、位置、价格、房东和评论评分等信息。",
                "supported_analysis": "这些信息可以支持房型构成、区域价格差异和评分关系等分析。",
            }
        }, None

    monkeypatch.setattr(dataset_subject, "request_structured_json", fake_request)
    df = pd.DataFrame(
        {
            "room_type": ["Entire home/apt", "Private room"],
            "price": ["$100", "$80"],
            "review_scores_rating": [4.8, 4.5],
        }
    )

    result = infer_dataset_subject(df)

    assert result["source"] == "AI 增强识别"
    assert result["overview_paragraphs"][0] == "这份数据主要记录住宿平台上的房源信息。"
    assert result["matched_keywords"] == []


def test_infer_dataset_subject_falls_back_when_ai_invalid(monkeypatch):
    def fake_request(prompt, schema, timeout=30):
        return {"overview": {"data_object": ""}}, None

    monkeypatch.setattr(dataset_subject, "request_structured_json", fake_request)
    df = pd.DataFrame({"room_type": ["Entire home/apt"], "host_name": ["A"], "availability_365": [120]})

    result = infer_dataset_subject(df)

    assert result["source"] == "本地规则兜底"
    assert result["overview_paragraphs"]
