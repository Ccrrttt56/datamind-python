"""Tests for data loading and profiling.

Source: Student + AI
"""

from pathlib import Path

import pandas as pd

from modules.data_loader import read_table
from modules.profiler import numeric_summary, profile_table


def test_read_sample_csv():
    sample_path = Path("data/sample/sample_students.csv")

    df = read_table(sample_path)

    assert len(df) == 6
    assert "score" in df.columns


def test_profile_sample_csv():
    sample_path = Path("data/sample/sample_students.csv")

    df = read_table(sample_path)

    profile = profile_table(df)

    assert profile["rows"] == 6
    assert profile["columns"] == 6
    assert profile["missing_counts"]["score"] == 1
    assert profile["missing_counts"]["city"] == 1


def test_numeric_summary_not_empty():
    sample_path = Path("data/sample/sample_students.csv")

    df = read_table(sample_path)

    summary = numeric_summary(df)

    assert not summary.empty
    assert "score" in set(summary["column"])


def test_read_gzipped_csv():
    gz_path = Path("data/sample/test_gzip_loader.csv.gz")
    expected = pd.DataFrame({"city": ["Barcelona", "Madrid"], "price": [120, 90]})

    try:
        expected.to_csv(gz_path, index=False, compression="gzip")
        df = read_table(gz_path)
    finally:
        gz_path.unlink(missing_ok=True)

    assert len(df) == 2
    assert list(df.columns) == ["city", "price"]
