"""Tests for the controlled Skill registry.

Source: Student + AI
"""

import pandas as pd

from modules.skill_registry import allowed_skill_ids, list_skills, skill_display_name, validate_skill_instruction


def make_skill_df():
    return pd.DataFrame(
        {
            "category": ["A", "B", "A"],
            "value": [10, 20, 30],
        }
    )


def test_skill_registry_lists_whitelisted_skills():
    skills = list_skills()

    assert not skills.empty
    assert "missing_values" in set(skills["Skill ID"])
    assert "缺失值检查" in set(skills["Skill 名称"])
    assert "correlation" in allowed_skill_ids()


def test_skill_display_name_returns_user_facing_name():
    assert skill_display_name("top_n") == "类别频次分析"


def test_validate_skill_instruction_rejects_unknown_skill():
    ok, message = validate_skill_instruction(make_skill_df(), {"intent": "run_python"})

    assert ok is False
    assert "白名单" in message


def test_validate_skill_instruction_rejects_bad_value_field():
    ok, message = validate_skill_instruction(
        make_skill_df(),
        {"intent": "groupby_sum", "group_column": "category", "value_column": "category"},
    )

    assert ok is False
    assert "不是数值字段" in message


def test_validate_skill_instruction_accepts_valid_instruction():
    instruction = {"intent": "top_n", "column": "category", "n": 2}

    ok, message = validate_skill_instruction(make_skill_df(), instruction)

    assert ok is True
    assert message == "字段和参数校验通过。"
