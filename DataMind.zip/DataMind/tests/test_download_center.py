"""Tests for result download center helpers.

Source: Student + AI
"""

import pandas as pd

from app import csv_download_item


def test_csv_download_item_encodes_dataframe():
    df = pd.DataFrame({"字段": ["价格"], "结果": [100]})

    item = csv_download_item("测试", "说明", df, "test.csv", "下载")

    assert item["file_name"] == "test.csv"
    assert item["mime"] == "text/csv"
    assert item["build_data"]().startswith(b"\xef\xbb\xbf")
    assert "下载" == item["button"]
