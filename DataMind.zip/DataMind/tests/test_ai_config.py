"""Tests for AI configuration switches.

Source: Student + AI
"""

from pathlib import Path

from modules import ai_config


def test_ai_status_defaults_to_local_rules(monkeypatch):
    monkeypatch.delenv("DATAMIND_AI_ENABLED", raising=False)
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("DEEPSEEK_API_KEY", raising=False)
    monkeypatch.delenv("DATAMIND_AI_API_KEY", raising=False)
    monkeypatch.setattr(ai_config, "ENV_PATH", Path("missing.env"))

    status = ai_config.ai_status()

    assert status["enabled"] is False
    assert status["can_call"] is False
    assert status["state"] == "未启用"


def test_ai_status_requires_api_key(monkeypatch):
    monkeypatch.setenv("DATAMIND_AI_ENABLED", "true")
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.delenv("DEEPSEEK_API_KEY", raising=False)
    monkeypatch.delenv("DATAMIND_AI_API_KEY", raising=False)
    monkeypatch.setattr(ai_config, "ENV_PATH", Path("missing.env"))

    status = ai_config.ai_status()

    assert status["enabled"] is True
    assert status["has_api_key"] is False
    assert status["can_call"] is False


def test_ai_status_can_call_when_enabled_and_key_exists(monkeypatch):
    monkeypatch.setenv("DATAMIND_AI_ENABLED", "true")
    monkeypatch.delenv("DATAMIND_AI_PROVIDER", raising=False)
    monkeypatch.delenv("DATAMIND_AI_BASE_URL", raising=False)
    monkeypatch.setenv("DEEPSEEK_API_KEY", "test-key")
    monkeypatch.setenv("DATAMIND_AI_MODEL", "deepseek-chat")
    monkeypatch.setattr(ai_config, "ENV_PATH", Path("missing.env"))

    status = ai_config.ai_status()

    assert status["can_call"] is True
    assert status["provider"] == "DeepSeek"
    assert status["model"] == "deepseek-chat"
    assert status["base_url"] == "https://api.deepseek.com"


def test_load_env_file_reads_simple_pairs():
    env_path = Path("outputs/test_temp.env")
    env_path.parent.mkdir(exist_ok=True)
    env_path.write_text("DATAMIND_AI_ENABLED=true\nDEEPSEEK_API_KEY='abc'\n", encoding="utf-8")

    try:
        values = ai_config.load_env_file(env_path)
    finally:
        env_path.unlink(missing_ok=True)

    assert values["DATAMIND_AI_ENABLED"] == "true"
    assert values["DEEPSEEK_API_KEY"] == "abc"
