"""Tests for controlled natural-language QA.

Source: Student + AI
"""

import pandas as pd

from modules import qa_engine
from modules.qa_engine import answer_question, parse_question, run_controlled_query


def make_qa_df():
    return pd.DataFrame(
        {
            "major": ["Math", "Math", "CS", "Business"],
            "score": [90, 85, 95, 80],
            "study_hours": [10, 9, 12, 8],
            "date": pd.to_datetime(["2026-01-01", "2026-01-02", "2026-02-01", "2026-02-02"]),
        }
    )


def test_parse_row_count_question():
    df = make_qa_df()

    instruction = parse_question(df, "这份数据有多少行？")

    assert instruction["intent"] == "count_rows"


def test_answer_missing_values_question():
    df = make_qa_df()
    df.loc[0, "major"] = None

    response = answer_question(df, "哪些字段缺失最多？")

    assert response["ok"] is True
    assert response["intent"] == "missing_values"
    assert "major" in set(response["result"]["column"])
    assert response["summary"]["结论"].startswith("缺失最多的字段是 major")
    assert "缺失值会影响" in response["summary"]["解释"]


def test_answer_top_n_question():
    df = make_qa_df()

    response = answer_question(df, "major 前 2 个频次是什么？")

    assert response["ok"] is True
    assert response["intent"] == "top_n"
    assert response["instruction"]["column"] == "major"
    assert len(response["result"]) == 2
    assert "出现最多" in response["summary"]["结论"]


def test_answer_distribution_question_as_top_n():
    df = pd.DataFrame(
        {
            "room_type": ["Entire home", "Private room", "Entire home", "Shared room"],
            "price": [100, 60, 120, 30],
        }
    )

    response = answer_question(df, "不同 room_type 的房源数量分布")

    assert response["ok"] is True
    assert response["intent"] == "groupby_count"
    assert response["instruction"]["group_column"] == "room_type"
    assert "数量最多" in response["summary"]["结论"]


def test_answer_distribution_question_with_chinese_field_alias():
    df = pd.DataFrame(
        {
            "room_type": ["Entire home", "Private room", "Entire home", "Shared room"],
            "price": [100, 60, 120, 30],
        }
    )

    response = answer_question(df, "不同房型的房源数量分布")

    assert response["ok"] is True
    assert response["intent"] == "groupby_count"
    assert response["instruction"]["group_column"] == "room_type"


def test_answer_groupby_mean_with_chinese_field_aliases():
    df = pd.DataFrame(
        {
            "room_type": ["Entire home", "Private room", "Entire home", "Shared room"],
            "price": [100, 60, 120, 30],
        }
    )

    response = answer_question(df, "不同房型的平均价格是多少")

    assert response["ok"] is True
    assert response["intent"] == "groupby_agg"
    assert response["instruction"]["group_column"] == "room_type"
    assert response["instruction"]["value_column"] == "price"


def test_answer_cluster_group_rating_question_with_generated_cluster_field():
    df = pd.DataFrame(
        {
            "智能分群": ["第 1 组", "第 1 组", "第 2 组", "第 2 组"],
            "review_scores_rating": [4.8, 4.6, 4.1, 4.0],
        }
    )

    response = answer_question(df, "智能分群的组别的评分情况如何")

    assert response["ok"] is True
    assert response["intent"] == "groupby_agg"
    assert response["instruction"]["group_column"] == "智能分群"
    assert response["instruction"]["value_column"] == "review_scores_rating"
    assert response["instruction"]["agg"] == "mean"


def test_answer_numeric_summary_question():
    df = make_qa_df()

    response = answer_question(df, "score 的统计描述")

    assert response["ok"] is True
    assert response["intent"] == "numeric_summary"
    assert response["instruction"]["column"] == "score"
    assert "中位数" in response["summary"]["主要结果"]


def test_answer_outlier_question():
    df = pd.DataFrame({"price": [10, 11, 12, 13, 500]})

    response = answer_question(df, "price 有没有异常值")

    assert response["ok"] is True
    assert response["intent"] == "outlier_detection"
    assert response["result"]["outlier_count"] == 1


def test_answer_duplicate_question():
    df = pd.DataFrame({"name": ["a", "a", "b"], "score": [1, 1, 2]})

    response = answer_question(df, "有没有重复记录")

    assert response["ok"] is True
    assert response["intent"] == "duplicate_rows"
    assert response["result"]["duplicate_count"] == 2


def test_answer_top_records_question():
    df = make_qa_df()

    response = answer_question(df, "score 最高的前 2 条记录")

    assert response["ok"] is True
    assert response["intent"] == "top_records"
    assert response["instruction"]["sort_column"] == "score"
    assert len(response["result"]) == 2


def test_answer_groupby_sum_question():
    df = make_qa_df()

    response = answer_question(df, "按 major 对 score 求和")

    assert response["ok"] is True
    assert response["intent"] == "groupby_sum"
    assert response["instruction"]["group_column"] == "major"
    assert response["instruction"]["value_column"] == "score"
    assert "存在差异" in response["summary"]["结论"]
    assert "最高" in response["summary"]["主要结果"]


def test_run_controlled_query_from_recommended_instruction():
    df = make_qa_df()
    instruction = {"intent": "groupby_agg", "group_column": "major", "value_column": "score", "agg": "mean", "n": 10}

    response = run_controlled_query(df, instruction)

    assert response["ok"] is True
    assert response["intent"] == "groupby_agg"
    assert "存在差异" in response["summary"]["结论"]


def test_answer_correlation_question():
    df = make_qa_df()

    response = answer_question(df, "score 和 study_hours 的相关性如何？")

    assert response["ok"] is True
    assert response["intent"] == "correlation"
    assert "相关" in response["summary"]["结论"]
    assert "因果" in response["summary"]["提醒"]


def test_answer_unsupported_question():
    df = make_qa_df()

    response = answer_question(df, "请帮我写一首诗")

    assert response["ok"] is False
    assert response["intent"] == "unsupported"


def test_ai_parse_single_skill_when_local_rules_fail(monkeypatch):
    df = pd.DataFrame(
        {
            "room_type": ["Entire home", "Private room", "Entire home"],
            "price": [100, 60, 120],
        }
    )
    monkeypatch.setattr(
        qa_engine,
        "request_structured_json",
        lambda prompt, schema: (
            {
                "answer_type": "single_skill",
                "instructions": [
                    {
                        "intent": "groupby_agg",
                        "column": "",
                        "group_column": "room_type",
                        "value_column": "price",
                        "time_column": "",
                        "n": 10,
                        "agg": "mean",
                        "method": "",
                        "freq": "",
                    }
                ],
                "route": [],
                "user_explanation": "可以比较不同房型的平均价格。",
                "reason": "用户在询问哪类房源更贵。",
            },
            None,
        ),
    )

    response = answer_question(df, "哪类房源更贵一些")

    assert response["ok"] is True
    assert response["intent"] == "groupby_agg"
    assert response["parse_source"] == "AI 理解 + Skill 校验"


def test_ai_parse_analysis_route_when_question_is_open(monkeypatch):
    df = make_qa_df()
    monkeypatch.setattr(
        qa_engine,
        "request_structured_json",
        lambda prompt, schema: (
            {
                "answer_type": "analysis_route",
                "instructions": [],
                "route": ["先检查缺失值", "再查看主要类别分布"],
                "user_explanation": "这个问题更适合按步骤分析。",
                "reason": "问题过于开放。",
            },
            None,
        ),
    )

    response = answer_question(df, "这份数据说明了什么")

    assert response["ok"] is True
    assert response["intent"] == "analysis_route"
    assert response["parse_source"] == "AI 理解 + 分析路线"
